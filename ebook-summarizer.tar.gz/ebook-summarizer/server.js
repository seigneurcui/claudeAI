const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { Pool } = require('pg');
const { Ollama } = require('langchain/llms/ollama');
const { RecursiveCharacterTextSplitter } = require('langchain/text_splitter');
const EPub = require('epub');
const mammoth = require('mammoth');
const pdf = require('pdf-parse');
const AdmZip = require('adm-zip');
const { v4: uuidv4 } = require('uuid');
const cors = require('cors');
const WebSocket = require('ws');
const http = require('http');
const { exec } = require('child_process');
const puppeteer = require('puppeteer');
const MindmapGenerator = require('./mindmapGenerator'); // Import Mindmap Generator
const morgan = require('morgan');
const axios = require('axios');


const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Middleware configuration
app.use(cors());
app.use(morgan('dev'));
app.use(express.json({ limit: '50mb' }));
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));
// [NEW] Serve generated mindmap files
app.use('/outputs', express.static('outputs'));


// PostgreSQL connection configuration
const pool = new Pool({
    user: process.env.DB_USER || 'postgres',
    host: process.env.DB_HOST || '127.0.0.1',
    database: process.env.DB_NAME || 'ebook_sumup',
    password: process.env.DB_PASSWORD || 'postgres',
    port: process.env.DB_PORT || 6432,
});

// Initialize database table
async function initDatabase() {
    try {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS ebooks (
                id SERIAL PRIMARY KEY,
                file_name VARCHAR(255) NOT NULL,
                original_name VARCHAR(255) NOT NULL,
                file_type VARCHAR(50) NOT NULL,
                file_size BIGINT NOT NULL,
                upload_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                processing_status VARCHAR(50) DEFAULT 'pending',
                model_used VARCHAR(100),
                summary_length INTEGER,
                processing_time_seconds INTEGER,
                total_pages INTEGER,
                summary_text TEXT,
                keywords TEXT[],
                metadata JSONB
            )
        `);
        
        await pool.query(`
            CREATE INDEX IF NOT EXISTS idx_ebooks_upload_time ON ebooks(upload_time);
            CREATE INDEX IF NOT EXISTS idx_ebooks_keywords ON ebooks USING GIN(keywords);
            CREATE INDEX IF NOT EXISTS idx_ebooks_status ON ebooks(processing_status);
            CREATE INDEX IF NOT EXISTS idx_ebooks_model_used ON ebooks(model_used);
        `);
        
        console.log('Database initialized successfully');
    } catch (err) {
        console.error('Database initialization failed:', err);
    }
}

// Store active processing jobs
const activeJobs = new Map();

// WebSocket connection management
const clients = new Set();
wss.on('connection', (ws) => {
    clients.add(ws);
    ws.on('close', () => {
        clients.delete(ws);
    });
});

// Broadcast message to all clients
function broadcast(data) {
    clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(data));
        }
    });
}

// File upload configuration
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = 'uploads';
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const originalName = Buffer.from(file.originalname, 'latin1').toString('utf8');
        cb(null, uniqueSuffix + path.extname(originalName));
    }
});

const upload = multer({ 
    storage,
    limits: { fileSize: 100 * 1024 * 1024 }, // 100MB limit
    fileFilter: (req, file, cb) => {
        const allowedExtensions = ['.epub', '.mobi', '.azw', '.azw3', '.pdf', '.txt', '.rtf', '.cbr', '.cbz'];
        const originalName = Buffer.from(file.originalname, 'latin1').toString('utf8');
        const ext = path.extname(originalName).toLowerCase();
        if (allowedExtensions.includes(ext)) {
            cb(null, true);
        } else {
            cb(new Error('Unsupported file format'));
        }
    }
});

// Get Ollama model list - using curl command
app.get('/api/models', async (req, res) => {
    const command = 'curl -s http://localhost:11434/api/tags';
    console.log(`Executing command: ${command}`);

    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.error(`curl command execution failed: ${error.message}`);
            console.error(`stderr: ${stderr}`);
            res.status(503).json({ 
                status: 'offline', 
                error: 'Could not connect to Ollama service via curl. Please ensure Ollama is running.',
                details: stderr 
            });
            return;
        }

        try {
            const data = JSON.parse(stdout);
            console.log('Raw response from curl:', data);

            if (data.models && data.models.length > 0) {
                const modelNames = data.models.map(model => model.name);
                res.json({ status: 'success', models: modelNames });
            } else {
                res.json({ status: 'no_models', models: [] });
            }
        } catch (parseError) {
            console.error('Failed to parse Ollama API response:', parseError);
            res.status(500).json({
                status: 'error',
                error: 'Failed to parse Ollama API response',
                details: stdout
            });
        }
    });
});

// Text extraction function
async function extractTextFromFile(filePath, fileType) {
    const ext = path.extname(filePath).toLowerCase();
    
    try {
        switch (ext) {
            case '.txt':
                return fs.readFileSync(filePath, 'utf8');
                
            case '.pdf':
                const pdfBuffer = fs.readFileSync(filePath);
                const pdfData = await pdf(pdfBuffer);
                return pdfData.text;
                
            case '.epub':
                return new Promise((resolve, reject) => {
                    const epub = new EPub(filePath);
                    epub.on('end', () => {
                        let text = '';
                        const chapterIds = epub.flow.map(chapter => chapter.id);
                        
                        let processedChapters = 0;
                        if (chapterIds.length === 0) {
                            resolve('');
                            return;
                        }
                        chapterIds.forEach(chapterId => {
                            epub.getChapter(chapterId, (err, data) => {
                                if (!err && data) {
                                    text += data.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ');
                                }
                                processedChapters++;
                                if (processedChapters === chapterIds.length) {
                                    resolve(text);
                                }
                            });
                        });
                    });
                    epub.parse();
                });
                
            case '.cbr':
            case '.cbz':
                const zip = new AdmZip(filePath);
                const entries = zip.getEntries();
                return `Comic book file contains ${entries.length} image files`;
                
            default:
                return fs.readFileSync(filePath, 'utf8');
        }
    } catch (error) {
        console.error('Text extraction failed:', error);
        throw new Error(`Could not extract text from ${ext} file: ${error.message}`);
    }
}

// Generate summary using Ollama
async function generateSummary(text, model, maxLength = 1500, fileName) {
    try {
        const ollama = new Ollama({
            baseUrl: 'http://localhost:11434',
            model: model,
        });
        
        const textSplitter = new RecursiveCharacterTextSplitter({
            chunkSize: 4000,
            chunkOverlap: 200,
        });
        
        const chunks = await textSplitter.splitText(text);
        let summaries = [];
        
        for (let i = 0; i < chunks.length; i++) {
            const prompt = `Please summarize the following text to no more than ${Math.floor(maxLength/chunks.length)} words:\n\n${chunks[i]}`;
            
            const response = await ollama.call(prompt);
            summaries.push(response);
            
            broadcast({
                type: 'chunk_progress',
                progress: (i + 1) / chunks.length * 100,
                message: `Processing text chunk ${i + 1}/${chunks.length} for ${fileName}`
            });
        }
        
        const combinedSummary = summaries.join('\n\n');
        if (combinedSummary.length > maxLength) {
            const finalPrompt = `Please summarize the following content into a final summary of no more than ${maxLength} words:\n\n${combinedSummary}`;
            return await ollama.call(finalPrompt);
        }
        
        return combinedSummary;
    } catch (error) {
        console.error('Summary generation failed:', error);
        throw new Error(`Summary generation failed: ${error.message}`);
    }
}

// Extract keywords
async function extractKeywords(text, model) {
    try {
        const ollama = new Ollama({
            baseUrl: 'http://localhost:11434',
            model: model,
        });
        
        const prompt = `Please extract 5-10 keywords from the following text, separated by commas:\n\n${text.substring(0, 2000)}`;
        const response = await ollama.call(prompt);
        
        return response.split(',').map(keyword => keyword.trim()).filter(k => k);
    } catch (error) {
        console.error('Keyword extraction failed:', error);
        return [];
    }
}

// File upload and processing endpoint
app.post('/api/upload', upload.array('files'), async (req, res) => {
    try {
        const { model, summaryLength } = req.body;
        const files = req.files;
        
        if (!files || files.length === 0) {
            return res.status(400).json({ error: 'No files uploaded' });
        }
        
        const jobId = uuidv4();
        const job = {
            id: jobId,
            files: files.map(file => {
                const correctedName = Buffer.from(file.originalname, 'latin1').toString('utf8');
                return {
                    id: uuidv4(),
                    name: correctedName,
                    path: file.path,
                    size: file.size,
                    type: path.extname(correctedName).toLowerCase(),
                    status: 'pending'
                };
            }),
            model,
            summaryLength: parseInt(summaryLength) || 1500,
            status: 'processing',
            startTime: Date.now(),
            processedFiles: 0,
            totalFiles: files.length
        };
        
        activeJobs.set(jobId, job);
        
        processFiles(jobId);
        
        res.json({ jobId, message: 'File upload successful, processing has started' });
    } catch (error) {
        console.error('File upload failed:', error);
        res.status(500).json({ error: error.message });
    }
});

// Main function for processing files
async function processFiles(jobId) {
    const job = activeJobs.get(jobId);
    if (!job) return;
    
    broadcast({
        type: 'job_started',
        jobId,
        totalFiles: job.totalFiles
    });
    
    for (let i = 0; i < job.files.length; i++) {
        if (job.status === 'cancelled') break;
        
        const file = job.files[i];
        file.status = 'processing';
        
        // [MODIFIED] Requirement 2: Send current file number and total
        broadcast({
            type: 'file_processing',
            jobId,
            fileId: file.id,
            fileName: file.name,
            progress: (i / job.totalFiles) * 100,
            currentFileNumber: i + 1,
            totalFiles: job.totalFiles
        });
        
        const fileStartTime = Date.now(); // [MODIFIED] Requirement 1: Start timer for individual file
        
        try {
            const text = await extractTextFromFile(file.path, file.type);
            const summary = await generateSummary(text, job.model, job.summaryLength, file.name);
            const keywords = await extractKeywords(summary, job.model);
            
            // [MODIFIED] Requirement 1: Calculate individual processing time
            const fileEndTime = Date.now();
            const processingTimeSeconds = Math.round((fileEndTime - fileStartTime) / 1000);

            const result = await pool.query(`
                INSERT INTO ebooks (
                    file_name, original_name, file_type, file_size,
                    processing_status, model_used, summary_length,
                    summary_text, keywords, metadata, processing_time_seconds
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
                RETURNING id
            `, [
                path.basename(file.path),
                file.name,
                file.type,
                file.size,
                'completed',
                job.model,
                job.summaryLength,
                summary,
                keywords,
                { originalPath: file.path, textLength: text.length },
                processingTimeSeconds // Save individual time
            ]);
            
            file.status = 'completed';
            file.dbId = result.rows[0].id;
            file.summary = summary;
            file.keywords = keywords;
            
        } catch (error) {
            console.error(`Failed to process file ${file.name}:`, error);
            file.status = 'error';
            file.error = error.message;
        }
        
        job.processedFiles++;
        
        //~ job.endTime = Date.now();
        //~ jobDuration = Math.round((job.endTime - job.startTime) / 1000);
        
             //~ await sendNotifications(videoFileName, originalFileName, outputPath, duration.toFixed(2), languages);
     await sendNotifications(file.status, file.size, processingTimeSeconds, file.name);
        
        broadcast({
            type: 'file_completed',
            jobId,
            fileId: file.id,
            file: file,
            progress: (job.processedFiles / job.totalFiles) * 100
        });
    }
    
    job.status = (job.status === 'cancelled') ? 'cancelled' : 'completed';
    job.endTime = Date.now();
    
    broadcast({
        type: 'job_completed',
        jobId,
        totalTime: Math.round((job.endTime - job.startTime) / 1000),
        files: job.files
    });
}

// Cancel job
app.post('/api/cancel/:jobId', (req, res) => {
    const jobId = req.params.jobId;
    const job = activeJobs.get(jobId);
    
    if (job && job.status === 'processing') {
        job.status = 'cancelled';
        broadcast({
            type: 'job_cancelled',
            jobId
        });
        res.json({ message: 'Job has been cancelled' });
    } else {
        res.status(404).json({ error: 'Job not found or already completed' });
    }
});

// Get job status
app.get('/api/job/:jobId', (req, res) => {
    const job = activeJobs.get(req.params.jobId);
    if (job) {
        res.json(job);
    } else {
        res.status(404).json({ error: 'Job not found' });
    }
});

// [NEW] Get distinct models from database for filtering
app.get('/api/ebooks/models', async (req, res) => {
    try {
        const result = await pool.query('SELECT DISTINCT model_used FROM ebooks WHERE model_used IS NOT NULL ORDER BY model_used');
        res.json(result.rows.map(row => row.model_used));
    } catch (error) {
        console.error('Failed to get model list:', error);
        res.status(500).json({ error: error.message });
    }
});

// Get ebook list from database
app.get('/api/ebooks', async (req, res) => {
    try {
        // [MODIFIED] Requirement 3 & 4: Added model filter and pagination options
        const { search, startDate, endDate, model, page = 1, limit = 10 } = req.query;
        
        let query = 'SELECT * FROM ebooks';
        let countQuery = 'SELECT COUNT(*) FROM ebooks';
        
        let whereClauses = [];
        let params = [];
        let countParams = [];

        whereClauses.push('processing_status = $1');
        params.push('completed');
        countParams.push('completed');
        
        if (search) {
            whereClauses.push(`(original_name ILIKE $${params.length + 1} OR summary_text ILIKE $${params.length + 1} OR $${params.length + 1} = ANY(keywords))`);
            params.push(`%${search}%`);
            countParams.push(`%${search}%`);
        }
        
        if (startDate) {
            whereClauses.push(`upload_time >= $${params.length + 1}`);
            params.push(startDate);
            countParams.push(startDate);
        }
        
        if (endDate) {
            whereClauses.push(`upload_time <= $${params.length + 1}`);
            params.push(endDate);
            countParams.push(endDate);
        }

        if (model) {
            whereClauses.push(`model_used = $${params.length + 1}`);
            params.push(model);
            countParams.push(model);
        }

        if (whereClauses.length > 0) {
            const whereString = ' WHERE ' + whereClauses.join(' AND ');
            query += whereString;
            countQuery += whereString;
        }
        
        query += ' ORDER BY upload_time DESC';
        
        const countResult = await pool.query(countQuery, countParams);
        const total = parseInt(countResult.rows[0].count, 10);
        
        const pageNum = parseInt(page, 10);
        const limitNum = parseInt(limit, 10);
        const totalPages = (limit === 'all' || !limitNum) ? 1 : Math.ceil(total / limitNum);

        if (limit !== 'all') {
            const offset = (pageNum - 1) * limitNum;
            query += ` LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
            params.push(limitNum, offset);
        }
        
        const result = await pool.query(query, params);
        
        res.json({
            ebooks: result.rows,
            total,
            page: pageNum,
            totalPages
        });
    } catch (error) {
        console.error('Failed to get ebook list:', error);
        res.status(500).json({ error: error.message });
    }
});

// Export single file report
app.get('/api/export/:id/:format', async (req, res) => {
    try {
        const { id, format } = req.params;
        
        const result = await pool.query('SELECT * FROM ebooks WHERE id = $1', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'File not found' });
        }
        
        const ebook = result.rows[0];
        const timestamp = new Date().toISOString().split('T')[0];
        const safeFileName = ebook.original_name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
        
        switch (format.toLowerCase()) {
            case 'txt':
                res.setHeader('Content-Type', 'text/plain; charset=utf-8');
                res.setHeader('Content-Disposition', `attachment; filename="${safeFileName}_summary_${timestamp}.txt"`);
                res.send(`File Name: ${ebook.original_name}\nProcessing Time: ${ebook.upload_time}\nModel: ${ebook.model_used}\nKeywords: ${ebook.keywords.join(', ')}\n\nSummary:\n${ebook.summary_text}`);
                break;
                
            case 'html':
                res.setHeader('Content-Type', 'text/html; charset=utf-8');
                res.setHeader('Content-Disposition', `attachment; filename="${safeFileName}_summary_${timestamp}.html"`);
                res.send(`
                    <!DOCTYPE html>
                    <html><head><meta charset="utf-8"><title>${ebook.original_name} - Summary Report</title><style>body {font-family: 'Microsoft YaHei', sans-serif;}</style></head>
                    <body>
                        <h1>${ebook.original_name} - Summary Report</h1>
                        <p><strong>Processing Time:</strong> ${ebook.upload_time}</p>
                        <p><strong>Model Used:</strong> ${ebook.model_used}</p>
                        <p><strong>Keywords:</strong> ${ebook.keywords.join(', ')}</p>
                        <h2>Summary</h2>
                        <p>${ebook.summary_text.replace(/\n/g, '<br>')}</p>
                    </body></html>
                `);
                break;
                
            case 'markdown':
                res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
                res.setHeader('Content-Disposition', `attachment; filename="${safeFileName}_summary_${timestamp}.md"`);
                res.send(`# ${ebook.original_name} - Summary Report\n\n**Processing Time:** ${ebook.upload_time}\n**Model Used:** ${ebook.model_used}\n**Keywords:** ${ebook.keywords.join(', ')}\n\n## Summary\n\n${ebook.summary_text}`);
                break;

            // [NEW] Requirement 7: Add PDF export
            case 'pdf':
                const htmlContent = `
                    <!DOCTYPE html>
                    <html><head><meta charset="utf-8"><title>${ebook.original_name} - Summary Report</title><style>body {font-family: 'Microsoft YaHei', 'Segoe UI', sans-serif; padding: 20px;}</style></head>
                    <body>
                        <h1>${ebook.original_name} - Summary Report</h1>
                        <p><strong>Processing Time:</strong> ${ebook.upload_time}</p>
                        <p><strong>Model Used:</strong> ${ebook.model_used}</p>
                        <p><strong>Keywords:</strong> ${ebook.keywords.join(', ')}</p>
                        <h2>Summary</h2>
                        <p>${ebook.summary_text.replace(/\n/g, '<br>')}</p>
                    </body></html>`;
                
                const browser = await puppeteer.launch({ headless: "new", args: ['--no-sandbox'] });
                const page = await browser.newPage();
                await page.setContent(htmlContent, { waitUntil: 'networkidle0' });
                const pdfBuffer = await page.pdf({ format: 'A4', printBackground: true });
                await browser.close();

                res.setHeader('Content-Type', 'application/pdf');
                res.setHeader('Content-Disposition', `attachment; filename="${safeFileName}_summary_${timestamp}.pdf"`);
                res.send(pdfBuffer);
                break;

            default:
                res.status(400).json({ error: 'Unsupported export format' });
        }
    } catch (error) {
        console.error('Export failed:', error);
        res.status(500).json({ error: error.message });
    }
});

// [NEW] Requirement 8: Generate and export mind maps
// Helper function to generate mindmap data using LLM
async function generateMindmapDataFromText(ebook) {
    const ollama = new Ollama({
        baseUrl: 'http://localhost:11434',
        model: ebook.model_used,
    });
    
    const prompt = `Based on the following summary, create a hierarchical mind map structure. Represent the structure as a nested JSON object array. Each object should have 'id', 'label', 'level', and a 'children' array. The root node should have level 0. Do not include any explanations, just the JSON object.
Summary: """
${ebook.summary_text}
"""
JSON Output:`;
    
    const response = await ollama.call(prompt);

    // Clean and parse the response
    let nodes = [];
    try {
        const cleanedResponse = response.replace(/```json/g, '').replace(/```/g, '').trim();
        nodes = JSON.parse(cleanedResponse);
    } catch (e) {
        console.error("Failed to parse LLM response into JSON for mindmap:", e);
        // Fallback: create a simple mindmap
        nodes = [
            { id: 'root', label: ebook.original_name, level: 0, children: 
                (ebook.keywords || []).map((kw, i) => ({ id: `kw-${i}`, label: kw, level: 1, children: [] }))
            }
        ];
    }

    return {
        title: ebook.original_name,
        summary: ebook.summary_text,
        keywords: ebook.keywords,
        nodes: nodes
    };
}

app.get('/api/mindmap/:id/:format', async (req, res) => {
    try {
        const { id, format } = req.params;
        
        const result = await pool.query('SELECT * FROM ebooks WHERE id = $1', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'File not found' });
        }
        
        const ebook = result.rows[0];
        const mindmapData = await generateMindmapDataFromText(ebook);
        const safeFileName = ebook.original_name.replace(/[^a-z0-9]/gi, '_').toLowerCase();
        const generator = new MindmapGenerator();

        let filePath;
        let contentType;

        switch (format.toLowerCase()) {
            case 'html':
                filePath = await generator.generateHTML(mindmapData, safeFileName);
                contentType = 'text/html; charset=utf-8';
                break;
            case 'png':
                filePath = await generator.generatePNG(mindmapData, safeFileName);
                contentType = 'image/png';
                break;
            case 'pdf':
                filePath = await generator.generatePDF(mindmapData, safeFileName);
                contentType = 'application/pdf';
                break;
            default:
                return res.status(400).json({ error: 'Unsupported mindmap format' });
        }

        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `attachment; filename="${path.basename(filePath)}"`);
        fs.createReadStream(filePath).pipe(res);

    } catch (error) {
        console.error('Mindmap generation failed:', error);
        res.status(500).json({ error: `Mindmap generation failed: ${error.message}` });
    }
});


// [MODIFIED] Requirement 5: Batch export Excel for filtered results
app.post('/api/export/excel', async (req, res) => {
    try {
        const { ids } = req.body;
        if (!ids || !Array.isArray(ids) || ids.length === 0) {
            return res.status(400).json({ error: 'No file IDs provided' });
        }
        const xl = require('excel4node');
        
        const wb = new xl.Workbook();
        const ws = wb.addWorksheet('Ebook Summaries');
        
        const headers = ['File Name', 'Upload Time', 'Model Used', 'Keywords', 'Summary'];
        headers.forEach((header, index) => {
            ws.cell(1, index + 1).string(header);
        });
        
        const result = await pool.query(
            'SELECT * FROM ebooks WHERE id = ANY($1) ORDER BY upload_time DESC',
            [ids]
        );
        
        result.rows.forEach((ebook, index) => {
            ws.cell(index + 2, 1).string(ebook.original_name || '');
            ws.cell(index + 2, 2).string(ebook.upload_time ? new Date(ebook.upload_time).toISOString() : '');
            ws.cell(index + 2, 3).string(ebook.model_used || '');
            ws.cell(index + 2, 4).string(ebook.keywords ? ebook.keywords.join(', ') : '');
            ws.cell(index + 2, 5).string(ebook.summary_text || '');
        });
        
        const timestamp = new Date().toISOString().split('T')[0];
        const filename = `ebook_summaries_${timestamp}.xlsx`;
        
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        
        wb.write(filename, res);
    } catch (error) {
        console.error('Excel export failed:', error);
        res.status(500).json({ error: error.message });
    }
});


// Health check endpoint
app.get('/health', async (req, res) => {
    try {
        await pool.query('SELECT 1');
        
        const ollamaResponse = await fetch('http://localhost:11434/api/tags').catch(() => null);
        const ollamaStatus = ollamaResponse && ollamaResponse.ok ? 'connected' : 'disconnected';
        
        res.json({
            status: 'healthy',
            timestamp: new Date().toISOString(),
            database: 'connected',
            ollama: ollamaStatus,
            uptime: process.uptime(),
            memory: process.memoryUsage(),
            version: '1.0.0'
        });
    } catch (error) {
        res.status(503).json({
            status: 'unhealthy',
            error: error.message,
            timestamp: new Date().toISOString()
        });
    }
});





//~ async function sendNotifications(videoFileName, originalFileName, outputPath, duration, languages) {
     //~ await sendNotifications(file.status, file.size, processingTimeSeconds, file.name);
//~ async function sendNotifications(jobStatus, jobId, jobTotalTime, jobFilesList) {
//~ async function sendNotifications(jobStatus, jobId, jobTotalTime, jobFiles) {
async function sendNotifications(fileStatus, fileSize, fileTotalTime, fileName) {
  console.log(`📢 Sending notifications for: ${fileName}`);
  //~ const jobFiles = jobFilesList.join(', ');
  
  const notifications = [
    {
      name: 'WxPusher',
      url: 'https://wxpusher.zjiecode.com/api/send/message',
      headers: { 'Content-Type': 'application/json' },
      data: {
        appToken: 'AT_byimkOmi7B0xzvqEvXVYIAj0YkMrwDvV',
        content: `电子书总结完毕: ${fileStatus} ==> ${fileTotalTime} / ${fileSize} : ${fileName}`,
        summary: '电子书总结完毕',
        contentType: 2,
        topicIds: [36095],
        uids: ['UID_FD24Cus5ocGO5CKQAcxkw8gP2ZRu'],
        verifyPay: false,
        verifyPayType: 0,
      },
    },
    {
      name: 'PushPlus',
      url: 'http://www.pushplus.plus/send',
      headers: { 'Content-Type': 'application/json' },
      data: {
        token: 'f76bf4e54490439c86fdae45e9db76ce',
        title: '电子书总结完毕',
        content: `电子书总结完毕: ${fileStatus} ==> ${fileTotalTime} / ${fileSize} : ${fileName}`,
      },
    },
    {
      name: 'Resend Email',
      url: 'https://api.resend.com/emails',
      headers: {
        'Authorization': 'Bearer re_KwMt5gij_5c7XvcqJeNjmAhV3cy1DAvfj',
        'Content-Type': 'application/json',
      },
      data: {
        from: 'onboarding@resend.dev',
        to: 'seigneurtsui@goallez.dpdns.org',
        subject: '电子书总结完毕',
        html: `<p>电子书总结完毕: ${fileStatus} ==> ${fileTotalTime} / ${fileSize} : ${fileName}`,
      },
    },
    {
      name: 'Telegram',
      url: `https://api.telegram.org/bot8371556252:AAHUpvXA_73QYDsNbmMWiqG2SOKTKzzOY_Y/sendMessage`,
      headers: { 'Content-Type': 'application/json' },
      data: {
        chat_id: '8200348152',
        text: `电子书总结完毕: ${fileStatus} ==> ${fileTotalTime} / ${fileSize} : ${fileName}`,
      },
    },
  ];

  for (const notification of notifications) {
    try {
      const response = await axios.post(notification.url, notification.data, {
        headers: notification.headers,
      });
      console.log(`✅ ${notification.name} notification sent successfully:`, response.status);
    } catch (error) {
      console.error(`❌ Failed to send ${notification.name} notification:`, error.message);
    }
  }
}





// Start server
const PORT = process.env.PORT || 8066;

async function startServer() {
    try {
        await initDatabase();
        
        server.listen(PORT, () => {
            console.log(`Server is running on http://localhost:${PORT}`);
            console.log('WebSocket server started');
        });
    } catch (error) {
        console.error('Server startup failed:', error);
        process.exit(1);
    }
}

startServer();
