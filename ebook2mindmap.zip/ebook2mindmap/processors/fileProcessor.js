const fs = require('fs-extra');
const path = require('path');
const { EpubParser } = require('@ridi/epub-parser'); // 引入新的 EPUB 解析库
const pdfParse = require('pdf-parse');
const unzipper = require('unzipper');
const mammoth = require('mammoth');
const logger = require('../utils/logger');

class FileProcessor {
  static supportedFormats = ['.epub', '.pdf', '.txt', '.rtf', '.mobi', '.azw', '.azw3', '.cbr', '.cbz'];

  static async extractText(file) {
    const ext = path.extname(file.originalname || file.filename).toLowerCase();
    const filePath = file.path || file.filepath;

    if (!this.supportedFormats.includes(ext)) {
      throw new Error(`不支持的文件格式: ${ext}`);
    }

    if (!await fs.pathExists(filePath)) {
      throw new Error(`文件不存在: ${filePath}`);
    }

    try {
      logger.info(`开始提取文本: ${file.originalname || file.filename} (${ext})`);

      let content = '';
      switch (ext) {
        case '.txt':
          content = await this.extractFromTxt(filePath);
          break;
        case '.pdf':
          content = await this.extractFromPdf(filePath);
          break;
        case '.epub':
          // 使用新的、更可靠的 EPUB 解析库
          content = await this.extractFromEpub(filePath);
          break;
        case '.rtf':
          content = await this.extractFromRtf(filePath);
          break;
        case '.mobi':
        case '.azw':
        case '.azw3':
          content = await this.extractFromMobi(filePath);
          break;
        case '.cbr':
        case '.cbz':
          content = await this.extractFromComic(filePath, ext);
          break;
        default:
          throw new Error(`不支持的文件格式: ${ext}`);
      }

      logger.info(`文本提取完成: ${file.originalname || file.filename}`);
      return content;
    } catch (error) {
      logger.error(`文本提取失败 (${ext}):`, error.message);
      throw new Error(`处理文件 ${file.originalname || file.filename} 失败: 文本提取失败: ${error.message}`);
    }
  }

  static async extractFromTxt(filePath) {
    const content = await fs.readFile(filePath, 'utf-8');
    return this.cleanText(content);
  }

  static async extractFromPdf(filePath) {
    const dataBuffer = await fs.readFile(filePath);
    const data = await pdfParse(dataBuffer);
    return this.cleanText(data.text);
  }

  static async extractFromEpub(filePath) {
    try {
      const parser = new EpubParser(filePath);
      const book = await parser.parse();

      let content = '';
      if (!book.sections || book.sections.length === 0) {
        return 'EPUB文件中未找到章节内容';
      }

      for (const section of book.sections) {
        if (section.html) {
          content += this.cleanHtml(section.html) + '\n\n';
        }
      }

      if (!content.trim()) {
        return 'EPUB文件中未找到有效文本内容';
      }

      return this.cleanText(content);
    } catch (error) {
      throw new Error(`EPUB解析失败: ${error.message}`);
    }
  }
  
  static async extractFromRtf(filePath) {
    const data = await mammoth.extractRawText({ path: filePath });
    return this.cleanText(data.value);
  }

  static async extractFromMobi(filePath) {
    throw new Error('Mobi格式暂不支持自动文本提取');
  }

  static async extractFromComic(filePath, ext) {
    throw new Error(`漫画书格式 (${ext}) 不支持文本提取`);
  }

  static cleanHtml(html) {
    let text = html.replace(/<[^>]+>/g, '');
    text = text.replace(/&nbsp;/g, ' ');
    text = text.replace(/&amp;/g, '&');
    return text;
  }

  static cleanText(text) {
    return text
      .replace(/\n\s*\n/g, '\n\n') // 移除多余的空行
      .replace(/[^\S\n]+$/gm, '') // 移除行尾空白
      .trim();
  }

  static async getFileInfo(filePath) {
    try {
      const stats = await fs.stat(filePath);
      const ext = path.extname(filePath).toLowerCase();
      
      return {
        size: stats.size,
        format: ext,
        created: stats.birthtime,
        modified: stats.mtime,
        isSupported: this.supportedFormats.includes(ext)
      };
    } catch (error) {
      throw new Error(`获取文件信息失败: ${error.message}`);
    }
  }

  static async validateFile(filePath, maxSize = 100 * 1024 * 1024) {
    try {
      const fileInfo = await this.getFileInfo(filePath);
      
      if (!fileInfo.isSupported) {
        throw new Error(`不支持的文件格式: ${fileInfo.format}`);
      }
      
      if (fileInfo.size > maxSize) {
        throw new Error(`文件过大: ${fileInfo.size} bytes (最大: ${maxSize} bytes)`);
      }
      
      if (fileInfo.size === 0) {
        throw new Error('文件为空');
      }
      
      return fileInfo;
    } catch (error) {
      throw error;
    }
  }

  static getSupportedFormats() {
    return {
      formats: this.supportedFormats,
      descriptions: {
        '.epub': 'EPUB电子书',
        '.pdf': 'PDF文档',
        '.txt': '纯文本文件',
        '.rtf': '富文本文件',
        '.mobi': 'MOBI电子书',
        '.azw': 'Kindle电子书',
        '.azw3': 'Kindle电子书',
        '.cbr': '漫画书（RAR压缩）',
        '.cbz': '漫画书（ZIP压缩）',
      }
    };
  }
}

module.exports = FileProcessor;
