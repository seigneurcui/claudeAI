const axios = require('axios');
const logger = require('../utils/logger');

class OllamaService {
  constructor() {
    this.baseURL = process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
    this.timeout = parseInt(process.env.OLLAMA_TIMEOUT) || 300000; // 5分钟超时
    this.maxRetries = parseInt(process.env.OLLAMA_MAX_RETRIES) || 3;
  }

  // 获取可用模型列表
  async getAvailableModels() {
    try {
      logger.info('获取Ollama模型列表');
      const response = await axios.get(`${this.baseURL}/api/tags`, {
        timeout: 10000
      });

      if (!response.data || !response.data.models) {
        throw new Error('无效的模型列表响应');
      }

      const models = response.data.models.map(model => ({
        name: model.name,
        size: model.size,
        modified_at: model.modified_at,
        digest: model.digest,
        details: model.details || {}
      }));

      logger.info(`找到 ${models.length} 个可用模型`);
      return models;
    } catch (error) {
      logger.error('获取Ollama模型失败:', error.message);
      
      if (error.code === 'ECONNREFUSED') {
        throw new Error('无法连接到Ollama服务，请确保Ollama正在运行');
      } else if (error.code === 'ETIMEDOUT') {
        throw new Error('连接Ollama服务超时');
      } else {
        throw new Error(`获取模型列表失败: ${error.message}`);
      }
    }
  }

  // 检查模型是否存在
  async checkModelExists(modelName) {
    try {
      const models = await this.getAvailableModels();
      return models.some(model => model.name === modelName);
    } catch (error) {
      logger.error('检查模型存在性失败:', error);
      return false;
    }
  }

  // 分析文本内容
  async analyzeContent(content, modelName, options = {}) {
    try {
      // 验证模型是否存在
      const modelExists = await this.checkModelExists(modelName);
      if (!modelExists) {
        throw new Error(`模型 ${modelName} 不存在或未安装`);
      }

      // 限制内容长度，避免过长的文本
      const maxLength = options.maxLength || 15000;
      const truncatedContent = content.length > maxLength 
        ? content.substring(0, maxLength) + '...[内容已截断]'
        : content;

      logger.info(`开始分析内容，模型: ${modelName}，内容长度: ${truncatedContent.length}`);

      // 构建分析提示
      const prompt = this.buildAnalysisPrompt(truncatedContent, options);
      
      // 发送请求到Ollama
      const analysisResult = await this.sendAnalysisRequest(modelName, prompt, options);
      
      // 解析响应
      const parsedResult = this.parseAnalysisResponse(analysisResult, content);
      
      logger.info('内容分析完成');
      return parsedResult;

    } catch (error) {
      logger.error('Ollama分析失败:', error);
      throw new Error(`内容分析失败: ${error.message}`);
    }
  }

  // 构建分析提示词
  buildAnalysisPrompt(content, options = {}) {
    const language = options.language || 'zh-CN';
    const maxKeywords = options.maxKeywords || 10;
    const maxSummaryLength = options.maxSummaryLength || 200;

    let prompt = '';
    
    if (language === 'zh-CN') {
      prompt = `
请仔细分析以下文本内容，并提供结构化的分析结果。请务必按照JSON格式返回结果：

分析要求：
1. 提取文本的核心主题（作为思维导图的中心节点）
2. 识别主要章节或重要部分（作为主要分支，最多6个）
3. 为每个主要分支提供2-4个子概念
4. 提取关键词（不超过${maxKeywords}个）
5. 生成内容摘要（不超过${maxSummaryLength}字）

请严格按照以下JSON格式返回：
{
  "central_topic": "文档的核心主题",
  "main_branches": [
    {
      "title": "主要分支标题",
      "description": "分支详细描述",
      "sub_branches": ["子概念1", "子概念2", "子概念3"]
    }
  ],
  "keywords": ["关键词1", "关键词2", "关键词3"],
  "summary": "文档内容的简洁摘要"
}

文本内容：
${content}

请仅返回JSON格式的结果，不要包含其他说明文字。
      `;
    } else {
      prompt = `
Please analyze the following text content and provide a structured analysis. Return the result in JSON format only:

Analysis Requirements:
1. Extract the core topic (for mind map center node)
2. Identify main sections or important parts (as main branches, max 6)
3. Provide 2-4 sub-concepts for each main branch
4. Extract keywords (max ${maxKeywords})
5. Generate content summary (max ${maxSummaryLength} words)

Return strictly in this JSON format:
{
  "central_topic": "Core topic of the document",
  "main_branches": [
    {
      "title": "Main branch title",
      "description": "Branch description",
      "sub_branches": ["Sub-concept 1", "Sub-concept 2", "Sub-concept 3"]
    }
  ],
  "keywords": ["keyword1", "keyword2", "keyword3"],
  "summary": "Concise summary of the document content"
}

Text content:
${content}

Return only the JSON result, no additional explanation.
      `;
    }

    return prompt;
  }

  // 发送分析请求
  async sendAnalysisRequest(modelName, prompt, options = {}) {
    const requestOptions = {
      model: modelName,
      prompt: prompt,
      stream: false,
      options: {
        temperature: options.temperature || 0.3,
        top_p: options.top_p || 0.8,
        top_k: options.top_k || 40,
        repeat_penalty: options.repeat_penalty || 1.1,
        num_ctx: options.num_ctx || 4096
      }
    };

    let attempt = 0;
    while (attempt < this.maxRetries) {
      try {
        logger.info(`发送分析请求，尝试 ${attempt + 1}/${this.maxRetries}`);
        
        const response = await axios.post(`${this.baseURL}/api/generate`, requestOptions, {
          timeout: this.timeout,
          headers: {
            'Content-Type': 'application/json'
          }
        });

        if (!response.data || !response.data.response) {
          throw new Error('收到无效的响应数据');
        }

        return response.data.response;

      } catch (error) {
        attempt++;
        logger.warn(`分析请求失败，尝试 ${attempt}/${this.maxRetries}:`, error.message);
        
        if (attempt >= this.maxRetries) {
          if (error.code === 'ECONNREFUSED') {
            throw new Error('无法连接到Ollama服务');
          } else if (error.code === 'ETIMEDOUT') {
            throw new Error('分析请求超时，请尝试使用更小的模型或减少文本长度');
          } else {
            throw new Error(`分析请求失败: ${error.message}`);
          }
        }
        
        // 等待后重试
        await this.delay(1000 * attempt);
      }
    }
  }

  // 解析分析响应
  parseAnalysisResponse(responseText, originalContent) {
    try {
      // 尝试直接解析JSON
      let jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        
        // 验证必需字段
        if (this.validateAnalysisResult(parsed)) {
          return this.sanitizeAnalysisResult(parsed);
        }
      }

      logger.warn('JSON解析失败，使用备用解析方法');
      return this.createFallbackAnalysis(responseText, originalContent);

    } catch (parseError) {
      logger.error('响应解析失败:', parseError);
      return this.createFallbackAnalysis(responseText, originalContent);
    }
  }

  // 验证分析结果
  validateAnalysisResult(result) {
    return (
      result &&
      typeof result === 'object' &&
      typeof result.central_topic === 'string' &&
      Array.isArray(result.main_branches) &&
      Array.isArray(result.keywords) &&
      typeof result.summary === 'string' &&
      result.central_topic.trim().length > 0 &&
      result.main_branches.length > 0 &&
      result.keywords.length > 0 &&
      result.summary.trim().length > 0
    );
  }

  // 清理分析结果
  sanitizeAnalysisResult(result) {
    return {
      central_topic: this.sanitizeText(result.central_topic, 100),
      main_branches: result.main_branches.slice(0, 6).map(branch => ({
        title: this.sanitizeText(branch.title || '未命名分支', 80),
        description: this.sanitizeText(branch.description || '', 200),
        sub_branches: (branch.sub_branches || [])
          .filter(sub => sub && typeof sub === 'string')
          .slice(0, 4)
          .map(sub => this.sanitizeText(sub, 60))
      })),
      keywords: result.keywords
        .filter(keyword => keyword && typeof keyword === 'string')
        .slice(0, 10)
        .map(keyword => this.sanitizeText(keyword, 30)),
      summary: this.sanitizeText(result.summary, 500)
    };
  }

  // 创建备用分析结果
  createFallbackAnalysis(responseText, originalContent) {
    logger.info('创建备用分析结果');
    
    // 从原始内容中提取关键词
    const words = originalContent
      .toLowerCase()
      .replace(/[^\w\s\u4e00-\u9fff]/g, ' ')
      .split(/\s+/)
      .filter(word => word.length > 2)
      .slice(0, 200);

    // 统计词频
    const wordCount = {};
    words.forEach(word => {
      wordCount[word] = (wordCount[word] || 0) + 1;
    });

    // 获取高频词作为关键词
    const keywords = Object.entries(wordCount)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 8)
      .map(([word]) => word)
      .filter(word => word.length > 2);

    return {
      central_topic: "文档内容分析",
      main_branches: [
        {
          title: "主要内容",
          description: "文档的核心信息和主要观点",
          sub_branches: keywords.slice(0, 3)
        },
        {
          title: "关键概念",
          description: "文档中的重要概念和术语",
          sub_branches: keywords.slice(3, 6)
        },
        {
          title: "详细信息",
          description: "补充说明和具体细节",
          sub_branches: keywords.slice(6, 8)
        }
      ],
      keywords: keywords,
      summary: originalContent.substring(0, 200) + (originalContent.length > 200 ? '...' : '')
    };
  }

  // 文本清理工具
  sanitizeText(text, maxLength) {
    if (!text || typeof text !== 'string') {
      return '';
    }
    
    return text
      .replace(/\s+/g, ' ')
      .trim()
      .substring(0, maxLength);
  }

  // 延迟工具
  async delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // 健康检查
  async healthCheck() {
    try {
      const response = await axios.get(`${this.baseURL}/api/tags`, {
        timeout: 5000
      });
      return response.status === 200;
    } catch (error) {
      logger.error('Ollama健康检查失败:', error.message);
      return false;
    }
  }

  // 获取模型信息
  async getModelInfo(modelName) {
    try {
      const response = await axios.post(`${this.baseURL}/api/show`, {
        name: modelName
      }, {
        timeout: 10000
      });
      
      return response.data;
    } catch (error) {
      logger.error(`获取模型信息失败 ${modelName}:`, error.message);
      throw new Error(`无法获取模型信息: ${error.message}`);
    }
  }
}

module.exports = new OllamaService();