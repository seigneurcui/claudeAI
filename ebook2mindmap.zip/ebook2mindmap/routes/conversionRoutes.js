



const express = require('express');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const http = require('http');
const fs = require('fs-extra');
const { Pool } = require('pg');
const FileProcessor = require('../processors/fileProcessor');
const { validateConversionRequest } = require('../middleware/validation');

const router = express.Router();

// PostgreSQL connection
// PostgreSQL connection
const pool = new Pool({
  user: process.env.PG_USER || 'postgres',
  host: process.env.PG_HOST || '127.0.0.1',
  database: process.env.PG_DATABASE || 'ebook_mindmap',
  password: process.env.PG_PASSWORD || 'postgres',
  port: process.env.PG_PORT || 6432,
});


// File upload configuration
const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, `${file.fieldname}-${uniqueSuffix}${ext}`);
  }
});

const upload = multer({ 
  storage: storage,
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.epub', '.mobi', '.azw', '.azw3', '.pdf', '.txt', '.rtf', '.cbr', '.cbz'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error(`不支持的文件格式: ${ext}`), false);
    }
  },
  limits: { fileSize: 100 * 1024 * 1024 } // 100MB
});

// Conversion request handler
router.post('/', upload.array('files', 10), validateConversionRequest, async (req, res) => {
  const jobId = uuidv4();
  console.log(`开始转换任务 ${jobId}，文件数: ${req.files.length}，模型: ${req.body.model}`);

  const { model } = req.body;
  const startTime = new Date();
  const results = [];

  // Emit task start event
  global.io?.emit('conversion:start', { jobId });

  // Respond to the client immediately
  res.status(200).json({ success: true, jobId, message: '转换任务已启动' });

  for (const file of req.files) {
    try {
      const fileId = uuidv4();
      const jobStartTime = new Date();

      // Emit file processing event
      global.io?.emit('conversion:progress', {
        jobId,
        fileId,
        filename: file.originalname,
        status: 'processing',
        progress: 0,
        message: '开始处理文件...'
      });

      // 1. 提取文本内容
      const textContent = await FileProcessor.extractText(file);
      const textChunk = textContent.length > 5000 ? textContent.substring(0, 5000) + '...' : textContent;
      console.log(`文本提取完成: ${file.originalname} (${textChunk.length} 个字符)`);
      
      const prompt = `请将以下文本内容提取关键信息，并将其转化为一个结构清晰的Markdown格式思维导图。请使用中文，并尽量保持简洁。
      文本内容:
      
      ${textContent}`;

      const postData = JSON.stringify({
        model: model,
        prompt: prompt,
        stream: false,
      });

      const options = {
        hostname: '127.0.0.1',
        port: 11434,
        path: '/api/generate',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData),
        },
        timeout: 120000, // 120 seconds timeout
      };

      // 2. 将文本发送到 Ollama 服务
      const ollamaResponse = await new Promise((resolve, reject) => {
        const req = http.request(options, (res) => {
          let responseData = '';
          res.setEncoding('utf8');
          res.on('data', (chunk) => {
            responseData += chunk;
          });
          res.on('end', () => {
            try {
              const parsed = JSON.parse(responseData);
              resolve(parsed);
            } catch (e) {
              reject(new Error(`无效的JSON响应: ${responseData}`));
            }
          });
        });

        req.on('error', (e) => {
          reject(e);
        });

        req.on('timeout', () => {
          req.destroy();
          reject(new Error('请求超时'));
        });

        req.write(postData);
        req.end();
      });

      // 3. 处理 Ollama 响应
      if (ollamaResponse.error) {
        throw new Error(ollamaResponse.error);
      }

      const mindmapMarkdown = ollamaResponse.response;

      // 4. 保存转换结果
      const conversionEndTime = new Date();
      const duration = Math.round((conversionEndTime - jobStartTime) / 1000);
      const outputFilename = path.basename(file.originalname, path.extname(file.originalname));
      const outputPath = `outputs/${outputFilename}-${uuidv4()}`;

      // (此处省略了生成图片和PDF的代码，以保持简洁)
      const result = {
        id: fileId,
        filename: file.originalname,
        mindmapMarkdown: mindmapMarkdown,
        status: 'completed',
        duration: duration,
        mindmapPaths: {
          imagePath: '', // 示例路径
          pdfPath: '',   // 示例路径
        },
      };

      // Save to PostgreSQL
      await pool.query(
        `INSERT INTO conversions (job_id, file_id, filename, original_format, file_size, model_used, content_text, mindmap_data, conversion_status, start_time, end_time, duration_seconds)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
        [
          jobId,
          result.id,
          file.originalname,
          path.extname(file.originalname).toLowerCase(),
          file.size,
          model,
          textContent,
          JSON.stringify({ markdown: mindmapMarkdown }), // 修复：将Markdown文本封装为JSON对象
          result.status,
          jobStartTime,
          conversionEndTime,
          result.duration,
        ]
      );
      results.push(result);

      // Emit progress event
      global.io?.emit('conversion:progress', {
        jobId,
        fileId,
        filename: file.originalname,
        status: 'completed',
        progress: 100,
        message: '转换成功！'
      });

    } catch (error) {
      console.error(`处理文件 ${file.originalname} 失败:`, error.message);
      const result = {
        id: uuidv4(),
        filename: file.originalname,
        status: 'failed',
        error: error.message,
        duration: 0,
      };

      // Save error to PostgreSQL
      await pool.query(
        `INSERT INTO conversions (job_id, file_id, filename, original_format, file_size, model_used, conversion_status, start_time, end_time, duration_seconds, error_message)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
        [
          jobId,
          result.id,
          file.originalname,
          path.extname(file.originalname).toLowerCase(),
          file.size,
          model,
          result.status,
          startTime,
          new Date(),
          result.duration,
          result.error,
        ]
      );
      results.push(result);
      global.io?.emit('conversion:error', {
        jobId,
        fileId: result.id,
        filename: file.originalname,
        error: error.message,
      });
    } finally {
      // Clean up uploaded file
      await fs.remove(file.path);
    }
  }

  const endTime = new Date();
  const totalDuration = Math.round((endTime - startTime) / 1000);

  console.log(`转换任务完成 ${jobId}，总耗时: ${totalDuration}秒`);

  // Emit complete event
  global.io?.emit('conversion:complete', {
    jobId,
    results,
    totalDuration,
    successCount: results.filter(r => r.status === 'completed').length,
    failCount: results.filter(r => r.status === 'failed').length
  });
});

module.exports = router;
