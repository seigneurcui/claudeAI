

// routes/historyRoutes.js
const express = require('express');
const { Pool } = require('pg');
const router = express.Router();
const pool = new Pool({
  user: process.env.PG_USER || 'postgres',
  host: process.env.PG_HOST || '127.0.0.1',
  database: process.env.PG_DATABASE || 'ebook_mindmap',
  password: process.env.PG_PASSWORD || 'postgres',
  port: process.env.PG_PORT || 6432,
});


// 获取历史记录
router.get('/', async (req, res) => {
  try {
    const { keyword = '', startDate = '', endDate = '' } = req.query;
    let query = 'SELECT * FROM conversions WHERE 1=1';
    const params = [];

    if (keyword) {
      query += ' AND filename ILIKE $1';
      params.push(`%${keyword}%`);
    }
    if (startDate) {
      query += ` AND end_time >= $${params.length + 1}`;
      params.push(startDate);
    }
    if (endDate) {
      query += ` AND end_time <= $${params.length + 1}`;
      params.push(endDate);
    }

    query += ' ORDER BY end_time DESC LIMIT 50';

    const { rows } = await pool.query(query, params);
    const formattedRows = rows.map(row => ({
      id: row.id,
      filename: row.filename,
      format: row.original_format,
      model: row.model_used,
      status: row.conversion_status,
      duration: row.duration_seconds,
      startTime: row.start_time,
      endTime: row.end_time,
      errorMessage: row.error_message,
    }));

    res.json({ success: true, history: formattedRows });
  } catch (error) {
    console.error('获取历史记录失败:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 获取统计信息
router.get('/stats/summary', async (req, res) => {
  try {
    const statsQuery = `
      SELECT 
        COUNT(*) as total_conversions,
        COUNT(*) FILTER (WHERE conversion_status = 'completed') as successful_conversions,
        COUNT(*) FILTER (WHERE conversion_status = 'failed') as failed_conversions,
        AVG(duration_seconds) as average_processing_time,
        (SELECT model_used FROM conversions GROUP BY model_used ORDER BY COUNT(*) DESC LIMIT 1) as most_used_model,
        (SELECT original_format FROM conversions GROUP BY original_format ORDER BY COUNT(*) DESC LIMIT 1) as most_converted_format,
        COUNT(*) FILTER (WHERE DATE(end_time) = CURRENT_DATE) as today_conversions
      FROM conversions
    `;
    const dbSizeQuery = `
      SELECT pg_size_pretty(pg_database_size($1)) as database_size
    `;
    
    const [statsResult, dbSizeResult] = await Promise.all([
      pool.query(statsQuery),
      pool.query(dbSizeQuery, ['ebook_mindmap'])
    ]);

    const stats = statsResult.rows[0];
    const databaseSize = dbSizeResult.rows[0].database_size;

    res.json({
      success: true,
      stats: {
        totalConversions: parseInt(stats.total_conversions),
        successfulConversions: parseInt(stats.successful_conversions),
        failedConversions: parseInt(stats.failed_conversions),
        averageProcessingTime: Math.round(parseFloat(stats.average_processing_time) || 0),
        mostUsedModel: stats.most_used_model || null,
        mostConvertedFormat: stats.most_converted_format || null,
        todayConversions: parseInt(stats.today_conversions),
        databaseSize
      }
    });
  } catch (error) {
    console.error('获取统计信息失败:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
