// routes/exportRoutes.js
const express = require('express');
const router = express.Router();

router.get('/excel', (req, res) => {
  res.status(501).json({
    error: '导出功能正在开发中',
    message: 'Excel导出功能即将推出'
  });
});

module.exports = router;
