const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs-extra');
const logger = require('../utils/logger');

// 处理下载请求，根据文件ID和类型提供文件
router.get('/:id/:type', async (req, res) => {
  const { id, type } = req.params;
  const directory = path.join(__dirname, '..', 'mindmaps');
  let filePath;

  // 根据类型设置文件路径和内容类型
  switch (type) {
    case 'image':
      filePath = path.join(directory, `${id}.png`);
      res.setHeader('Content-Type', 'image/png');
      break;
    case 'pdf':
      filePath = path.join(directory, `${id}.pdf`);
      res.setHeader('Content-Type', 'application/pdf');
      break;
    default:
      // 如果类型不被支持，返回400错误
      logger.error(`请求了不支持的下载类型: ${type}`);
      return res.status(400).json({ success: false, error: '不支持的下载类型' });
  }

  try {
    // 检查文件是否存在
    if (await fs.pathExists(filePath)) {
      logger.info(`提供文件下载：${filePath}`);
      // 发送文件
      res.sendFile(filePath);
    } else {
      // 文件不存在则返回404
      logger.error(`请求的文件不存在：${filePath}`);
      res.status(404).json({ success: false, error: '文件不存在' });
    }
  } catch (err) {
    // 处理文件发送过程中的错误
    logger.error(`处理下载请求时出错：${err.message}`);
    res.status(500).json({ success: false, error: '服务器内部错误' });
  }
});

module.exports = router;

