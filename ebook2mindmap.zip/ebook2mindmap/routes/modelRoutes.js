const express = require('express');
const http = require('http');
const router = express.Router();

const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434';

async function fetchOllamaModels(retries = 3, delay = 1000) {
  for (let i = 0; i < retries; i++) {
    try {
      console.log(`Attempt ${i + 1}: Connecting to Ollama at ${OLLAMA_BASE_URL}/api/tags`);
      const data = await new Promise((resolve, reject) => {
        const options = {
          hostname: '127.0.0.1',
          port: 11434,
          path: '/api/tags',
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'User-Agent': 'ebook2mindmap/1.0.0',
          },
          timeout: 5000,
        };

        const req = http.get(options, (res) => {
          let body = '';
          res.on('data', chunk => body += chunk);
          res.on('end', () => {
            try {
              const parsed = JSON.parse(body);
              console.log('Ollama 响应数据:', JSON.stringify(parsed, null, 2));
              resolve(parsed);
            } catch (e) {
              reject(new Error('Invalid JSON response'));
            }
          });
        });

        req.on('error', (error) => {
          console.error(`Attempt ${i + 1} error:`, error);
          reject(error);
        });

        req.on('timeout', () => {
          req.destroy();
          reject(new Error('Request timeout'));
        });

        req.end();
      });

      if (!data || !data.models) {
        throw new Error('无效的模型列表响应');
      }
      return data;
    } catch (error) {
      console.error(`Attempt ${i + 1} failed: ${error.message}`, error);
      if (i === retries - 1) {
        return { models: [], error: 'Ollama service unavailable' };
      }
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}

router.get('/', async (req, res) => {
  try {
    console.log('获取Ollama模型列表请求');
    const data = await fetchOllamaModels();
    
    if (data.error) {
      return res.status(503).json({
        success: false,
        error: '获取模型列表失败',
        code: 'OLLAMA_UNAVAILABLE',
        details: data.error,
        timestamp: new Date().toISOString(),
      });
    }

    const models = data.models.map(model => ({
      name: model.name,
      size: model.size || 0,
      modified_at: model.modified_at,
      digest: model.digest,
      parameter_size: model.details?.parameter_size || 'Unknown',
      quantization: model.details?.quantization_level || 'Unknown',
    }));

    console.log(`找到 ${models.length} 个可用模型`);
    
    res.json({
      success: true,
      count: models.length,
      models,
      source: 'ollama',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('获取模型列表失败:', error.message, error);
    let errorMessage = '获取模型列表失败';
    let statusCode = 500;
    let errorCode = error.code || 'MODEL_FETCH_ERROR';

    if (error.message.includes('ECONNREFUSED')) {
      errorMessage = '无法连接到Ollama服务，请确保Ollama正在运行';
      statusCode = 503;
      errorCode = 'ECONNREFUSED';
    } else if (error.message.includes('timeout') || error.message.includes('socket hang up')) {
      errorMessage = '连接Ollama服务失败';
      statusCode = 504;
    }

    res.status(statusCode).json({
      success: false,
      error: errorMessage,
      code: errorCode,
      details: error.message,
      timestamp: new Date().toISOString(),
    });
  }
});

router.get('/health', async (req, res) => {
  try {
    console.log('Ollama健康检查请求');
    const data = await fetchOllamaModels(1, 0);
    
    if (data.error) {
      return res.status(503).json({
        success: false,
        status: 'unhealthy',
        ollama_connected: false,
        error: data.error,
        timestamp: new Date().toISOString(),
      });
    }

    res.json({
      success: true,
      status: 'healthy',
      ollama_connected: true,
      models_count: data.models.length,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Ollama健康检查失败:', error.message, error);
    res.status(503).json({
      success: false,
      status: 'unhealthy',
      ollama_connected: false,
      error: error.message,
      timestamp: new Date().toISOString(),
    });
  }
});

module.exports = router;
