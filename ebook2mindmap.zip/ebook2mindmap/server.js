require('dotenv').config();
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const morgan = require('morgan');
const helmet = require('helmet');
const fs = require('fs-extra');
const path = require('path');

// 创建Express应用
const app = express();
const server = http.createServer(app);

// Socket.IO配置
const io = socketIo(server, {
  cors: {
    origin: process.env.CORS_ORIGIN || "*",
    methods: ["GET", "POST"]
  }
});

// 全局Socket.IO实例
global.io = io;

// 基础中间件
app.use(cors());
app.use(morgan('dev'));
app.use(helmet({
  contentSecurityPolicy: false // 临时禁用CSP以避免开发时的问题
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// 请求日志中间件
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path} - ${req.ip}`);
  next();
});

// 静态文件服务
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));
app.use('/mindmaps', express.static('mindmaps'));

// 导入路由
const modelRoutes = require('./routes/modelRoutes');
const conversionRoutes = require('./routes/conversionRoutes');
const historyRoutes = require('./routes/historyRoutes');
const downloadRoutes = require('./routes/downloadRoutes');
const exportRoutes = require('./routes/exportRoutes');

// 路由挂载
app.use('/api/models', modelRoutes);
app.use('/api/convert', conversionRoutes);
app.use('/api/history', historyRoutes);
app.use('/download', downloadRoutes);
app.use('/api/export', exportRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    uptime: process.uptime()
  });
});

// 404处理
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Route not found',
    path: req.originalUrl
  });
});

// 错误处理中间件
app.use((err, req, res, next) => {
  console.error('应用错误:', err);

  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({
      error: '文件过大',
      maxSize: '100MB'
    });
  }

  res.status(err.status || 500).json({
    error: '服务器内部错误',
    message: process.env.NODE_ENV === 'development' ? err.message : '服务暂时不可用'
  });
});

// Socket.IO连接处理
io.on('connection', (socket) => {
  console.log(`Socket连接建立: ${socket.id}`);

  socket.on('disconnect', () => {
    console.log(`Socket断开连接: ${socket.id}`);
  });
});

// 创建必要的目录
async function createDirectories() {
  const directories = ['uploads', 'mindmaps', 'logs', 'temp'];

  for (const dir of directories) {
    await fs.ensureDir(dir);
    console.log(`目录创建/确认: ${dir}`);
  }
}

// 启动服务器
async function startServer() {
  try {
    await createDirectories();

    const PORT = process.env.PORT || 9066;
    server.listen(PORT, () => {
      console.log(`服务器运行在 http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('启动服务器失败:', err);
    process.exit(1);
  }
}

startServer();

