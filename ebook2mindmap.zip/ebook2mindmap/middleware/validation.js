const validateConversionRequest = (req, res, next) => {
  const { model } = req.body;

  if (!model) {
    return res.status(400).json({
      error: '请选择AI模型'
    });
  }

  next();
};

module.exports = { validateConversionRequest };
