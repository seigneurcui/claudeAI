const logger = require('../utils/logger');

/**
 * Middleware de manejo de errores centralizado.
 * Captura los errores que ocurren en la aplicación, los registra
 * y envía una respuesta de error JSON estandarizada al cliente.
 */
const errorHandler = (err, req, res, next) => {
  // Registrar el error completo para depuración
  logger.error(`${err.status || 500} - ${err.message} - ${req.originalUrl} - ${req.method} - ${req.ip}`, {
    error: {
      message: err.message,
      stack: err.stack,
    },
  });

  const statusCode = err.statusCode || 500;
  const response = {
    success: false,
    error: 'Error interno del servidor',
    code: err.code || 'INTERNAL_ERROR',
    // En desarrollo, incluir más detalles para facilitar la depuración
    ...(process.env.NODE_ENV !== 'production' && { message: err.message, stack: err.stack }),
  };

  res.status(statusCode).json(response);
};

module.exports = errorHandler;
