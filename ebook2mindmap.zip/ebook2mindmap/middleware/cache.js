// middleware/cache.js - 缓存中间件
const NodeCache = require('node-cache');
const logger = require('../utils/logger');

// 创建缓存实例
const cache = new NodeCache({
  stdTTL: 600, // 默认缓存10分钟
  checkperiod: 60, // 每60秒检查一次过期的key
  useClones: false
});

// 缓存中间件
const cacheMiddleware = (duration = 600) => {
  return (req, res, next) => {
    // 只对GET请求进行缓存
    if (req.method !== 'GET') {
      return next();
    }

    const key = req.originalUrl || req.url;
    const cachedResponse = cache.get(key);

    if (cachedResponse) {
      logger.debug(`缓存命中: ${key}`);
      return res.json(cachedResponse);
    }

    // 覆盖res.json方法以缓存响应
    const originalJson = res.json;
    res.json = function(body) {
      res.json = originalJson;
      
      // 只缓存成功的响应
      if (res.statusCode === 200) {
        cache.set(key, body, duration);
        logger.debug(`缓存设置: ${key}`);
      }
      
      return originalJson.call(this, body);
    };

    next();
  };
};

// 清除缓存
const clearCache = (pattern) => {
  if (pattern) {
    const keys = cache.keys().filter(key => key.includes(pattern));
    keys.forEach(key => cache.del(key));
    logger.info(`清除缓存模式: ${pattern}, 清除数量: ${keys.length}`);
  } else {
    cache.flushAll();
    logger.info('清除所有缓存');
  }
};

// 获取缓存统计
const getCacheStats = () => {
  return {
    keys: cache.keys().length,
    stats: cache.getStats()
  };
};

module.exports = {
  cache,
  cacheMiddleware,
  clearCache,
  getCacheStats
};
