const fs = require('fs-extra');
const path = require('path');
const epub = require('epub2');
const pdfParse = require('pdf-parse');
const unzipper = require('unzipper');
const mammoth = require('mammoth');
const logger = require('../utils/logger');

class FileProcessor {
  static supportedFormats = ['.epub', '.pdf', '.txt', '.rtf', '.mobi', '.azw', '.azw3', '.cbr', '.cbz'];
  
  static async extractText(file) {
    const ext = path.extname(file.originalname || file.filename).toLowerCase();
    const filePath = file.path || file.filepath;
    
    if (!this.supportedFormats.includes(ext)) {
      throw new Error(`不支持的文件格式: ${ext}`);
    }

    if (!await fs.pathExists(filePath)) {
      throw new Error(`文件不存在: ${filePath}`);
    }

    try {
      logger.info(`开始提取文本: ${file.originalname || file.filename} (${ext})`);
      
      let content = '';
      switch (ext) {
        case '.txt':
          content = await this.extractFromTxt(filePath);
          break;
        case '.pdf':
          content = await this.extractFromPdf(filePath);
          break;
        case '.epub':
          content = await this.extractFromEpub(filePath);
          break;
        case '.rtf':
          content = await this.extractFromRtf(filePath);
          break;
        case '.mobi':
        case '.azw':
        case '.azw3':
          content = await this.extractFromKindle(filePath, ext);
          break;
        case '.cbr':
        case '.cbz':
          content = await this.extractFromComic(filePath, ext);
          break;
        default:
          throw new Error(`处理器未实现: ${ext}`);
      }

      if (!content || content.trim().length === 0) {
        throw new Error('文件中未找到有效文本内容');
      }

      logger.info(`文本提取完成: ${content.length} 个字符`);
      return content.trim();

    } catch (error) {
      logger.error(`文本提取失败 (${ext}):`, error);
      throw new Error(`文本提取失败: ${error.message}`);
    }
  }

  static async extractFromTxt(filePath) {
    try {
      const content = await fs.readFile(filePath, 'utf8');
      return this.cleanText(content);
    } catch (error) {
      // 尝试其他编码
      try {
        const buffer = await fs.readFile(filePath);
        const content = buffer.toString('latin1');
        return this.cleanText(content);
      } catch (secondError) {
        throw new Error('无法读取TXT文件，可能是编码问题');
      }
    }
  }

  static async extractFromPdf(filePath) {
    try {
      const dataBuffer = await fs.readFile(filePath);
      const options = {
        max: 0, // 处理所有页面
        version: 'v1.10.100' // 指定PDF.js版本
      };
      
      const data = await pdfParse(dataBuffer, options);
      
      if (!data.text || data.text.trim().length === 0) {
        throw new Error('PDF文件中未找到可提取的文本');
      }
      
      return this.cleanText(data.text);
    } catch (error) {
      throw new Error(`PDF处理失败: ${error.message}`);
    }
  }

  static async extractFromEpub(filePath) {
    return new Promise((resolve, reject) => {
      try {
        const book = new epub(filePath);
        let content = '';
        let processedChapters = 0;

        book.on('ready', async () => {
          try {
            const chapters = book.flow;
            
            if (!chapters || chapters.length === 0) {
              resolve('EPUB文件中未找到章节内容');
              return;
            }

            const chapterContents = [];
            
            for (const chapter of chapters) {
              try {
                const chapterText = await new Promise((chapterResolve) => {
                  book.getChapter(chapter.id, (err, text) => {
                    if (err) {
                      logger.warn(`提取章节失败 ${chapter.id}:`, err);
                      chapterResolve('');
                    } else {
                      chapterResolve(text);
                    }
                  });
                });
                
                if (chapterText) {
                  const cleanText = this.cleanHtml(chapterText);
                  chapterContents.push(cleanText);
                }
                
                processedChapters++;
              } catch (chapterError) {
                logger.warn(`处理章节失败: ${chapter.id}`, chapterError);
              }
            }

            content = chapterContents.join('\n\n');
            
            if (!content.trim()) {
              resolve('EPUB文件中未找到有效文本内容');
            } else {
              resolve(this.cleanText(content));
            }
            
          } catch (processingError) {
            reject(new Error(`EPUB处理失败: ${processingError.message}`));
          }
        });

        book.on('error', (error) => {
          reject(new Error(`EPUB解析失败: ${error.message}`));
        });

        // 设置超时
        setTimeout(() => {
          reject(new Error('EPUB处理超时'));
        }, 30000);

        book.parse();
        
      } catch (error) {
        reject(new Error(`EPUB初始化失败: ${error.message}`));
      }
    });
  }

  static async extractFromRtf(filePath) {
    try {
      // 使用mammoth处理RTF文件
      const result = await mammoth.extractRawText({ path: filePath });
      
      if (result.value && result.value.trim().length > 0) {
        return this.cleanText(result.value);
      }
      
      // 如果mammoth失败，尝试简单的文本处理
      const content = await fs.readFile(filePath, 'utf8');
      const cleanedContent = this.cleanRtf(content);
      
      if (!cleanedContent.trim()) {
        throw new Error('RTF文件中未找到有效文本内容');
      }
      
      return cleanedContent;
    } catch (error) {
      throw new Error(`RTF处理失败: ${error.message}`);
    }
  }

  static async extractFromKindle(filePath, format) {
    try {
      // Kindle格式需要专门的库，这里提供基础实现
      logger.warn(`${format} 格式需要额外的处理库`);
      
      // 尝试基础文本提取
      const buffer = await fs.readFile(filePath);
      let content = '';
      
      // 简单的文本搜索和提取
      const text = buffer.toString('utf8', 0, Math.min(buffer.length, 100000));
      const textMatch = text.match(/[\x20-\x7E\u4e00-\u9fff\s]{10,}/g);
      
      if (textMatch && textMatch.length > 0) {
        content = textMatch.join(' ');
      }
      
      if (!content.trim()) {
        return `这是一个 ${format.toUpperCase()} 格式文件。由于格式限制，无法完全提取文本内容。建议转换为EPUB或PDF格式后再次尝试。`;
      }
      
      return this.cleanText(content);
    } catch (error) {
      throw new Error(`${format} 处理失败: ${error.message}`);
    }
  }

  static async extractFromComic(filePath, format) {
    try {
      // 漫画文件通常是压缩的图片集合
      const tempDir = path.join(path.dirname(filePath), 'temp_comic');
      await fs.ensureDir(tempDir);
      
      try {
        if (format === '.cbz') {
          // 解压ZIP文件
          await fs.createReadStream(filePath)
            .pipe(unzipper.Extract({ path: tempDir }))
            .promise();
        }
        
        // 检查是否有文本文件
        const files = await fs.readdir(tempDir);
        const textFiles = files.filter(file => 
          ['.txt', '.nfo', '.xml'].includes(path.extname(file).toLowerCase())
        );
        
        let content = '';
        for (const textFile of textFiles) {
          const textContent = await fs.readFile(path.join(tempDir, textFile), 'utf8');
          content += textContent + '\n';
        }
        
        // 清理临时目录
        await fs.remove(tempDir);
        
        if (!content.trim()) {
          return `这是一个 ${format.toUpperCase()} 格式的漫画文件，主要包含图片内容。如需提取图片中的文字，请使用OCR工具。`;
        }
        
        return this.cleanText(content);
        
      } catch (extractError) {
        await fs.remove(tempDir);
        throw extractError;
      }
    } catch (error) {
      throw new Error(`${format} 处理失败: ${error.message}`);
    }
  }

  // 清理HTML标签
  static cleanHtml(html) {
    return html
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // 移除script标签
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '') // 移除style标签
      .replace(/<[^>]*>/g, ' ') // 移除所有HTML标签
      .replace(/&nbsp;/g, ' ') // 替换&nbsp;
      .replace(/&lt;/g, '<') // 替换HTML实体
      .replace(/&gt;/g, '>')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/\s+/g, ' ') // 压缩多个空白字符
      .trim();
  }

  // 清理RTF格式
  static cleanRtf(rtfContent) {
    return rtfContent
      .replace(/\\[a-z]+\d*/g, '') // 移除RTF控制字
      .replace(/\{[^}]*\}/g, '') // 移除大括号内容
      .replace(/[{}]/g, '') // 移除剩余的大括号
      .replace(/\\/g, '') // 移除反斜杠
      .replace(/\s+/g, ' ') // 压缩空白字符
      .trim();
  }

  // 通用文本清理
  static cleanText(text) {
    return text
      .replace(/\r\n/g, '\n') // 统一换行符
      .replace(/\r/g, '\n')
      .replace(/\n{3,}/g, '\n\n') // 压缩多个换行符
      .replace(/[ \t]+/g, ' ') // 压缩多个空格和制表符
      .replace(/^\s+|\s+$/g, '') // 移除首尾空白
      .replace(/[^\S\n]+$/gm, '') // 移除行尾空白
      .trim();
  }

  // 获取文件信息
  static async getFileInfo(filePath) {
    try {
      const stats = await fs.stat(filePath);
      const ext = path.extname(filePath).toLowerCase();
      
      return {
        size: stats.size,
        format: ext,
        created: stats.birthtime,
        modified: stats.mtime,
        isSupported: this.supportedFormats.includes(ext)
      };
    } catch (error) {
      throw new Error(`获取文件信息失败: ${error.message}`);
    }
  }

  // 验证文件
  static async validateFile(filePath, maxSize = 100 * 1024 * 1024) {
    try {
      const fileInfo = await this.getFileInfo(filePath);
      
      if (!fileInfo.isSupported) {
        throw new Error(`不支持的文件格式: ${fileInfo.format}`);
      }
      
      if (fileInfo.size > maxSize) {
        throw new Error(`文件过大: ${fileInfo.size} bytes (最大: ${maxSize} bytes)`);
      }
      
      if (fileInfo.size === 0) {
        throw new Error('文件为空');
      }
      
      return fileInfo;
    } catch (error) {
      throw error;
    }
  }

  // 获取支持的格式列表
  static getSupportedFormats() {
    return {
      formats: this.supportedFormats,
      descriptions: {
        '.epub': 'EPUB电子书格式',
        '.pdf': 'PDF文档格式',
        '.txt': '纯文本格式',
        '.rtf': '富文本格式',
        '.mobi': 'Mobipocket格式',
        '.azw': 'Amazon Kindle格式',
        '.azw3': 'Amazon KF8格式',
        '.cbr': 'Comic Book RAR格式',
        '.cbz': 'Comic Book ZIP格式'
      }
    };
  }
}

module.exports = FileProcessor;