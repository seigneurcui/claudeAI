const winston = require('winston');
const { createLogger, format, transports } = winston;
const { combine, timestamp, printf, colorize, errors } = format;
const path = require('path');
const fs = require('fs');

// Asegurarse de que el directorio de logs exista
const logDir = 'logs';
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir);
}

// Formato personalizado para los logs de la consola
const consoleFormat = combine(
  colorize(),
  timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  printf(info => `${info.timestamp} ${info.level}: ${info.message}`)
);

// Formato para los logs en archivos
const fileFormat = combine(
  timestamp(),
  errors({ stack: true }), // Incluir stack trace en los errores
  format.json() // Formato JSON para facilitar el análisis
);

const logger = createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: fileFormat,
  transports: [
    // Guardar errores en error.log
    new transports.File({
      filename: path.join(logDir, 'error.log'),
      level: 'error',
    }),
    // Guardar todos los logs de nivel info y superior en combined.log
    new transports.File({
      filename: path.join(logDir, 'combined.log')
    }),
  ],
  exitOnError: false, // No salir en excepciones no manejadas
});

// Si no estamos en producción, también registrar en la consola con un formato más legible
if (process.env.NODE_ENV !== 'production') {
  logger.add(new transports.Console({
    format: consoleFormat,
  }));
}

// Crear un stream para morgan (si se usa para logging de peticiones HTTP)
logger.stream = {
  write: (message) => {
    logger.info(message.substring(0, message.lastIndexOf('\n')));
  },
};

module.exports = logger;
