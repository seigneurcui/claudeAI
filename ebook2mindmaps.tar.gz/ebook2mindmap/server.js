require('dotenv').config();
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const fs = require('fs-extra');
const path = require('path');

// 导入中间件和工具
const logger = require('./utils/logger');
const errorHandler = require('./middleware/errorHandler');
const rateLimiter = require('./middleware/rateLimiter');

// 导入路由
const uploadRoutes = require('./routes/uploadRoutes');
const conversionRoutes = require('./routes/conversionRoutes');
const historyRoutes = require('./routes/historyRoutes');
const downloadRoutes = require('./routes/downloadRoutes');
const exportRoutes = require('./routes/exportRoutes');
const modelRoutes = require('./routes/modelRoutes');

// 导入数据库
const Database = require('./database/connection');

// 创建Express应用
const app = express();
const server = http.createServer(app);

// Socket.IO配置
const io = socketIo(server, {
  cors: {
    origin: process.env.CORS_ORIGIN || "*",
    methods: ["GET", "POST"]
  }
});

// 全局Socket.IO实例
global.io = io;

// 安全中间件
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com"],
      scriptSrc: ["'self'", "https://cdnjs.cloudflare.com"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'", "ws:", "wss:"]
    }
  }
}));

// CORS配置
app.use(cors({
  origin: process.env.CORS_ORIGIN || "*",
  credentials: true
}));

// 基础中间件
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// 请求日志
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.path} - ${req.ip}`);
  next();
});

// 速率限制
app.use('/api/', rateLimiter);

// 静态文件服务
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));
app.use('/mindmaps', express.static('mindmaps'));

// API路由
app.use('/api/models', modelRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/convert', conversionRoutes);
app.use('/api/history', historyRoutes);
app.use('/api/download', downloadRoutes);
app.use('/api/export', exportRoutes);

// 健康检查端点
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    version: process.env.npm_package_version || '1.0.0'
  });
});

// 404处理
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Route not found',
    path: req.originalUrl,
    timestamp: new Date().toISOString()
  });
});

// 错误处理中间件
app.use(errorHandler);

// Socket.IO连接处理
io.on('connection', (socket) => {
  logger.info(`Socket连接建立: ${socket.id}`);
  
  socket.on('join:conversion', (jobId) => {
    socket.join(`conversion:${jobId}`);
    logger.info(`Socket ${socket.id} 加入转换任务: ${jobId}`);
  });
  
  socket.on('disconnect', () => {
    logger.info(`Socket断开连接: ${socket.id}`);
  });
  
  socket.on('error', (error) => {
    logger.error('Socket错误:', error);
  });
});

// 创建必要的目录
async function createDirectories() {
  const directories = [
    'uploads',
    'mindmaps',
    'logs',
    'temp'
  ];
  
  for (const dir of directories) {
    await fs.ensureDir(dir);
    logger.info(`目录创建/确认: ${dir}`);
  }
}

// 优雅关闭处理
function gracefulShutdown(signal) {
  logger.info(`接收到 ${signal} 信号，开始优雅关闭...`);
  
  server.close((err) => {
    if (err) {
      logger.error('服务器关闭错误:', err);
      process.exit(1);
    }
    
    // 关闭数据库连接
    Database.close().then(() => {
      logger.info('数据库连接已关闭');
      logger.info('应用程序已优雅关闭');
      process.exit(0);
    }).catch((err) => {
      logger.error('数据库关闭错误:', err);
      process.exit(1);
    });
  });
  
  // 强制关闭超时
  setTimeout(() => {
    logger.error('强制关闭应用程序');
    process.exit(1);
  }, 10000);
}

// 注册信号处理器
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// 未捕获的异常处理
process.on('uncaughtException', (err) => {
  logger.error('未捕获的异常:', err);
  gracefulShutdown('UNCAUGHT_EXCEPTION');
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('未处理的Promise拒绝:', reason);
  gracefulShutdown('UNHANDLED_REJECTION');
});

// 启动服务器
async function startServer() {
  try {
    // 创建必要目录
    await createDirectories();
    
    // 初始化数据库
    await Database.initialize();
    
    const PORT = process.env.PORT || 9066;
    const HOST = process.env.HOST || 'localhost';
    
    server.listen(PORT, HOST, () => {
      logger.info(`服务器启动成功`);
      logger.info(`地址: http://${HOST}:${PORT}`);
      logger.info(`环境: ${process.env.NODE_ENV || 'development'}`);
      logger.info(`进程ID: ${process.pid}`);
    });
    
  } catch (error) {
    logger.error('服务器启动失败:', error);
    process.exit(1);
  }
}

// 启动应用
startServer();

module.exports = { app, server, io };
