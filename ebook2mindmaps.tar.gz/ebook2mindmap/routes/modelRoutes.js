const express = require('express');
const ollamaService = require('../services/ollamaService');
const logger = require('../utils/logger');
const { cacheMiddleware } = require('../middleware/cache');

const router = express.Router();

// 获取可用模型列表
router.get('/', cacheMiddleware(300), async (req, res) => {
  try {
    logger.info('请求获取Ollama模型列表');
    
    const models = await ollamaService.getAvailableModels();
    
    // 添加模型推荐信息
    const enhancedModels = models.map(model => {
      const modelInfo = getModelRecommendation(model.name);
      return {
        ...model,
        ...modelInfo,
        sizeFormatted: formatBytes(model.size)
      };
    });
    
    // 按推荐度排序
    enhancedModels.sort((a, b) => (b.recommended ? 1 : 0) - (a.recommended ? 1 : 0));
    
    res.json({
      success: true,
      count: enhancedModels.length,
      models: enhancedModels,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    logger.error('获取模型列表失败:', error);
    
    res.status(500).json({
      success: false,
      error: '获取模型列表失败',
      message: error.message,
      suggestions: [
        '请确保Ollama服务正在运行',
        '检查Ollama服务地址配置',
        '验证网络连接是否正常'
      ]
    });
  }
});

// 获取特定模型信息
router.get('/:modelName', async (req, res) => {
  try {
    const { modelName } = req.params;
    
    logger.info(`请求获取模型信息: ${modelName}`);
    
    const modelInfo = await ollamaService.getModelInfo(modelName);
    const recommendation = getModelRecommendation(modelName);
    
    res.json({
      success: true,
      model: {
        ...modelInfo,
        ...recommendation,
        sizeFormatted: formatBytes(modelInfo.size || 0)
      }
    });
    
  } catch (error) {
    logger.error(`获取模型信息失败 ${req.params.modelName}:`, error);
    
    res.status(404).json({
      success: false,
      error: '模型不存在或获取信息失败',
      message: error.message,
      modelName: req.params.modelName
    });
  }
});

// 检查模型是否存在
router.get('/:modelName/exists', async (req, res) => {
  try {
    const { modelName } = req.params;
    
    const exists = await ollamaService.checkModelExists(modelName);
    
    res.json({
      success: true,
      modelName,
      exists,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    logger.error(`检查模型存在性失败 ${req.params.modelName}:`, error);
    
    res.status(500).json({
      success: false,
      error: '检查模型失败',
      message: error.message,
      modelName: req.params.modelName
    });
  }
});

// 获取推荐模型列表
router.get('/recommended/list', async (req, res) => {
  try {
    const allModels = await ollamaService.getAvailableModels();
    
    const recommendedModels = allModels
      .map(model => {
        const recommendation = getModelRecommendation(model.name);
        return {
          ...model,
          ...recommendation,
          sizeFormatted: formatBytes(model.size)
        };
      })
      .filter(model => model.recommended)
      .sort((a, b) => b.priority - a.priority);
    
    res.json({
      success: true,
      count: recommendedModels.length,
      models: recommendedModels,
      message: '推荐模型基于处理速度和准确性平衡'
    });
    
  } catch (error) {
    logger.error('获取推荐模型失败:', error);
    
    res.status(500).json({
      success: false,
      error: '获取推荐模型失败',
      message: error.message
    });
  }
});

// 测试模型性能
router.post('/:modelName/test', async (req, res) => {
  try {
    const { modelName } = req.params;
    const testContent = req.body.content || '这是一个测试文本，用于验证模型的分析能力。';
    
    logger.info(`测试模型性能: ${modelName}`);
    
    const startTime = Date.now();
    
    const result = await ollamaService.analyzeContent(testContent, modelName, {
      maxLength: 1000,
      maxKeywords: 5,
      maxSummaryLength: 100
    });
    
    const endTime = Date.now();
    const duration = endTime - startTime;
    
    res.json({
      success: true,
      modelName,
      testDuration: duration,
      performanceRating: getPerformanceRating(duration),
      result: result,
      recommendations: getPerformanceRecommendations(duration)
    });
    
  } catch (error) {
    logger.error(`模型性能测试失败 ${req.params.modelName}:`, error);
    
    res.status(500).json({
      success: false,
      error: '模型测试失败',
      message: error.message,
      modelName: req.params.modelName
    });
  }
});

// 健康检查
router.get('/health/check', async (req, res) => {
  try {
    const isHealthy = await ollamaService.healthCheck();
    
    if (isHealthy) {
      res.json({
        success: true,
        status: 'healthy',
        message: 'Ollama服务运行正常',
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(503).json({
        success: false,
        status: 'unhealthy',
        message: 'Ollama服务不可用',
        timestamp: new Date().toISOString()
      });
    }
    
  } catch (error) {
    logger.error('Ollama健康检查失败:', error);
    
    res.status(503).json({
      success: false,
      status: 'error',
      message: 'health check failed',
      error: error.message
    });
  }
});

// 获取模型推荐信息
function getModelRecommendation(modelName) {
  const recommendations = {
    'llama2:7b': {
      recommended: true,
      priority: 9,
      description: '平衡的性能和准确性，适合大多数文档',
      pros: ['速度快', '准确性好', '资源占用适中'],
      cons: ['对复杂文档理解有限'],
      useCase: '通用文档分析'
    },
    'llama2:13b': {
      recommended: true,
      priority: 8,
      description: '更好的理解能力，适合复杂文档',
      pros: ['理解能力强', '生成质量高'],
      cons: ['速度较慢', '资源占用大'],
      useCase: '复杂学术文档'
    },
    'mistral:7b': {
      recommended: true,
      priority: 8,
      description: '快速高效，适合批量处理',
      pros: ['处理速度快', '资源效率高'],
      cons: ['中文支持一般'],
      useCase: '英文文档批量处理'
    },
    'qwen:7b': {
      recommended: true,
      priority: 10,
      description: '优秀的中文理解能力',
      pros: ['中文处理优秀', '理解准确'],
      cons: ['英文处理一般'],
      useCase: '中文文档分析'
    },
    'codellama:7b': {
      recommended: false,
      priority: 3,
      description: '专门用于代码分析',
      pros: ['代码理解强'],
      cons: ['文档分析能力有限'],
      useCase: '技术文档和代码'
    }
  };
  
  // 默认推荐信息
  const defaultRecommendation = {
    recommended: false,
    priority: 5,
    description: '通用模型',
    pros: ['可用'],
    cons: ['未经优化测试'],
    useCase: '通用'
  };
  
  return recommendations[modelName] || defaultRecommendation;
}

// 格式化字节大小
function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// 获取性能评级
function getPerformanceRating(duration) {
  if (duration < 5000) return 'excellent';
  if (duration < 15000) return 'good';
  if (duration < 30000) return 'fair';
  return 'poor';
}

// 获取性能建议
function getPerformanceRecommendations(duration) {
  const recommendations = [];
  
  if (duration > 30000) {
    recommendations.push('考虑使用较小的模型以提高处理速度');
    recommendations.push('检查系统资源使用情况');
  } else if (duration > 15000) {
    recommendations.push('当前性能可接受，可考虑批量处理优化');
  } else {
    recommendations.push('性能良好，适合实时处理');
  }
  
  return recommendations;
}

module.exports = router;
