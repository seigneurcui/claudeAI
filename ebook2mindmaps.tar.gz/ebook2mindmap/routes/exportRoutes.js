const express = require('express');
const database = require('../database/connection');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * Convierte un array de objetos JSON a una cadena CSV.
 * @param {Array<Object>} jsonArray El array de objetos a convertir.
 * @returns {string} La cadena en formato CSV.
 */
function convertToCsv(jsonArray) {
  if (jsonArray.length === 0) return '';
  const headers = Object.keys(jsonArray[0]);
  const csvRows = [headers.join(',')];

  for (const row of jsonArray) {
    const values = headers.map(header => {
      let value = row[header];
      if (value === null || value === undefined) {
        value = '';
      } else if (typeof value === 'object') {
        value = JSON.stringify(value);
      }
      // Escapar comillas dobles y encerrar si contiene comas
      const stringValue = String(value);
      if (stringValue.includes('"') || stringValue.includes(',')) {
        return `"${stringValue.replace(/"/g, '""')}"`;
      }
      return stringValue;
    });
    csvRows.push(values.join(','));
  }
  return csvRows.join('\n');
}

/**
 * GET /api/export/:format
 * Exporta todos los registros de conversiones en formato JSON o CSV.
 * :format - 'json' o 'csv'.
 */
router.get('/:format', async (req, res, next) => {
  const { format } = req.params;

  if (format !== 'json' && format !== 'csv') {
    return res.status(400).json({ success: false, error: 'Formato de exportación no válido. Use "json" o "csv".' });
  }

  try {
    const result = await database.query('SELECT * FROM conversions ORDER BY created_at DESC');
    const data = result.rows;
    const timestamp = new Date().toISOString().replace(/:/g, '-');
    
    if (format === 'json') {
      const filename = `export_${timestamp}.json`;
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', 'application/json');
      res.status(200).json(data);
    } else if (format === 'csv') {
      const filename = `export_${timestamp}.csv`;
      const csvData = convertToCsv(data);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', 'text/csv');
      res.status(200).send(csvData);
    }
    
    logger.info(`Historial exportado en formato ${format.toUpperCase()}`);

  } catch (error) {
    logger.error(`Error al exportar el historial en formato ${format}:`, error);
    next(error);
  }
});

module.exports = router;
