const express = require('express');
const fs = require('fs-extra');
const path = require('path');
const database = require('../database/connection');
const logger = require('../utils/logger');

const router = express.Router();

/**
 * GET /api/download/:id/:type
 * Permite descargar los archivos generados (imagen o PDF) para una conversión.
 * :id - El UUID del registro de conversión.
 * :type - 'image' o 'pdf'.
 */
router.get('/:id/:type', async (req, res, next) => {
  const { id, type } = req.params;

  if (type !== 'image' && type !== 'pdf') {
    return res.status(400).json({ success: false, error: 'Tipo de archivo no válido. Use "image" o "pdf".' });
  }

  try {
    const result = await database.query(
      'SELECT filename, mindmap_image_path, mindmap_pdf_path FROM conversions WHERE id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Registro de conversión no encontrado.' });
    }

    const record = result.rows[0];
    const filePath = type === 'image' ? record.mindmap_image_path : record.mindmap_pdf_path;
    
    if (!filePath) {
        return res.status(404).json({ success: false, error: `El archivo de ${type} no existe para este registro.` });
    }
    
    // Verificar si el archivo existe en el disco
    const fileExists = await fs.pathExists(filePath);
    if (!fileExists) {
      logger.error(`El archivo ${filePath} no fue encontrado en el sistema de archivos, pero existe en la DB.`);
      return res.status(404).json({ success: false, error: 'El archivo no fue encontrado en el servidor.' });
    }

    const downloadFilename = `${path.parse(record.filename).name}_${type}${path.extname(filePath)}`;

    // res.download() maneja las cabeceras Content-Type y Content-Disposition
    res.download(filePath, downloadFilename, (err) => {
      if (err) {
        // El error será manejado por el errorHandler si las cabeceras no han sido enviadas
        next(err);
      } else {
        logger.info(`Archivo ${filePath} descargado como ${downloadFilename}`);
      }
    });

  } catch (error) {
    logger.error(`Error al procesar la descarga para el ID ${id}:`, error);
    next(error);
  }
});

module.exports = router;
