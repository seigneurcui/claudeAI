const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const { v4: uuidv4 } = require('uuid');
const database = require('../database/connection');
const FileProcessor = require('../processors/fileProcessor');
const ollamaService = require('../services/ollamaService');
const mindmapGenerator = require('../services/mindmapGenerator');
const logger = require('../utils/logger');
const { validateConversionRequest } = require('../middleware/validation');

const router = express.Router();

// Configuración de Multer para la subida de archivos
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/')
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, `${file.fieldname}-${uniqueSuffix}${ext}`);
  }
});

const upload = multer({ 
  storage: storage,
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.epub', '.mobi', '.azw', '.azw3', '.pdf', '.txt', '.rtf', '.cbr', '.cbz'];
    const ext = path.extname(file.originalname).toLowerCase();
    
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error(`Formato de archivo no soportado: ${ext}`), false);
    }
  },
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 100 * 1024 * 1024, // 100MB
    files: 10 // Máximo 10 archivos
  }
});

// Ruta principal para manejar la solicitud de conversión
router.post('/', upload.array('files', 10), validateConversionRequest, async (req, res, next) => {
  const jobId = uuidv4();
  const { model } = req.body;
  const files = req.files;
  
  try {
    // Validaciones iniciales
    if (!model) {
      return res.status(400).json({ 
        error: 'Por favor, selecciona un modelo de IA',
        code: 'NO_MODEL'
      });
    }

    const modelExists = await ollamaService.checkModelExists(model);
    if (!modelExists) {
      return res.status(400).json({
        error: `El modelo ${model} no existe o no está instalado`,
        code: 'MODEL_NOT_FOUND'
      });
    }

    logger.info(`Iniciando tarea de conversión ${jobId}, archivos: ${files.length}, modelo: ${model}`);
    
    // Responder inmediatamente al cliente con el ID del trabajo
    res.json({ 
      jobId, 
      message: 'La tarea de conversión ha comenzado',
      filesCount: files.length
    });
    
    // Procesar la conversión de forma asíncrona para no bloquear la respuesta
    processConversionJob(jobId, files, model);
    
  } catch (error) {
    logger.error('Fallo al procesar la solicitud de conversión:', error);
    
    // Limpiar archivos subidos en caso de un error temprano
    if (files) {
      files.forEach(file => {
        fs.remove(file.path).catch(err => 
          logger.error(`Fallo al limpiar el archivo ${file.path}:`, err)
        );
      });
    }
    // El error será manejado por el errorHandler global
    next(error);
  }
});

// Función principal que procesa la cola de conversión
async function processConversionJob(jobId, files, model) {
  const totalFiles = files.length;
  const results = [];
  const startTime = new Date();
  
  try {
    // Emitir evento de inicio a través de Socket.IO
    global.io.emit('conversion:start', { 
      jobId, 
      totalFiles,
      startTime: startTime.toISOString()
    });
    
    // Procesar cada archivo secuencialmente
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const fileStartTime = new Date();
      let recordId = null; // Declarar aquí para que esté disponible en try y catch
      
      try {
        logger.info(`Procesando archivo ${i + 1}/${totalFiles}: ${file.originalname}`);
        
        // Emitir progreso a través de Socket.IO
        global.io.emit('conversion:progress', {
          jobId,
          current: i + 1,
          total: totalFiles,
          currentFile: file.originalname,
          status: 'processing'
        });
        
        // Crear registro en la base de datos
        const conversionResult = await database.query(`
          INSERT INTO conversions (filename, original_format, file_size, model_used, conversion_status, start_time)
          VALUES ($1, $2, $3, $4, 'processing', $5)
          RETURNING id
        `, [
          file.originalname,
          path.extname(file.originalname).toLowerCase(),
          file.size,
          model,
          fileStartTime
        ]);
        recordId = conversionResult.rows[0].id;
        
        // 1. Extraer texto del archivo
        const content = await FileProcessor.extractText(file);
        
        // 2. Analizar contenido con Ollama
        const analysis = await ollamaService.analyzeContent(content, model);
        
        // 3. Generar datos del mapa mental
        const mindmapData = await mindmapGenerator.generateMindmapData(analysis);
        
        // 4. Generar archivos de imagen y PDF del mapa mental
        const mindmapPaths = await mindmapGenerator.generateMindmapFiles(mindmapData, recordId);
        
        const fileEndTime = new Date();
        const fileDuration = Math.round((fileEndTime - fileStartTime) / 1000);
        
        // Actualizar registro en la base de datos como completado
        await database.query(`
          UPDATE conversions 
          SET content_text = $1, mindmap_data = $2, mindmap_image_path = $3, 
              mindmap_pdf_path = $4, conversion_status = 'completed', 
              end_time = $5, duration_seconds = $6, keywords = $7, summary = $8
          WHERE id = $9
        `, [
          content.substring(0, 10000), // Limitar texto almacenado
          JSON.stringify(mindmapData),
          mindmapPaths.imagePath,
          mindmapPaths.pdfPath,
          fileEndTime,
          fileDuration,
          analysis.keywords,
          analysis.summary,
          recordId
        ]);
        
        results.push({
          id: recordId,
          filename: file.originalname,
          status: 'completed',
          duration: fileDuration,
          mindmapPaths: mindmapPaths
        });
        
        logger.info(`Archivo ${file.originalname} procesado con éxito en ${fileDuration}s`);
        
      } catch (error) {
        const errorEndTime = new Date();
        const errorDuration = Math.round((errorEndTime - fileStartTime) / 1000);
        logger.error(`Error procesando el archivo ${file.originalname}:`, error);

        // Actualizar registro en la base de datos como fallido si ya se creó
        if (recordId) {
          await database.query(`
            UPDATE conversions SET conversion_status = 'failed', end_time = $1, error_message = $2, duration_seconds = $3
            WHERE id = $4
          `, [errorEndTime, error.message, errorDuration, recordId]);
        }
        
        // **ESTA ES LA PARTE CORREGIDA**
        // Añadir el resultado de error al array de resultados.
        results.push({
          id: recordId,
          filename: file.originalname,
          status: 'failed',
          error: error.message,
          duration: errorDuration
        });

      } finally {
        // Limpiar el archivo subido de la carpeta 'uploads' después de procesarlo (éxito o fallo)
        await fs.remove(file.path).catch(err => logger.warn(`No se pudo limpiar el archivo ${file.path}:`, err));
      }
    }
    
    // Tarea completada, emitir evento final
    const endTime = new Date();
    const totalDuration = Math.round((endTime - startTime) / 1000);
    global.io.emit('conversion:complete', {
      jobId,
      results,
      totalDuration
    });
    logger.info(`Tarea de conversión ${jobId} completada en ${totalDuration}s.`);

  } catch (jobError) {
    logger.error(`Error crítico en la tarea de conversión ${jobId}:`, jobError);
    global.io.emit('conversion:error', {
      jobId,
      error: 'Un error crítico ha ocurrido en el servidor.',
      message: jobError.message
    });
  }
}

module.exports = router;
