const express = require('express');
const fs = require('fs-extra');
const database = require('../database/connection');
const logger = require('../utils/logger');
const { validatePaginationParams } = require('../middleware/validation');

const router = express.Router();

// GET /api/history - Obtener lista de registros de conversiones con filtros y paginación
router.get('/', validatePaginationParams, async (req, res, next) => {
  try {
    const {
      search = '',
      status,
      model,
      format,
      startDate,
      endDate,
      limit = 20,
      offset = 0,
      sortBy = 'created_at',
      sortOrder = 'DESC'
    } = req.query;

    let whereClauses = [];
    let queryParams = [];
    let paramIndex = 1;

    if (search) {
      whereClauses.push(`
        to_tsvector('simple', coalesce(filename, '') || ' ' || coalesce(summary, '') || ' ' || array_to_string(coalesce(keywords, '{}'), ' ')) @@ to_tsquery('simple', $${paramIndex++})
      `);
      queryParams.push(search.split(' ').join(' & '));
    }
    if (status) {
      whereClauses.push(`conversion_status = $${paramIndex++}`);
      queryParams.push(status);
    }
    if (model) {
      whereClauses.push(`model_used = $${paramIndex++}`);
      queryParams.push(model);
    }
    if (format) {
      whereClauses.push(`original_format = $${paramIndex++}`);
      queryParams.push(format);
    }
    if (startDate) {
      whereClauses.push(`created_at >= $${paramIndex++}`);
      queryParams.push(startDate);
    }
    if (endDate) {
      whereClauses.push(`created_at <= $${paramIndex++}`);
      queryParams.push(endDate);
    }

    const whereString = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

    // Consulta para obtener el total de registros
    const totalQuery = `SELECT COUNT(*) FROM conversions ${whereString}`;
    const totalResult = await database.query(totalQuery, queryParams);
    const totalRecords = parseInt(totalResult.rows[0].count, 10);

    // Consulta para obtener los datos paginados
    const dataQuery = `
      SELECT id, filename, original_format, file_size, model_used, conversion_status, start_time, end_time, duration_seconds, keywords, summary, mindmap_image_path, mindmap_pdf_path
      FROM conversions
      ${whereString}
      ORDER BY ${sortBy} ${sortOrder}
      LIMIT $${paramIndex++} OFFSET $${paramIndex++}
    `;
    const dataResult = await database.query(dataQuery, [...queryParams, limit, offset]);

    res.json({
      success: true,
      pagination: {
        total: totalRecords,
        limit,
        offset,
        pages: Math.ceil(totalRecords / limit),
      },
      data: dataResult.rows,
    });
  } catch (error) {
    logger.error('Error al obtener el historial de conversiones:', error);
    next(error);
  }
});

// GET /api/history/stats - Obtener estadísticas del sistema
router.get('/stats', async (req, res, next) => {
  try {
    const statsResult = await database.query('SELECT * FROM get_system_stats()');
    res.json({
      success: true,
      data: statsResult.rows[0]
    });
  } catch (error) {
    logger.error('Error al obtener las estadísticas del sistema:', error);
    next(error);
  }
});

// GET /api/history/:id - Obtener un registro específico
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const result = await database.query(
      'SELECT * FROM conversions WHERE id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Registro no encontrado',
        code: 'NOT_FOUND'
      });
    }

    res.json({
      success: true,
      data: result.rows[0]
    });
  } catch (error) {
    logger.error(`Error al obtener el registro ${req.params.id}:`, error);
    next(error);
  }
});

// DELETE /api/history/:id - Eliminar un registro
router.delete('/:id', async (req, res, next) => {
  const { id } = req.params;
  const client = await database.getClient();

  try {
    await client.query('BEGIN');

    // 1. Obtener las rutas de los archivos antes de eliminar el registro
    const selectResult = await client.query(
      'SELECT mindmap_image_path, mindmap_pdf_path FROM conversions WHERE id = $1',
      [id]
    );

    if (selectResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Registro no encontrado para eliminar',
        code: 'NOT_FOUND'
      });
    }

    const { mindmap_image_path, mindmap_pdf_path } = selectResult.rows[0];

    // 2. Eliminar el registro de la base de datos
    const deleteResult = await client.query(
      'DELETE FROM conversions WHERE id = $1 RETURNING filename',
      [id]
    );

    // 3. Eliminar los archivos asociados del sistema de archivos
    if (mindmap_image_path) {
      await fs.remove(mindmap_image_path).catch(err => logger.warn(`No se pudo eliminar el archivo de imagen ${mindmap_image_path}:`, err));
    }
    if (mindmap_pdf_path) {
      await fs.remove(mindmap_pdf_path).catch(err => logger.warn(`No se pudo eliminar el archivo PDF ${mindmap_pdf_path}:`, err));
    }

    await client.query('COMMIT');

    logger.info(`Registro ${id} (${deleteResult.rows[0].filename}) y archivos asociados eliminados.`);
    res.status(200).json({
      success: true,
      message: 'Registro y archivos asociados eliminados correctamente.'
    });
  } catch (error) {
    await client.query('ROLLBACK');
    logger.error(`Error al eliminar el registro ${id}:`, error);
    next(error);
  } finally {
    client.release();
  }
});

module.exports = router;
