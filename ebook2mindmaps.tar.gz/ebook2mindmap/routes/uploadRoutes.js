const express = require('express');
const multer = require('multer');
const path = require('path');
const logger = require('../utils/logger');
const FileProcessor = require('../processors/fileProcessor');

const router = express.Router();

// Configuración de Multer para la subida de archivos
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1E9)}`;
    cb(null, `${file.fieldname}-${uniqueSuffix}${path.extname(file.originalname)}`);
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // Límite de 100MB
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (FileProcessor.supportedFormats.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error(`Formato de archivo no soportado: ${ext}`), false);
    }
  },
});

/**
 * POST /api/upload
 * Endpoint para subir uno o más archivos. No inicia la conversión,
 * solo almacena el archivo y devuelve su metadata.
 */
router.post('/', upload.array('files', 10), (req, res) => {
  if (!req.files || req.files.length === 0) {
    return res.status(400).json({ success: false, error: 'No se subieron archivos.' });
  }

  logger.info(`${req.files.length} archivo(s) subido(s) correctamente.`);

  const uploadedFiles = req.files.map(file => ({
    originalname: file.originalname,
    filename: file.filename,
    path: file.path,
    size: file.size,
    mimetype: file.mimetype,
  }));

  res.status(201).json({
    success: true,
    message: 'Archivos subidos correctamente.',
    files: uploadedFiles,
  });
});

module.exports = router;
