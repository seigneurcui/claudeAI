const fs = require('fs-extra');
const path = require('path');
const puppeteer = require('puppeteer');
const { createCanvas } = require('canvas');
const logger = require('../utils/logger');

class MindmapGenerator {
  constructor() {
    this.puppeteerOptions = {
      headless: 'new',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--no-first-run',
        '--no-zygote',
        '--single-process'
      ]
    };
  }

  // 生成思维导图数据结构
  async generateMindmapData(analysis, options = {}) {
    try {
      logger.info('开始生成思维导图数据结构');
      
      // 验证分析数据
      if (!analysis || !analysis.central_topic || !analysis.main_branches) {
        throw new Error('分析数据格式无效');
      }

      // 转换为D3.js层级数据结构
      const mindmapData = {
        name: analysis.central_topic,
        type: 'root',
        level: 0,
        children: analysis.main_branches.map((branch, index) => ({
          name: branch.title,
          description: branch.description,
          type: 'branch',
          level: 1,
          index: index,
          children: (branch.sub_branches || []).map((subBranch, subIndex) => ({
            name: subBranch,
            type: 'leaf',
            level: 2,
            index: subIndex,
            size: 1
          }))
        }))
      };

      // 添加元数据
      mindmapData.metadata = {
        keywords: analysis.keywords || [],
        summary: analysis.summary || '',
        generated_at: new Date().toISOString(),
        total_nodes: this.countNodes(mindmapData),
        max_depth: this.calculateMaxDepth(mindmapData)
      };

      logger.info(`思维导图数据生成完成，共 ${mindmapData.metadata.total_nodes} 个节点`);
      return mindmapData;
      
    } catch (error) {
      logger.error('思维导图数据生成失败:', error);
      throw new Error(`思维导图数据生成失败: ${error.message}`);
    }
  }

  // 生成思维导图文件（图片和PDF）
  async generateMindmapFiles(mindmapData, recordId, options = {}) {
    try {
      logger.info(`开始生成思维导图文件，记录ID: ${recordId}`);
      
      const timestamp = Date.now();
      const imageFileName = `mindmap_${recordId}_${timestamp}.png`;
      const pdfFileName = `mindmap_${recordId}_${timestamp}.pdf`;
      
      const imagePath = path.join('mindmaps', imageFileName);
      const pdfPath = path.join('mindmaps', pdfFileName);

      // 确保目录存在
      await fs.ensureDir('mindmaps');

      // 生成HTML内容
      const htmlContent = this.generateMindmapHTML(mindmapData, options);
      
      // 使用Puppeteer生成图片和PDF
      let browser = null;
      try {
        browser = await puppeteer.launch(this.puppeteerOptions);
        const page = await browser.newPage();
        
        // 设置视口
        await page.setViewport({
          width: options.width || 1200,
          height: options.height || 800,
          deviceScaleFactor: 2 // 高分辨率
        });

        // 加载HTML内容
        await page.setContent(htmlContent, { 
          waitUntil: ['networkidle0', 'domcontentloaded'] 
        });

        // 等待D3.js渲染完成
        await page.waitForTimeout(3000);
        
        // 等待思维导图元素完全渲染
        await page.waitForSelector('#mindmap svg', { timeout: 10000 });

        // 生成PNG图片
        await page.screenshot({
          path: imagePath,
          type: 'png',
          fullPage: false,
          clip: {
            x: 0,
            y: 0,
            width: options.width || 1200,
            height: options.height || 800
          }
        });

        // 生成PDF
        await page.pdf({
          path: pdfPath,
          format: 'A4',
          landscape: true,
          printBackground: true,
          margin: {
            top: '20px',
            right: '20px',
            bottom: '20px',
            left: '20px'
          }
        });

        logger.info('思维导图文件生成完成');
        
        return {
          imagePath: imagePath,
          pdfPath: pdfPath,
          imageUrl: `/mindmaps/${imageFileName}`,
          pdfUrl: `/mindmaps/${pdfFileName}`
        };

      } finally {
        if (browser) {
          await browser.close();
        }
      }

    } catch (error) {
      logger.error('思维导图文件生成失败:', error);
      throw new Error(`思维导图文件生成失败: ${error.message}`);
    }
  }

  // 生成思维导图HTML
  generateMindmapHTML(data, options = {}) {
    const theme = options.theme || 'default';
    const colors = this.getColorScheme(theme);
    
    return `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>思维导图 - ${data.name}</title>
    <style>
        body {
            margin: 0;
            padding: 20px;
            font-family: 'Microsoft YaHei', 'Arial', sans-serif;
            background: ${colors.background};
            overflow: hidden;
        }
        
        .mindmap-container {
            width: 100%;
            height: 760px;
            background: ${colors.containerBackground};
            border-radius: 10px;
            box-shadow: 0 10px 30px ${colors.shadow};
            padding: 20px;
            box-sizing: border-box;
            position: relative;
        }
        
        .mindmap-header {
            text-align: center;
            margin-bottom: 20px;
        }
        
        .mindmap-title {
            font-size: 24px;
            font-weight: bold;
            color: ${colors.titleColor};
            margin: 0 0 10px 0;
        }
        
        .mindmap-subtitle {
            font-size: 14px;
            color: ${colors.subtitleColor};
            margin: 0;
        }
        
        #mindmap {
            width: 100%;
            height: 100%;
        }
        
        .node circle {
            stroke-width: 2px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .node text {
            font-size: 12px;
            pointer-events: none;
            text-anchor: middle;
            dominant-baseline: central;
        }
        
        .node--root circle {
            fill: ${colors.rootNode};
            stroke: ${colors.rootNodeBorder};
            r: 15;
        }
        
        .node--root text {
            font-size: 16px;
            font-weight: bold;
            fill: white;
        }
        
        .node--branch circle {
            fill: ${colors.branchNode};
            stroke: ${colors.branchNodeBorder};
            r: 10;
        }
        
        .node--branch text {
            font-size: 13px;
            font-weight: 500;
            fill: ${colors.branchText};
        }
        
        .node--leaf circle {
            fill: ${colors.leafNode};
            stroke: ${colors.leafNodeBorder};
            r: 6;
        }
        
        .node--leaf text {
            font-size: 11px;
            fill: ${colors.leafText};
        }
        
        .link {
            fill: none;
            stroke: ${colors.linkColor};
            stroke-opacity: 0.6;
            stroke-width: 1.5px;
        }
        
        .node:hover circle {
            stroke-width: 3px;
            filter: brightness(1.1);
        }
        
        .metadata {
            position: absolute;
            bottom: 10px;
            right: 10px;
            font-size: 10px;
            color: ${colors.metadataColor};
            text-align: right;
        }
        
        .keywords {
            position: absolute;
            bottom: 10px;
            left: 10px;
            font-size: 10px;
            color: ${colors.metadataColor};
            max-width: 300px;
        }
        
        @media print {
            body { background: white; }
            .mindmap-container { 
                box-shadow: none; 
                border: 1px solid #ddd;
            }
        }
    </style>
</head>
<body>
    <div class="mindmap-container">
        <div class="mindmap-header">
            <h1 class="mindmap-title">${this.escapeHtml(data.name)}</h1>
            <p class="mindmap-subtitle">思维导图 - ${new Date().toLocaleDateString('zh-CN')}</p>
        </div>
        <svg id="mindmap"></svg>
        
        ${data.metadata && data.metadata.keywords ? `
        <div class="keywords">
            <strong>关键词：</strong>${data.metadata.keywords.join(', ')}
        </div>` : ''}
        
        <div class="metadata">
            <div>节点数: ${data.metadata ? data.metadata.total_nodes : this.countNodes(data)}</div>
            <div>生成时间: ${new Date().toLocaleString('zh-CN')}</div>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/d3/7.8.5/d3.min.js"></script>
    <script>
        const data = ${JSON.stringify(data)};
        
        // 设置画布尺寸
        const containerWidth = document.querySelector('.mindmap-container').clientWidth - 40;
        const containerHeight = document.querySelector('.mindmap-container').clientHeight - 100;
        
        const svg = d3.select("#mindmap")
            .attr("width", containerWidth)
            .attr("height", containerHeight);
            
        const g = svg.append("g")
            .attr("transform", "translate(" + containerWidth / 2 + "," + containerHeight / 2 + ")");
        
        // 创建径向树布局
        const tree = d3.tree()
            .size([360, Math.min(containerWidth, containerHeight) / 3])
            .separation(function(a, b) { 
                return (a.parent == b.parent ? 1 : 2) / a.depth; 
            });
        
        const root = d3.hierarchy(data);
        tree(root);
        
        // 创建连接线
        const link = g.selectAll(".link")
            .data(root.links())
            .enter().append("path")
            .attr("class", "link")
            .attr("d", d3.linkRadial()
                .angle(function(d) { return d.x / 180 * Math.PI; })
                .radius(function(d) { return d.y; }));
        
        // 创建节点
        const node = g.selectAll(".node")
            .data(root.descendants())
            .enter().append("g")
            .attr("class", function(d) { 
                let className = "node";
                if (!d.parent) className += " node--root";
                else if (d.children) className += " node--branch";
                else className += " node--leaf";
                return className;
            })
            .attr("transform", function(d) { 
                return "rotate(" + (d.x - 90) + ")translate(" + d.y + ",0)" + 
                       (d.x < 180 ? "" : "rotate(180)"); 
            });
        
        // 添加圆圈
        node.append("circle");
        
        // 添加文本标签
        node.append("text")
            .attr("dy", function(d) { return d.x < 180 ? "0.31em" : "-0.31em"; })
            .attr("x", function(d) { 
                if (d.parent === null) return 0; // 根节点居中
                return d.x < 180 === !d.children ? 12 : -12; 
            })
            .attr("text-anchor", function(d) { 
                if (d.parent === null) return "middle"; // 根节点居中
                return d.x < 180 === !d.children ? "start" : "end"; 
            })
            .text(function(d) { 
                const maxLength = d.parent === null ? 20 : (d.children ? 15 : 12);
                return d.data.name.length > maxLength ? 
                    d.data.name.substring(0, maxLength) + '...' : 
                    d.data.name; 
            });
        
        // 添加工具提示
        const tooltip = d3.select("body").append("div")
            .attr("class", "tooltip")
            .style("position", "absolute")
            .style("padding", "10px")
            .style("background", "rgba(0, 0, 0, 0.8)")
            .style("color", "white")
            .style("border-radius", "5px")
            .style("pointer-events", "none")
            .style("opacity", 0)
            .style("font-size", "12px")
            .style("max-width", "200px");
        
        node.on("mouseover", function(event, d) {
            let tooltipContent = "<strong>" + d.data.name + "</strong>";
            if (d.data.description) {
                tooltipContent += "<br><br>" + d.data.description;
            }
            
            tooltip.transition()
                .duration(200)
                .style("opacity", .9);
            tooltip.html(tooltipContent)
                .style("left", (event.pageX + 10) + "px")
                .style("top", (event.pageY - 10) + "px");
        })
        .on("mouseout", function(d) {
            tooltip.transition()
                .duration(500)
                .style("opacity", 0);
        });
        
        // 添加缩放和拖拽功能
        const zoom = d3.zoom()
            .scaleExtent([0.5, 3])
            .on("zoom", function(event) {
                g.attr("transform", event.transform);
            });
        
        svg.call(zoom);
        
        // 自动适应大小
        function fitToContainer() {
            const bbox = g.node().getBBox();
            const fullWidth = containerWidth;
            const fullHeight = containerHeight;
            const width = bbox.width;
            const height = bbox.height;
            const midX = bbox.x + width / 2;
            const midY = bbox.y + height / 2;
            
            if (width === 0 || height === 0) return;
            
            const scale = Math.min(fullWidth / width, fullHeight / height) * 0.8;
            const translate = [fullWidth / 2 - midX * scale, fullHeight / 2 - midY * scale];
            
            svg.transition()
                .duration(1000)
                .call(zoom.transform, d3.zoomIdentity.translate(translate[0], translate[1]).scale(scale));
        }
        
        // 延迟执行自动适应，确保渲染完成
        setTimeout(fitToContainer, 100);
        
        console.log("思维导图渲染完成");
    </script>
</body>
</html>
    `;
  }

  // 获取颜色方案
  getColorScheme(theme) {
    const schemes = {
      default: {
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        containerBackground: 'white',
        shadow: 'rgba(0,0,0,0.2)',
        titleColor: '#333',
        subtitleColor: '#666',
        rootNode: '#ff6b6b',
        rootNodeBorder: '#e55656',
        branchNode: '#4ecdc4',
        branchNodeBorder: '#45b7d1',
        leafNode: '#45b7d1',
        leafNodeBorder: '#3498db',
        linkColor: '#666',
        branchText: '#2c3e50',
        leafText: '#34495e',
        metadataColor: '#7f8c8d'
      },
      dark: {
        background: 'linear-gradient(135deg, #2c3e50 0%, #34495e 100%)',
        containerBackground: '#2c3e50',
        shadow: 'rgba(0,0,0,0.5)',
        titleColor: '#ecf0f1',
        subtitleColor: '#bdc3c7',
        rootNode: '#e74c3c',
        rootNodeBorder: '#c0392b',
        branchNode: '#f39c12',
        branchNodeBorder: '#d68910',
        leafNode: '#3498db',
        leafNodeBorder: '#2980b9',
        linkColor: '#7f8c8d',
        branchText: '#ecf0f1',
        leafText: '#bdc3c7',
        metadataColor: '#95a5a6'
      },
      nature: {
        background: 'linear-gradient(135deg, #a8e6cf 0%, #7fcdcd 100%)',
        containerBackground: '#f8fff8',
        shadow: 'rgba(0,0,0,0.1)',
        titleColor: '#2d5016',
        subtitleColor: '#5d7c47',
        rootNode: '#27ae60',
        rootNodeBorder: '#229954',
        branchNode: '#f39c12',
        branchNodeBorder: '#d68910',
        leafNode: '#3498db',
        leafNodeBorder: '#2980b9',
        linkColor: '#7d8471',
        branchText: '#2d5016',
        leafText: '#5d7c47',
        metadataColor: '#7d8471'
      }
    };
    
    return schemes[theme] || schemes.default;
  }

  // 计算节点数量
  countNodes(data) {
    let count = 1; // 根节点
    if (data.children) {
      data.children.forEach(child => {
        count += this.countNodes(child);
      });
    }
    return count;
  }

  // 计算最大深度
  calculateMaxDepth(data, currentDepth = 0) {
    if (!data.children || data.children.length === 0) {
      return currentDepth;
    }
    
    return Math.max(...data.children.map(child => 
      this.calculateMaxDepth(child, currentDepth + 1)
    ));
  }

  // HTML转义
  escapeHtml(text) {
    const map = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
  }

  // 生成简单的SVG思维导图（备用方案）
  async generateSVGMindmap(data, outputPath) {
    try {
      const { createCanvas } = require('canvas');
      const canvas = createCanvas(1200, 800);
      const ctx = canvas.getContext('2d');
      
      // 设置背景
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, 1200, 800);
      
      // 绘制标题
      ctx.fillStyle = '#333333';
      ctx.font = 'bold 24px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(data.name, 600, 50);
      
      // 绘制中心节点
      ctx.beginPath();
      ctx.arc(600, 400, 50, 0, 2 * Math.PI);
      ctx.fillStyle = '#ff6b6b';
      ctx.fill();
      ctx.strokeStyle = '#e55656';
      ctx.lineWidth = 3;
      ctx.stroke();
      
      // 绘制中心文本
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 14px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(data.name, 600, 405);
      
      // 绘制分支
      if (data.children) {
        const angleStep = (2 * Math.PI) / data.children.length;
        data.children.forEach((branch, index) => {
          const angle = index * angleStep;
          const x = 600 + Math.cos(angle) * 200;
          const y = 400 + Math.sin(angle) * 150;
          
          // 绘制连接线
          ctx.beginPath();
          ctx.moveTo(600, 400);
          ctx.lineTo(x, y);
          ctx.strokeStyle = '#666666';
          ctx.lineWidth = 2;
          ctx.stroke();
          
          // 绘制分支节点
          ctx.beginPath();
          ctx.arc(x, y, 30, 0, 2 * Math.PI);
          ctx.fillStyle = '#4ecdc4';
          ctx.fill();
          ctx.strokeStyle = '#45b7d1';
          ctx.lineWidth = 2;
          ctx.stroke();
          
          // 绘制分支文本
          ctx.fillStyle = '#2c3e50';
          ctx.font = 'bold 12px Arial';
          ctx.textAlign = 'center';
          ctx.fillText(branch.title, x, y);
        });
      }
      
      // 保存为PNG
      const buffer = canvas.toBuffer('image/png');
      await fs.writeFile(outputPath, buffer);
      
      logger.info('SVG思维导图生成完成');
      return outputPath;
      
    } catch (error) {
      logger.error('SVG思维导图生成失败:', error);
      throw error;
    }
  }

  // 清理旧文件
  async cleanupOldFiles(retentionDays = 30) {
    try {
      const mindmapsDir = 'mindmaps';
      const now = Date.now();
      const retentionMs = retentionDays * 24 * 60 * 60 * 1000;
      
      if (!await fs.pathExists(mindmapsDir)) {
        return;
      }
      
      const files = await fs.readdir(mindmapsDir);
      let deletedCount = 0;
      
      for (const file of files) {
        const filePath = path.join(mindmapsDir, file);
        const stats = await fs.stat(filePath);
        
        if (now - stats.mtime.getTime() > retentionMs) {
          await fs.remove(filePath);
          deletedCount++;
          logger.info(`删除过期文件: ${file}`);
        }
      }
      
      logger.info(`清理完成，删除了 ${deletedCount} 个过期文件`);
      return deletedCount;
      
    } catch (error) {
      logger.error('清理旧文件失败:', error);
      throw error;
    }
  }
}

module.exports = new MindmapGenerator();