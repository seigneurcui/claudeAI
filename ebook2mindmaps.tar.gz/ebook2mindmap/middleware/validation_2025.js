const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};

//const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};const { body, query, param, validationResult } = require('express-validator');

// Función de middleware para manejar los errores de validación
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array()
    });
  }
  next();
};

// Validar la solicitud de conversión
const validateConversionRequest = [
  body('model')
    .isString()
    .withMessage('El modelo debe ser una cadena de texto.')
    .notEmpty()
    .withMessage('El nombre del modelo no puede estar vacío.')
    .trim(),
  (req, res, next) => {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No se subieron archivos.',
        code: 'NO_FILES_UPLOADED'
      });
    }
    next();
  },
  handleValidationErrors,
];

// Validar parámetros de paginación y ordenamiento
const validatePaginationParams = [
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('El límite debe ser un entero entre 1 y 100.')
    .toInt(),
  query('offset')
    .optional()
    .isInt({ min: 0 })
    .withMessage('El offset debe ser un entero positivo.')
    .toInt(),
  query('sortBy')
    .optional()
    .isString()
    .isIn(['created_at', 'filename', 'file_size', 'duration_seconds', 'model_used', 'original_format'])
    .withMessage('El campo para ordenar no es válido.')
    .trim(),
  query('sortOrder')
    .optional()
    .isString()
    .isIn(['ASC', 'DESC'])
    .withMessage('El orden debe ser ASC o DESC.')
    .toUpperCase(),
  query('search')
    .optional()
    .isString()
    .trim(),
  query('status')
    .optional()
    .isString()
    .isIn(['processing', 'completed', 'failed']),
  query('model')
    .optional()
    .isString(),
  query('format')
    .optional()
    .isString(),
  query('startDate')
    .optional()
    .isISO8601()
    .toDate(),
  query('endDate')
    .optional()
    .isISO8601()
    .toDate(),
  handleValidationErrors,
];

module.exports = {
  validateConversionRequest,
  validatePaginationParams,
};
