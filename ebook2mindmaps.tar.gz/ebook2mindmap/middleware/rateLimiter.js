const rateLimit = require('express-rate-limit');

/**
 * Middleware de límite de velocidad para proteger la API contra solicitudes excesivas.
 * Limita a cada IP a 100 solicitudes por un período de 15 minutos.
 */
const rateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100, // Límite de 100 solicitudes por IP por ventana de tiempo
  standardHeaders: true, // Devuelve información del límite de velocidad en las cabeceras `RateLimit-*`
  legacyHeaders: false, // Deshabilita las cabeceras `X-RateLimit-*`
  message: {
    success: false,
    error: 'Demasiadas solicitudes',
    code: 'TOO_MANY_REQUESTS',
    message: 'Has alcanzado el límite de solicitudes. Por favor, inténtalo de nuevo más tarde.',
  },
});

module.exports = rateLimiter;
