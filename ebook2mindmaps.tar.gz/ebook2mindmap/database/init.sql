-- 启用必要的扩展
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 创建转换记录表
CREATE TABLE IF NOT EXISTS conversions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    filename VARCHAR(255) NOT NULL,
    original_format VARCHAR(20) NOT NULL,
    file_size BIGINT NOT NULL,
    model_used VARCHAR(100) NOT NULL,
    content_text TEXT,
    mindmap_data JSONB,
    mindmap_image_path VARCHAR(500),
    mindmap_pdf_path VARCHAR(500),
    conversion_status VARCHAR(20) DEFAULT 'processing' 
        CHECK (conversion_status IN ('processing', 'completed', 'failed')),
    start_time TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    end_time TIMESTAMP WITH TIME ZONE,
    duration_seconds INTEGER,
    error_message TEXT,
    keywords TEXT[],
    summary TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 创建系统配置表
CREATE TABLE IF NOT EXISTS system_config (
    key VARCHAR(100) PRIMARY KEY,
    value JSONB NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 创建用户会话表（可选功能）
CREATE TABLE IF NOT EXISTS user_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id VARCHAR(255) UNIQUE NOT NULL,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_activity TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT true
);

-- 创建转换统计表
CREATE TABLE IF NOT EXISTS conversion_stats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    date DATE NOT NULL,
    total_conversions INTEGER DEFAULT 0,
    successful_conversions INTEGER DEFAULT 0,
    failed_conversions INTEGER DEFAULT 0,
    total_files_processed INTEGER DEFAULT 0,
    total_processing_time INTEGER DEFAULT 0,
    most_used_model VARCHAR(100),
    most_converted_format VARCHAR(20),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(date)
);

-- 创建错误日志表
CREATE TABLE IF NOT EXISTS error_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    conversion_id UUID REFERENCES conversions(id) ON DELETE CASCADE,
    error_type VARCHAR(50) NOT NULL,
    error_message TEXT NOT NULL,
    stack_trace TEXT,
    context JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 为conversions表创建索引
CREATE INDEX IF NOT EXISTS idx_conversions_filename 
    ON conversions(filename);
CREATE INDEX IF NOT EXISTS idx_conversions_status 
    ON conversions(conversion_status);
CREATE INDEX IF NOT EXISTS idx_conversions_start_time 
    ON conversions(start_time DESC);
CREATE INDEX IF NOT EXISTS idx_conversions_keywords 
    ON conversions USING GIN(keywords);
CREATE INDEX IF NOT EXISTS idx_conversions_created_at 
    ON conversions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_conversions_model 
    ON conversions(model_used);
CREATE INDEX IF NOT EXISTS idx_conversions_format 
    ON conversions(original_format);

-- Create IMMUTABLE function for search vector
CREATE OR REPLACE FUNCTION create_search_vector(
    filename TEXT, 
    summary TEXT, 
    keywords TEXT[]
) RETURNS tsvector AS $$
BEGIN
    RETURN to_tsvector(
        'simple',
        COALESCE(filename, '') || ' ' || 
        COALESCE(summary, '') || ' ' || 
        COALESCE(array_to_string(keywords, ' '), '')
    );
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- 创建全文搜索索引
CREATE INDEX IF NOT EXISTS idx_conversions_search 
    ON conversions USING GIN(
        create_search_vector(filename, summary, keywords)
    );

-- 为其他表创建索引
CREATE INDEX IF NOT EXISTS idx_user_sessions_session_id 
    ON user_sessions(session_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_last_activity 
    ON user_sessions(last_activity DESC);
CREATE INDEX IF NOT EXISTS idx_conversion_stats_date 
    ON conversion_stats(date DESC);
CREATE INDEX IF NOT EXISTS idx_error_logs_conversion_id 
    ON error_logs(conversion_id);
CREATE INDEX IF NOT EXISTS idx_error_logs_created_at 
    ON error_logs(created_at DESC);

-- 创建触发器函数：更新updated_at字段
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE 'plpgsql';

-- 为conversions表创建updated_at触发器
DROP TRIGGER IF EXISTS update_conversions_updated_at ON conversions;
CREATE TRIGGER update_conversions_updated_at
    BEFORE UPDATE ON conversions
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- 为system_config表创建updated_at触发器
DROP TRIGGER IF EXISTS update_system_config_updated_at ON system_config;
CREATE TRIGGER update_system_config_updated_at
    BEFORE UPDATE ON system_config
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- 创建自动统计更新函数
CREATE OR REPLACE FUNCTION update_conversion_stats()
RETURNS TRIGGER AS $$
BEGIN
    -- 当转换完成时更新统计
    IF NEW.conversion_status = 'completed' AND OLD.conversion_status = 'processing' THEN
        INSERT INTO conversion_stats (
            date, total_conversions, successful_conversions, 
            total_files_processed, total_processing_time,
            most_used_model, most_converted_format
        )
        VALUES (
            CURRENT_DATE, 1, 1, 1, 
            COALESCE(NEW.duration_seconds, 0),
            NEW.model_used, NEW.original_format
        )
        ON CONFLICT (date) 
        DO UPDATE SET
            total_conversions = conversion_stats.total_conversions + 1,
            successful_conversions = conversion_stats.successful_conversions + 1,
            total_files_processed = conversion_stats.total_files_processed + 1,
            total_processing_time = conversion_stats.total_processing_time + COALESCE(NEW.duration_seconds, 0);
    END IF;
    
    -- 当转换失败时更新统计
    IF NEW.conversion_status = 'failed' AND OLD.conversion_status = 'processing' THEN
        INSERT INTO conversion_stats (
            date, total_conversions, failed_conversions, 
            total_files_processed, most_used_model, most_converted_format
        )
        VALUES (
            CURRENT_DATE, 1, 1, 1,
            NEW.model_used, NEW.original_format
        )
        ON CONFLICT (date) 
        DO UPDATE SET
            total_conversions = conversion_stats.total_conversions + 1,
            failed_conversions = conversion_stats.failed_conversions + 1,
            total_files_processed = conversion_stats.total_files_processed + 1;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE 'plpgsql';

-- 创建统计更新触发器
DROP TRIGGER IF EXISTS trigger_update_conversion_stats ON conversions;
CREATE TRIGGER trigger_update_conversion_stats
    AFTER UPDATE ON conversions
    FOR EACH ROW
    EXECUTE FUNCTION update_conversion_stats();

-- 插入默认系统配置
INSERT INTO system_config (key, value, description) VALUES
    ('max_file_size', '104857600'::jsonb, '最大文件大小（字节）'),
    ('max_concurrent_conversions', '5'::jsonb, '最大并发转换数'),
    ('cleanup_old_files_days', '30'::jsonb, '清理旧文件的天数'),
    ('supported_formats', '["epub", "pdf", "txt", "rtf", "mobi", "azw", "azw3", "cbr", "cbz"]'::jsonb, '支持的文件格式'),
    ('default_ollama_model', '"llama2:7b"'::jsonb, '默认Ollama模型')
ON CONFLICT (key) DO NOTHING;

-- 创建清理旧记录的存储过程
CREATE OR REPLACE FUNCTION cleanup_old_records(retention_days INTEGER DEFAULT 90)
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    -- 删除旧的转换记录（但保留文件路径用于清理）
    WITH deleted_records AS (
        DELETE FROM conversions 
        WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '1 day' * retention_days
        RETURNING id
    )
    SELECT COUNT(*) INTO deleted_count FROM deleted_records;
    
    -- 清理旧的错误日志
    DELETE FROM error_logs 
    WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '1 day' * retention_days;
    
    -- 清理旧的用户会话
    DELETE FROM user_sessions 
    WHERE last_activity < CURRENT_TIMESTAMP - INTERVAL '1 day' * 7;
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- 创建获取系统统计信息的函数
CREATE OR REPLACE FUNCTION get_system_stats()
RETURNS TABLE(
    total_conversions BIGINT,
    successful_conversions BIGINT,
    failed_conversions BIGINT,
    avg_processing_time NUMERIC,
    most_used_model TEXT,
    most_converted_format TEXT,
    today_conversions BIGINT,
    database_size TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COUNT(*) as total_conversions,
        COUNT(*) FILTER (WHERE conversion_status = 'completed') as successful_conversions,
        COUNT(*) FILTER (WHERE conversion_status = 'failed') as failed_conversions,
        AVG(duration_seconds) as avg_processing_time,
        (SELECT model_used FROM conversions 
         GROUP BY model_used 
         ORDER BY COUNT(*) DESC 
         LIMIT 1) as most_used_model,
        (SELECT original_format FROM conversions 
         GROUP BY original_format 
         ORDER BY COUNT(*) DESC 
         LIMIT 1) as most_converted_format,
        COUNT(*) FILTER (WHERE DATE(created_at) = CURRENT_DATE) as today_conversions,
        pg_size_pretty(pg_database_size(current_database())) as database_size
    FROM conversions;
END;
$$ LANGUAGE plpgsql;
