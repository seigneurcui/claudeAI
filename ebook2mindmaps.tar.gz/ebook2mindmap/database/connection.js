const { Pool } = require('pg');
const fs = require('fs-extra');
const path = require('path');
const logger = require('../utils/logger');

class Database {
  constructor() {
    this.pool = null;
    this.isConnected = false;
  }

  async initialize() {
    try {
      // 数据库连接配置
      this.pool = new Pool({
        user: process.env.DB_USER || 'postgres',
        host: process.env.DB_HOST || '127.0.0.1',
        database: process.env.DB_NAME || 'ebook_mindmap',
        password: process.env.DB_PASSWORD || 'postgres',
        port: process.env.DB_PORT || 6432,
        max: 20, // 连接池最大连接数
        idleTimeoutMillis: 30000, // 空闲连接超时时间
        connectionTimeoutMillis: 2000, // 连接超时时间
      });

      // 测试连接
      const client = await this.pool.connect();
      const result = await client.query('SELECT NOW()');
      client.release();

      logger.info('数据库连接成功:', result.rows[0].now);
      this.isConnected = true;

      // 初始化数据库表
      await this.initializeTables();

    } catch (error) {
      logger.error('数据库连接失败:', error);
      throw error;
    }
  }

  async initializeTables() {
    try {
      const initSqlPath = path.join(__dirname, 'init.sql');
      const initSql = await fs.readFile(initSqlPath, 'utf8');
      
      await this.pool.query(initSql);
      logger.info('数据库表初始化完成');
      
    } catch (error) {
      logger.error('数据库表初始化失败:', error);
      throw error;
    }
  }

  async query(text, params = []) {
    if (!this.isConnected) {
      throw new Error('数据库未连接');
    }

    const start = Date.now();
    try {
      const result = await this.pool.query(text, params);
      const duration = Date.now() - start;
      
      logger.debug('SQL查询执行:', {
        query: text,
        duration: `${duration}ms`,
        rows: result.rowCount
      });
      
      return result;
    } catch (error) {
      logger.error('SQL查询失败:', {
        query: text,
        params: params,
        error: error.message
      });
      throw error;
    }
  }

  async getClient() {
    if (!this.isConnected) {
      throw new Error('数据库未连接');
    }
    return await this.pool.connect();
  }

  async transaction(callback) {
    const client = await this.getClient();
    
    try {
      await client.query('BEGIN');
      const result = await callback(client);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      await client.query('ROLLBACK');
      logger.error('事务回滚:', error);
      throw error;
    } finally {
      client.release();
    }
  }

  async close() {
    if (this.pool) {
      await this.pool.end();
      this.isConnected = false;
      logger.info('数据库连接已关闭');
    }
  }

  // 健康检查
  async healthCheck() {
    try {
      const result = await this.query('SELECT 1 as health');
      return result.rows[0].health === 1;
    } catch (error) {
      logger.error('数据库健康检查失败:', error);
      return false;
    }
  }

  // 获取连接池状态
  getPoolStatus() {
    if (!this.pool) return null;
    
    return {
      totalCount: this.pool.totalCount,
      idleCount: this.pool.idleCount,
      waitingCount: this.pool.waitingCount
    };
  }
}

// 单例模式
const database = new Database();

module.exports = database;
