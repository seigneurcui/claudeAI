// Global variables
let selectedFiles = [];
let currentMindmap = null;
let currentConversions = {};

// Language configurations for chunk sizes
const languageConfigs = {
    'auto': { chunkSize: 2000, chunkOverlap: 200 },
    'en': { chunkSize: 2000, chunkOverlap: 200 },
    'zh-cn': { chunkSize: 1000, chunkOverlap: 100 },
    'zh-tw': { chunkSize: 1000, chunkOverlap: 100 },
    'ja': { chunkSize: 800, chunkOverlap: 80 },
    'fr': { chunkSize: 1800, chunkOverlap: 180 },
    'es': { chunkSize: 1800, chunkOverlap: 180 },
    'pt': { chunkSize: 1800, chunkOverlap: 180 },
    'it': { chunkSize: 1800, chunkOverlap: 180 },
    'de': { chunkSize: 1500, chunkOverlap: 150 },
    'ru': { chunkSize: 1200, chunkOverlap: 120 }
};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeFileUpload();
    initializeLanguageSettings();
    loadConversionHistory();
    
    // Set up periodic status updates
    setInterval(updateConversionStatus, 3000);
});

// Initialize file upload functionality
function initializeFileUpload() {
    const dragDropArea = document.getElementById('dragDropArea');
    const fileInput = document.getElementById('fileInput');

    // Drag and drop functionality
    dragDropArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        dragDropArea.classList.add('drag-over');
    });

    dragDropArea.addEventListener('dragleave', function(e) {
        e.preventDefault();
        dragDropArea.classList.remove('drag-over');
    });

    dragDropArea.addEventListener('drop', function(e) {
        e.preventDefault();
        dragDropArea.classList.remove('drag-over');
        const files = Array.from(e.dataTransfer.files);
        handleFileSelection(files);
    });

    // File input change
    fileInput.addEventListener('change', function(e) {
        const files = Array.from(e.target.files);
        handleFileSelection(files);
    });
}

// Initialize language settings and chunk size recommendations
function initializeLanguageSettings() {
    const inputLanguageSelect = document.getElementById('inputLanguage');
    const chunkSizeInput = document.getElementById('chunkSize');
    const chunkOverlapInput = document.getElementById('chunkOverlap');
    const chunkSizeRecommendation = document.getElementById('chunkSizeRecommendation');
    const chunkOverlapRecommendation = document.getElementById('chunkOverlapRecommendation');

    // Update chunk sizes when input language changes
    inputLanguageSelect.addEventListener('change', function() {
        const selectedLanguage = this.value;
        const config = languageConfigs[selectedLanguage] || languageConfigs['auto'];
        
        chunkSizeInput.value = config.chunkSize;
        chunkOverlapInput.value = config.chunkOverlap;
        chunkSizeRecommendation.textContent = config.chunkSize;
        chunkOverlapRecommendation.textContent = config.chunkOverlap;
    });
}

// Handle file selection
function handleFileSelection(files) {
    const validFiles = files.filter(file => {
        const allowedTypes = ['.pdf', '.epub', '.txt', '.docx', '.doc'];
        const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
        return allowedTypes.includes(fileExtension);
    });

    if (validFiles.length === 0) {
        showNotification('请选择支持的文件格式 (PDF, EPUB, TXT, DOCX, DOC)', 'error');
        return;
    }

    selectedFiles = [...selectedFiles, ...validFiles];
    updateFileList();
    updateConvertButton();
}

// Update file list display
function updateFileList() {
    const fileList = document.getElementById('fileList');
    
    if (selectedFiles.length === 0) {
        fileList.innerHTML = '';
        return;
    }

    const fileListHTML = selectedFiles.map((file, index) => `
        <div class="file-item">
            <div class="file-info">
                <span class="file-name">${file.name}</span>
                <span class="file-size">${formatFileSize(file.size)}</span>
            </div>
            <button class="remove-file-btn" onclick="removeFile(${index})">✗</button>
        </div>
    `).join('');

    fileList.innerHTML = `
        <h4>选中的文件 (${selectedFiles.length})</h4>
        ${fileListHTML}
    `;
}

// Remove file from selection
function removeFile(index) {
    selectedFiles.splice(index, 1);
    updateFileList();
    updateConvertButton();
}

// Update convert button state
function updateConvertButton() {
    const convertBtn = document.getElementById('convertBtn');
    convertBtn.disabled = selectedFiles.length === 0;
}

// Start conversion process
async function startConversion() {
    if (selectedFiles.length === 0) {
        showNotification('请先选择要转换的文件', 'error');
        return;
    }

    // Get configuration values
    const config = {
        summaryLength: parseInt(document.getElementById('summaryLength').value),
        inputLanguage: document.getElementById('inputLanguage').value,
        outputLanguage: document.getElementById('outputLanguage').value,
        chunkSize: parseInt(document.getElementById('chunkSize').value),
        chunkOverlap: parseInt(document.getElementById('chunkOverlap').value)
    };

    // Validate configuration
    if (!validateConfig(config)) {
        return;
    }

    showProgressModal();
    
    try {
        for (let i = 0; i < selectedFiles.length; i++) {
            const file = selectedFiles[i];
            updateProgress(i / selectedFiles.length * 100, `处理文件: ${file.name}`);
            
            await processFile(file, config);
        }
        
        hideProgressModal();
        showNotification('所有文件转换完成！', 'success');
        
        // Clear selected files
        selectedFiles = [];
        document.getElementById('fileInput').value = '';
        updateFileList();
        updateConvertButton();
        
        // Refresh conversion history
        loadConversionHistory();
        
    } catch (error) {
        hideProgressModal();
        showNotification(`转换失败: ${error.message}`, 'error');
    }
}

// Validate configuration
function validateConfig(config) {
    if (config.summaryLength < 200 || config.summaryLength > 5000) {
        showNotification('总结文本字数应在 200-5000 字之间', 'error');
        return false;
    }
    
    if (config.chunkSize < 500 || config.chunkSize > 8000) {
        showNotification('文本分块大小应在 500-8000 字符之间', 'error');
        return false;
    }
    
    if (config.chunkOverlap < 50 || config.chunkOverlap > 800) {
        showNotification('文本重叠大小应在 50-800 字符之间', 'error');
        return false;
    }
    
    if (config.chunkOverlap >= config.chunkSize * 0.5) {
        showNotification('文本重叠大小不应超过分块大小的50%', 'error');
        return false;
    }
    
    return true;
}

// Process individual file
async function processFile(file, config) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('config', JSON.stringify(config));

    const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || '文件处理失败');
    }

    const result = await response.json();
    
    // Start conversion process
    await startFileConversion(result.fileId, config);
}

// Start file conversion
async function startFileConversion(fileId, config) {
    const response = await fetch('/api/conversion/start', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            fileId: fileId,
            config: config
        })
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || '转换启动失败');
    }

    const result = await response.json();
    currentConversions[result.conversionId] = {
        id: result.conversionId,
        status: 'processing',
        startTime: new Date()
    };

    // Wait for completion
    await waitForConversionCompletion(result.conversionId);
}

// Wait for conversion completion
async function waitForConversionCompletion(conversionId) {
    return new Promise((resolve, reject) => {
        const checkStatus = async () => {
            try {
                const response = await fetch(`/api/conversion/status/${conversionId}`);
                const status = await response.json();
                
                if (status.status === 'completed') {
                    resolve(status);
                } else if (status.status === 'failed') {
                    reject(new Error(status.error || '转换失败'));
                } else {
                    // Continue checking
                    setTimeout(checkStatus, 2000);
                }
            } catch (error) {
                reject(error);
            }
        };
        
        checkStatus();
    });
}

// Tab switching functionality
function switchTab(tabName) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Remove active class from all tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab content
    document.getElementById(`${tabName}-tab`).classList.add('active');
    
    // Add active class to selected tab button
    event.target.classList.add('active');
    
    // Load tab-specific data
    switch(tabName) {
        case 'conversion':
            loadConversionHistory();
            break;
        case 'mindmap':
            loadMindmap();
            break;
        case 'export':
            loadExportHistory();
            break;
    }
}

// Load conversion history
async function loadConversionHistory() {
    try {
        const response = await fetch('/api/conversion/history');
        const history = await response.json();
        
        const historyList = document.getElementById('historyList');
        
        if (history.length === 0) {
            historyList.innerHTML = '<p class="no-history">暂无历史记录</p>';
            return;
        }
        
        const historyHTML = history.map(item => `
            <div class="history-item">
                <div class="history-info">
                    <h4>${item.filename}</h4>
                    <p>转换时间: ${formatDate(item.createdAt)}</p>
                    <p>状态: <span class="status-${item.status}">${getStatusText(item.status)}</span></p>
                </div>
                <div class="history-actions">
                    <button onclick="viewMindmap('${item.id}')">查看思维导图</button>
                    <button onclick="downloadResult('${item.id}')">下载结果</button>
                </div>
            </div>
        `).join('');
        
        historyList.innerHTML = historyHTML;
        
    } catch (error) {
        console.error('加载转换历史失败:', error);
    }
}

// Update conversion status
async function updateConversionStatus() {
    const statusList = document.getElementById('statusList');
    
    if (Object.keys(currentConversions).length === 0) {
        statusList.innerHTML = '<p class="no-conversions">暂无转换任务</p>';
        return;
    }
    
    const statusHTML = Object.values(currentConversions).map(conversion => `
        <div class="status-item">
            <div class="status-info">
                <h4>转换任务 ${conversion.id}</h4>
                <p>状态: <span class="status-${conversion.status}">${getStatusText(conversion.status)}</span></p>
                <p>开始时间: ${formatDate(conversion.startTime)}</p>
            </div>
        </div>
    `).join('');
    
    statusList.innerHTML = statusHTML;
}

// Load mindmap
async function loadMindmap(conversionId = null) {
    // Implementation for loading mindmap
    const mindmapContainer = document.getElementById('mindmapContainer');
    
    if (!conversionId) {
        mindmapContainer.innerHTML = '<p class="no-mindmap">请先完成文件转换以查看思维导图</p>';
        return;
    }
    
    try {
        const response = await fetch(`/api/mindmap/${conversionId}`);
        const mindmapData = await response.json();
        
        // Render mindmap (implementation would depend on chosen mindmap library)
        renderMindmap(mindmapData);
        
    } catch (error) {
        console.error('加载思维导图失败:', error);
        mindmapContainer.innerHTML = '<p class="error">加载思维导图失败</p>';
    }
}

// Render mindmap (placeholder implementation)
function renderMindmap(data) {
    const container = document.getElementById('mindmapContainer');
    // This would integrate with a mindmap library like vis.js, d3.js, or similar
    container.innerHTML = '<div class="mindmap-placeholder">思维导图将在此处显示</div>';
}

// Load export history
async function loadExportHistory() {
    try {
        const response = await fetch('/api/export/history');
        const exports = await response.json();
        
        const exportList = document.getElementById('exportList');
        
        if (exports.length === 0) {
            exportList.innerHTML = '<p class="no-exports">暂无导出记录</p>';
            return;
        }
        
        const exportHTML = exports.map(item => `
            <div class="export-item">
                <div class="export-info">
                    <h4>${item.filename}</h4>
                    <p>导出格式: ${item.format.toUpperCase()}</p>
                    <p>导出时间: ${formatDate(item.createdAt)}</p>
                </div>
                <div class="export-actions">
                    <button onclick="downloadExport('${item.id}')">下载</button>
                </div>
            </div>
        `).join('');
        
        exportList.innerHTML = exportHTML;
        
    } catch (error) {
        console.error('加载导出历史失败:', error);
    }
}

// Export functions
function exportAs(format) {
    if (!currentMindmap) {
        showNotification('请先选择要导出的思维导图', 'error');
        return;
    }
    
    // Implementation for different export formats
    console.log(`Exporting as ${format}`);
}

// Mindmap controls
function zoomIn() {
    console.log('Zoom in');
}

function zoomOut() {
    console.log('Zoom out');
}

function resetZoom() {
    console.log('Reset zoom');
}

function exportMindmap() {
    console.log('Export mindmap');
}

// Progress modal functions
function showProgressModal() {
    document.getElementById('progressModal').style.display = 'flex';
}

function hideProgressModal() {
    document.getElementById('progressModal').style.display = 'none';
}

function updateProgress(percentage, text, details = '') {
    document.getElementById('progressFill').style.width = `${percentage}%`;
    document.getElementById('progressText').textContent = text;
    document.getElementById('progressDetails').textContent = details;
}

// Utility functions
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatDate(date) {
    return new Date(date).toLocaleString('zh-CN');
}

function getStatusText(status) {
    const statusMap = {
        'pending': '等待中',
        'processing': '处理中',
        'completed': '已完成',
        'failed': '失败'
    };
    return statusMap[status] || status;
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => notification.classList.add('show'), 100);
    
    // Hide and remove notification
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => document.body.removeChild(notification), 300);
    }, 3000);
}

// Action functions
function viewMindmap(conversionId) {
    switchTab('mindmap');
    loadMindmap(conversionId);
}

function downloadResult(conversionId) {
    window.open(`/api/conversion/download/${conversionId}`, '_blank');
}

function downloadExport(exportId) {
    window.open(`/api/export/download/${exportId}`, '_blank');
}