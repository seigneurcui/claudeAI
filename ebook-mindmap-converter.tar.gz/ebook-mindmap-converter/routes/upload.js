const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const router = express.Router();

// Configure multer for file upload
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = path.join(__dirname, '../uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        const uniqueName = uuidv4() + path.extname(file.originalname);
        cb(null, uniqueName);
    }
});

const fileFilter = (req, file, cb) => {
    const allowedTypes = ['.pdf', '.epub', '.txt', '.docx', '.doc'];
    const fileExtension = path.extname(file.originalname).toLowerCase();
    
    if (allowedTypes.includes(fileExtension)) {
        cb(null, true);
    } else {
        cb(new Error(`不支持的文件格式: ${fileExtension}. 支持的格式: ${allowedTypes.join(', ')}`), false);
    }
};

const upload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 50 * 1024 * 1024, // 50MB limit
        files: 10 // Maximum 10 files
    }
});

// File upload endpoint
router.post('/', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ 
                success: false, 
                message: '未选择文件' 
            });
        }

        // Parse configuration
        let config = {};
        try {
            if (req.body.config) {
                config = JSON.parse(req.body.config);
            }
        } catch (error) {
            console.warn('配置解析失败，使用默认配置:', error.message);
        }

        // Validate configuration
        const validatedConfig = validateConfig(config);

        // Generate file ID
        const fileId = uuidv4();
        
        // Create file record
        const fileRecord = {
            id: fileId,
            originalName: req.file.originalname,
            filename: req.file.filename,
            path: req.file.path,
            size: req.file.size,
            mimetype: req.file.mimetype,
            uploadedAt: new Date(),
            config: validatedConfig,
            status: 'uploaded'
        };

        // Store file record (in production, this would go to database)
        const recordPath = path.join(__dirname, '../uploads', `${fileId}.json`);
        fs.writeFileSync(recordPath, JSON.stringify(fileRecord, null, 2));

        console.log(`📁 文件上传成功: ${req.file.originalname} (${fileId})`);

        res.json({
            success: true,
            message: '文件上传成功',
            fileId: fileId,
            originalName: req.file.originalname,
            size: req.file.size,
            config: validatedConfig
        });

    } catch (error) {
        console.error('文件上传失败:', error);
        
        // Clean up uploaded file if it exists
        if (req.file && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path);
        }

        res.status(500).json({
            success: false,
            message: error.message || '文件上传失败'
        });
    }
});

// Validate and set default configuration values
function validateConfig(config) {
    const defaultConfig = {
        summaryLength: 800,
        inputLanguage: 'auto',
        outputLanguage: 'same',
        chunkSize: 2000,
        chunkOverlap: 200
    };

    // Language-specific defaults for chunk sizes
    const languageDefaults = {
        'auto': { chunkSize: 2000, chunkOverlap: 200 },
        'en': { chunkSize: 2000, chunkOverlap: 200 },
        'zh-cn': { chunkSize: 1000, chunkOverlap: 100 },
        'zh-tw': { chunkSize: 1000, chunkOverlap: 100 },
        'ja': { chunkSize: 800, chunkOverlap: 80 },
        'fr': { chunkSize: 1800, chunkOverlap: 180 },
        'es': { chunkSize: 1800, chunkOverlap: 180 },
        'pt': { chunkSize: 1800, chunkOverlap: 180 },
        'it': { chunkSize: 1800, chunkOverlap: 180 },
        'de': { chunkSize: 1500, chunkOverlap: 150 },
        'ru': { chunkSize: 1200, chunkOverlap: 120 }
    };

    const validatedConfig = { ...defaultConfig, ...config };

    // Apply language-specific defaults if chunk sizes weren't explicitly set
    if (config.inputLanguage && languageDefaults[config.inputLanguage]) {
        const langDefaults = languageDefaults[config.inputLanguage];
        if (!config.chunkSize) {
            validatedConfig.chunkSize = langDefaults.chunkSize;
        }
        if (!config.chunkOverlap) {
            validatedConfig.chunkOverlap = langDefaults.chunkOverlap;
        }
    }

    // Validate ranges
    validatedConfig.summaryLength = Math.max(200, Math.min(5000, validatedConfig.summaryLength));
    validatedConfig.chunkSize = Math.max(500, Math.min(8000, validatedConfig.chunkSize));
    validatedConfig.chunkOverlap = Math.max(50, Math.min(800, validatedConfig.chunkOverlap));

    // Ensure overlap is not more than 50% of chunk size
    if (validatedConfig.chunkOverlap >= validatedConfig.chunkSize * 0.5) {
        validatedConfig.chunkOverlap = Math.floor(validatedConfig.chunkSize * 0.4);
    }

    return validatedConfig;
}

// Get file info endpoint
router.get('/:fileId', (req, res) => {
    try {
        const fileId = req.params.fileId;
        const recordPath = path.join(__dirname, '../uploads', `${fileId}.json`);
        
        if (!fs.existsSync(recordPath)) {
            return res.status(404).json({
                success: false,
                message: '文件未找到'
            });
        }

        const fileRecord = JSON.parse(fs.readFileSync(recordPath, 'utf8'));
        
        res.json({
            success: true,
            file: fileRecord
        });

    } catch (error) {
        console.error('获取文件信息失败:', error);
        res.status(500).json({
            success: false,
            message: '获取文件信息失败'
        });
    }
});

// Delete file endpoint
router.delete('/:fileId', (req, res) => {
    try {
        const fileId = req.params.fileId;
        const recordPath = path.join(__dirname, '../uploads', `${fileId}.json`);
        
        if (!fs.existsSync(recordPath)) {
            return res.status(404).json({
                success: false,
                message: '文件未找到'
            });
        }

        const fileRecord = JSON.parse(fs.readFileSync(recordPath, 'utf8'));
        
        // Delete actual file
        if (fs.existsSync(fileRecord.path)) {
            fs.unlinkSync(fileRecord.path);
        }
        
        // Delete record file
        fs.unlinkSync(recordPath);

        console.log(`🗑️  文件删除成功: ${fileRecord.originalName} (${fileId})`);

        res.json({
            success: true,
            message: '文件删除成功'
        });

    } catch (error) {
        console.error('文件删除失败:', error);
        res.status(500).json({
            success: false,
            message: '文件删除失败'
        });
    }
});

module.exports = router;