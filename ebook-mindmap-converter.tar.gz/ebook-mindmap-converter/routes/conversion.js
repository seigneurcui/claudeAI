const express = require('express');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const fileParser = require('../utils/fileParser');
const ollamaClient = require('../utils/ollamaClient');
const mindmapGenerator = require('../utils/mindmapGenerator');
const { sendNotifications } = require('../utils/notifications');
const router = express.Router();

// In-memory storage for active conversions (in production, use Redis or database)
const activeConversions = new Map();
const conversionHistory = new Map();

// Start conversion endpoint
router.post('/start', async (req, res) => {
    try {
        const { fileId, config } = req.body;

        if (!fileId) {
            return res.status(400).json({
                success: false,
                message: '缺少文件ID'
            });
        }

        // Load file record
        const recordPath = path.join(__dirname, '../uploads', `${fileId}.json`);
        if (!fs.existsSync(recordPath)) {
            return res.status(404).json({
                success: false,
                message: '文件未找到'
            });
        }

        const fileRecord = JSON.parse(fs.readFileSync(recordPath, 'utf8'));
        const conversionId = uuidv4();

        // Create conversion record
        const conversionRecord = {
            id: conversionId,
            fileId: fileId,
            fileName: fileRecord.originalName,
            config: { ...fileRecord.config, ...config },
            status: 'pending',
            startTime: new Date(),
            progress: 0,
            steps: [
                { name: 'parse_file', status: 'pending', message: '解析文件中...' },
                { name: 'extract_text', status: 'pending', message: '提取文本中...' },
                { name: 'chunk_text', status: 'pending', message: '分割文本中...' },
                { name: 'generate_summary', status: 'pending', message: '生成摘要中...' },
                { name: 'create_mindmap', status: 'pending', message: '创建思维导图中...' },
                { name: 'finalize', status: 'pending', message: '完成处理...' }
            ]
        };

        // Store conversion record
        activeConversions.set(conversionId, conversionRecord);
        conversionHistory.set(conversionId, conversionRecord);

        // Start conversion process asynchronously
        processConversion(conversionId, fileRecord)
            .catch(error => {
                console.error(`转换失败 ${conversionId}:`, error);
                updateConversionStatus(conversionId, 'failed', error.message);
            });

        console.log(`🚀 开始转换: ${fileRecord.originalName} (${conversionId})`);

        res.json({
            success: true,
            conversionId: conversionId,
            message: '转换已开始'
        });

    } catch (error) {
        console.error('启动转换失败:', error);
        res.status(500).json({
            success: false,
            message: error.message || '启动转换失败'
        });
    }
});

// Get conversion status
router.get('/status/:conversionId', (req, res) => {
    try {
        const conversionId = req.params.conversionId;
        const conversion = activeConversions.get(conversionId) || conversionHistory.get(conversionId);

        if (!conversion) {
            return res.status(404).json({
                success: false,
                message: '转换记录未找到'
            });
        }

        res.json({
            success: true,
            conversion: conversion
        });

    } catch (error) {
        console.error('获取转换状态失败:', error);
        res.status(500).json({
            success: false,
            message: '获取转换状态失败'
        });
    }
});

// Get conversion history
router.get('/history', (req, res) => {
    try {
        const history = Array.from(conversionHistory.values())
            .sort((a, b) => new Date(b.startTime) - new Date(a.startTime))
            .slice(0, 50); // Return last 50 conversions

        res.json({
            success: true,
            history: history
        });

    } catch (error) {
        console.error('获取转换历史失败:', error);
        res.status(500).json({
            success: false,
            message: '获取转换历史失败'
        });
    }
});

// Download conversion result
router.get('/download/:conversionId', (req, res) => {
    try {
        const conversionId = req.params.conversionId;
        const conversion = conversionHistory.get(conversionId);

        if (!conversion || conversion.status !== 'completed') {
            return res.status(404).json({
                success: false,
                message: '转换结果未找到或转换未完成'
            });
        }

        const outputPath = path.join(__dirname, '../outputs', `${conversionId}.json`);
        
        if (!fs.existsSync(outputPath)) {
            return res.status(404).json({
                success: false,
                message: '结果文件未找到'
            });
        }

        res.download(outputPath, `${conversion.fileName}_summary.json`);

    } catch (error) {
        console.error('下载转换结果失败:', error);
        res.status(500).json({
            success: false,
            message: '下载转换结果失败'
        });
    }
});

// Process conversion (main conversion logic)
async function processConversion(conversionId, fileRecord) {
    const conversion = activeConversions.get(conversionId);
    if (!conversion) return;

    try {
        // Update status to processing
        updateConversionStatus(conversionId, 'processing');

        // Step 1: Parse file
        updateStepStatus(conversionId, 'parse_file', 'processing', '正在解析文件...');
        updateProgress(conversionId, 10);

        const parsedContent = await fileParser.parseFile(fileRecord.path, fileRecord.mimetype);
        updateStepStatus(conversionId, 'parse_file', 'completed', '文件解析完成');

        // Step 2: Extract text
        updateStepStatus(conversionId, 'extract_text', 'processing', '正在提取文本内容...');
        updateProgress(conversionId, 25);

        const extractedText = await fileParser.extractText(parsedContent, conversion.config.inputLanguage);
        updateStepStatus(conversionId, 'extract_text', 'completed', `提取了 ${extractedText.length} 字符`);

        // Step 3: Chunk text
        updateStepStatus(conversionId, 'chunk_text', 'processing', '正在分割文本...');
        updateProgress(conversionId, 40);

        const chunks = await fileParser.chunkText(extractedText, {
            chunkSize: conversion.config.chunkSize,
            chunkOverlap: conversion.config.chunkOverlap,
            language: conversion.config.inputLanguage
        });
        updateStepStatus(conversionId, 'chunk_text', 'completed', `分割为 ${chunks.length} 个文本块`);

        // Step 4: Generate summary using Ollama
        updateStepStatus(conversionId, 'generate_summary', 'processing', '正在生成AI摘要...');
        updateProgress(conversionId, 60);

        const summary = await ollamaClient.generateSummary(chunks, {
            summaryLength: conversion.config.summaryLength,
            inputLanguage: conversion.config.inputLanguage,
            outputLanguage: conversion.config.outputLanguage
        });
        updateStepStatus(conversionId, 'generate_summary', 'completed', `生成了 ${summary.length} 字符的摘要`);

        // Step 5: Create mindmap
        updateStepStatus(conversionId, 'create_mindmap', 'processing', '正在创建思维导图...');
        updateProgress(conversionId, 80);

        const mindmap = await mindmapGenerator.createMindmap(summary, {
            language: conversion.config.outputLanguage || conversion.config.inputLanguage,
            style: 'hierarchical'
        });
        updateStepStatus(conversionId, 'create_mindmap', 'completed', `创建了包含 ${mindmap.nodes?.length || 0} 个节点的思维导图`);

        // Step 6: Finalize and save results
        updateStepStatus(conversionId, 'finalize', 'processing', '正在保存结果...');
        updateProgress(conversionId, 95);

        const result = {
            conversionId: conversionId,
            fileName: fileRecord.originalName,
            config: conversion.config,
            summary: summary,
            mindmap: mindmap,
            statistics: {
                originalTextLength: extractedText.length,
                chunksCount: chunks.length,
                summaryLength: summary.length,
                processingTime: new Date() - conversion.startTime
            },
            createdAt: new Date()
        };

        // Save result to file
        const outputDir = path.join(__dirname, '../outputs');
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }

        const outputPath = path.join(outputDir, `${conversionId}.json`);
        fs.writeFileSync(outputPath, JSON.stringify(result, null, 2));

        updateStepStatus(conversionId, 'finalize', 'completed', '结果已保存');
        updateProgress(conversionId, 100);

        // Mark conversion as completed
        conversion.status = 'completed';
        conversion.endTime = new Date();
        conversion.duration = conversion.endTime - conversion.startTime;
        conversion.outputPath = outputPath;
        conversion.result = result;

        // Remove from active conversions
        activeConversions.delete(conversionId);

        console.log(`✅ 转换完成: ${fileRecord.originalName} (${conversionId}) - ${conversion.duration}ms`);

        // Send notifications
        await sendNotifications(
            fileRecord.originalName,
            fileRecord.originalName,
            outputPath,
            Math.round(conversion.duration / 1000),
            [conversion.config.outputLanguage || conversion.config.inputLanguage]
        );

    } catch (error) {
        console.error(`❌ 转换失败 ${conversionId}:`, error);
        updateConversionStatus(conversionId, 'failed', error.message);
        
        // Remove from active conversions
        activeConversions.delete(conversionId);
        
        throw error;
    }
}

// Helper functions
function updateConversionStatus(conversionId, status, errorMessage = null) {
    const conversion = activeConversions.get(conversionId) || conversionHistory.get(conversionId);
    if (conversion) {
        conversion.status = status;
        conversion.lastUpdate = new Date();
        if (errorMessage) {
            conversion.error = errorMessage;
        }
        
        // Update in both maps
        if (activeConversions.has(conversionId)) {
            activeConversions.set(conversionId, conversion);
        }
        conversionHistory.set(conversionId, conversion);
    }
}

function updateStepStatus(conversionId, stepName, status, message = null) {
    const conversion = activeConversions.get(conversionId);
    if (conversion && conversion.steps) {
        const step = conversion.steps.find(s => s.name === stepName);
        if (step) {
            step.status = status;
            step.lastUpdate = new Date();
            if (message) {
                step.message = message;
            }
        }
    }
}

function updateProgress(conversionId, progress) {
    const conversion = activeConversions.get(conversionId);
    if (conversion) {
        conversion.progress = progress;
        conversion.lastUpdate = new Date();
    }
}

module.exports = router;