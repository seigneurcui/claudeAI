const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Import routes
const uploadRouter = require('./routes/upload');
const conversionRouter = require('./routes/conversion');
const mindmapRouter = require('./routes/mindmap');
const exportRouter = require('./routes/export');
const ollamaRouter = require('./routes/ollama');

// Import utilities
const { validateNotificationConfig } = require('./utils/notifications');

// Security middleware
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            scriptSrc: ["'self'", "'unsafe-inline'"],
            imgSrc: ["'self'", "data:", "https:"],
            connectSrc: ["'self'", "https://api.telegram.org", "https://wxpusher.zjiecode.com", "http://www.pushplus.plus", "https://api.resend.com"]
        }
    }
}));

// CORS configuration
app.use(cors({
    origin: process.env.NODE_ENV === 'production' 
        ? ['https://yourdomain.com'] 
        : ['http://localhost:3000', 'http://127.0.0.1:3000'],
    credentials: true
}));

// Compression middleware
app.use(compression());

// Logging middleware
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        timestamp: new Date().toISOString(),
        version: require('./package.json').version,
        environment: process.env.NODE_ENV || 'development'
    });
});

// API Routes
app.use('/api/upload', uploadRouter);
app.use('/api/conversion', conversionRouter);
app.use('/api/mindmap', mindmapRouter);
app.use('/api/export', exportRouter);
app.use('/api/ollama', ollamaRouter);

// System information endpoint
app.get('/api/system/info', (req, res) => {
    const packageJson = require('./package.json');
    
    // Configuration moved to code since package.json had issues
    const supportedLanguages = ['auto', 'zh-cn', 'zh-tw', 'en', 'fr', 'es', 'pt', 'it', 'de', 'ru', 'ja'];
    const supportedFormats = ['pdf', 'epub', 'txt', 'docx', 'doc'];
    const chunkSizeDefaults = {
        'en': 2000, 'zh-cn': 1000, 'zh-tw': 1000, 'ja': 800,
        'fr': 1800, 'es': 1800, 'pt': 1800, 'it': 1800, 'de': 1500, 'ru': 1200
    };
    
    res.json({
        name: packageJson.name,
        version: packageJson.version,
        supportedLanguages: supportedLanguages,
        supportedFormats: supportedFormats,
        chunkSizeDefaults: chunkSizeDefaults,
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        platform: process.platform,
        nodeVersion: process.version
    });
});

// Configuration endpoint
app.get('/api/config', (req, res) => {
    res.json({
        languages: [
            { code: 'auto', name: '自动识别', chunkSize: 2000, chunkOverlap: 200 },
            { code: 'zh-cn', name: '简体中文', chunkSize: 1000, chunkOverlap: 100 },
            { code: 'zh-tw', name: '繁體中文', chunkSize: 1000, chunkOverlap: 100 },
            { code: 'en', name: 'English', chunkSize: 2000, chunkOverlap: 200 },
            { code: 'fr', name: 'Français', chunkSize: 1800, chunkOverlap: 180 },
            { code: 'es', name: 'Español', chunkSize: 1800, chunkOverlap: 180 },
            { code: 'pt', name: 'Português', chunkSize: 1800, chunkOverlap: 180 },
            { code: 'it', name: 'Italiano', chunkSize: 1800, chunkOverlap: 180 },
            { code: 'de', name: 'Deutsch', chunkSize: 1500, chunkOverlap: 150 },
            { code: 'ru', name: 'Русский', chunkSize: 1200, chunkOverlap: 120 },
            { code: 'ja', name: '日本語', chunkSize: 800, chunkOverlap: 80 }
        ],
        outputLanguages: [
            { code: 'same', name: '同源文档语言' },
            { code: 'zh-cn', name: '简体中文' },
            { code: 'zh-tw', name: '繁體中文' },
            { code: 'en', name: 'English' },
            { code: 'fr', name: 'Français' },
            { code: 'es', name: 'Español' },
            { code: 'pt', name: 'Português' },
            { code: 'it', name: 'Italiano' },
            { code: 'de', name: 'Deutsch' },
            { code: 'ru', name: 'Русский' },
            { code: 'ja', name: '日本語' }
        ],
        defaults: {
            summaryLength: 800,
            summaryLengthRange: { min: 200, max: 5000 },
            chunkSizeRange: { min: 500, max: 8000 },
            chunkOverlapRange: { min: 50, max: 800 }
        }
    });
});

// Statistics endpoint
app.get('/api/stats', async (req, res) => {
    try {
        const uploadsDir = path.join(__dirname, 'uploads');
        const outputsDir = path.join(__dirname, 'outputs');
        
        const uploadFiles = fs.existsSync(uploadsDir) ? fs.readdirSync(uploadsDir).filter(f => f.endsWith('.json')) : [];
        const outputFiles = fs.existsSync(outputsDir) ? fs.readdirSync(outputsDir).filter(f => f.endsWith('.json')) : [];
        
        // Calculate total file sizes
        let totalUploadSize = 0;
        let totalOutputSize = 0;
        
        uploadFiles.forEach(file => {
            try {
                const filePath = path.join(uploadsDir, file);
                const stats = fs.statSync(filePath);
                totalUploadSize += stats.size;
            } catch (error) {
                // Ignore errors for individual files
            }
        });
        
        outputFiles.forEach(file => {
            try {
                const filePath = path.join(outputsDir, file);
                const stats = fs.statSync(filePath);
                totalOutputSize += stats.size;
            } catch (error) {
                // Ignore errors for individual files
            }
        });
        
        res.json({
            totalUploads: uploadFiles.length,
            totalConversions: outputFiles.length,
            totalUploadSize: totalUploadSize,
            totalOutputSize: totalOutputSize,
            diskUsage: {
                uploads: formatBytes(totalUploadSize),
                outputs: formatBytes(totalOutputSize),
                total: formatBytes(totalUploadSize + totalOutputSize)
            },
            systemUptime: formatDuration(process.uptime() * 1000),
            lastUpdated: new Date().toISOString()
        });
        
    } catch (error) {
        console.error('获取统计信息失败:', error);
        res.status(500).json({
            error: '获取统计信息失败',
            message: error.message
        });
    }
});

// Catch-all handler for SPA
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Global error handler
app.use((error, req, res, next) => {
    console.error('Unhandled error:', error);
    
    // Don't send error details in production
    const isDevelopment = process.env.NODE_ENV !== 'production';
    
    res.status(error.status || 500).json({
        success: false,
        message: error.message || '服务器内部错误',
        ...(isDevelopment && { stack: error.stack })
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: '请求的资源未找到',
        path: req.path
    });
});

// Utility functions
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${days}天 ${hours % 24}小时`;
    if (hours > 0) return `${hours}小时 ${minutes % 60}分钟`;
    if (minutes > 0) return `${minutes}分钟 ${seconds % 60}秒`;
    return `${seconds}秒`;
}

// Initialize server
async function startServer() {
    try {
        // Create required directories
        const requiredDirs = ['uploads', 'outputs', 'database'];
        requiredDirs.forEach(dir => {
            const dirPath = path.join(__dirname, dir);
            if (!fs.existsSync(dirPath)) {
                fs.mkdirSync(dirPath, { recursive: true });
                console.log(`📁 Created directory: ${dir}`);
            }
        });
        
        // Validate notification configuration (optional)
        validateNotificationConfig();
        
        // Start the server
        app.listen(PORT, () => {
            console.log('🚀 ===============================================');
            console.log(`📚 电子书思维导图转换器服务已启动`);
            console.log(`🌐 服务地址: http://localhost:${PORT}`);
            console.log(`🔧 环境: ${process.env.NODE_ENV || 'development'}`);
            console.log(`📋 版本: ${require('./package.json').version}`);
            console.log('===============================================');
            
            // Log supported features
            const config = require('./package.json').configuration;
            console.log(`📖 支持的文件格式: ${config.supported_formats.join(', ')}`);
            console.log(`🌐 支持的语言: ${config.supported_languages.length}种语言`);
            console.log('🔄 系统已就绪，等待文件上传...');
        });
        
    } catch (error) {
        console.error('❌ 服务启动失败:', error);
        process.exit(1);
    }
}

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n🛑 收到关闭信号，正在优雅关闭服务...');
    
    // Clean up resources here if needed
    console.log('✅ 服务已安全关闭');
    process.exit(0);
});

process.on('uncaughtException', (error) => {
    console.error('❌ 未捕获的异常:', error);
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ 未处理的Promise拒绝:', reason);
    // Don't exit in production, but log the error
    if (process.env.NODE_ENV === 'production') {
        console.error('Promise:', promise);
    } else {
        process.exit(1);
    }
});

// Start the server
startServer();