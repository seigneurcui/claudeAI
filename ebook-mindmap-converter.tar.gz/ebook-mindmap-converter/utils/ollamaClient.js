const axios = require('axios');

class OllamaClient {
    constructor(options = {}) {
        this.baseURL = options.baseURL || process.env.OLLAMA_URL || 'http://localhost:11434';
        this.model = options.model || process.env.OLLAMA_MODEL || 'llama3.2:1b';
        this.timeout = options.timeout || 300000; // 5 minutes default
        this.maxRetries = options.maxRetries || 3;
        
        console.log(`🤖 Ollama客户端初始化: ${this.baseURL} (模型: ${this.model})`);
    }

    /**
     * Check if Ollama service is available
     */
    async checkHealth() {
        try {
            const response = await axios.get(`${this.baseURL}/api/tags`, { 
                timeout: 5000 
            });
            console.log('✅ Ollama服务连接正常');
            return true;
        } catch (error) {
            console.error('❌ Ollama服务连接失败:', error.message);
            return false;
        }
    }

    /**
     * Generate summary from text chunks
     * @param {Array} chunks - Text chunks to summarize
     * @param {Object} options - Summary options
     */
    async generateSummary(chunks, options = {}) {
        const {
            summaryLength = 800,
            inputLanguage = 'auto',
            outputLanguage = 'same'
        } = options;

        console.log(`📝 开始生成摘要: ${chunks.length}个文本块 -> ${summaryLength}字 (${inputLanguage} -> ${outputLanguage})`);

        try {
            // First, generate summaries for each chunk
            const chunkSummaries = [];
            
            for (let i = 0; i < chunks.length; i++) {
                const chunk = chunks[i];
                console.log(`🔄 处理文本块 ${i + 1}/${chunks.length} (${chunk.length}字符)`);
                
                const chunkSummary = await this.summarizeChunk(chunk.text, {
                    inputLanguage,
                    outputLanguage,
                    maxLength: Math.min(200, Math.floor(summaryLength / chunks.length * 1.5))
                });
                
                chunkSummaries.push({
                    index: i,
                    summary: chunkSummary,
                    originalLength: chunk.length
                });
            }

            console.log(`✅ 完成分块摘要，开始生成最终摘要...`);

            // Then, combine chunk summaries into final summary
            const finalSummary = await this.combineSummaries(chunkSummaries, {
                targetLength: summaryLength,
                outputLanguage
            });

            console.log(`✅ 摘要生成完成: ${finalSummary.length}字符`);
            return finalSummary;

        } catch (error) {
            console.error('❌ 摘要生成失败:', error);
            throw new Error(`摘要生成失败: ${error.message}`);
        }
    }

    /**
     * Summarize individual chunk
     */
    async summarizeChunk(text, options = {}) {
        const {
            inputLanguage = 'auto',
            outputLanguage = 'same',
            maxLength = 200
        } = options;

        const prompt = this.buildSummarizePrompt(text, {
            inputLanguage,
            outputLanguage,
            maxLength
        });

        return await this.callOllama(prompt, {
            temperature: 0.3,
            top_p: 0.9
        });
    }

    /**
     * Combine chunk summaries into final summary
     */
    async combineSummaries(chunkSummaries, options = {}) {
        const {
            targetLength = 800,
            outputLanguage = 'zh-cn'
        } = options;

        const combinedText = chunkSummaries
            .map(item => item.summary)
            .join('\n\n');

        const prompt = this.buildCombinePrompt(combinedText, {
            targetLength,
            outputLanguage
        });

        return await this.callOllama(prompt, {
            temperature: 0.2,
            top_p: 0.8
        });
    }

    /**
     * Build summarization prompt
     */
    buildSummarizePrompt(text, options) {
        const {
            inputLanguage = 'auto',
            outputLanguage = 'same',
            maxLength = 200
        } = options;

        const languageMap = {
            'zh-cn': '简体中文',
            'zh-tw': '繁体中文',
            'en': 'English',
            'fr': 'Français',
            'es': 'Español',
            'pt': 'Português',
            'it': 'Italiano',
            'de': 'Deutsch',
            'ru': 'Русский',
            'ja': '日本語'
        };

        const outputLang = outputLanguage === 'same' ? 
            (languageMap[inputLanguage] || '原文语言') : 
            (languageMap[outputLanguage] || outputLanguage);

        return `请对以下文本进行摘要，要求：
1. 摘要长度控制在${maxLength}字符以内
2. 使用${outputLang}输出
3. 保持原文的主要观点和核心信息
4. 确保语言流畅、逻辑清晰
5. 突出重点内容和关键概念

原文内容：
${text}

请生成摘要：`;
    }

    /**
     * Build combination prompt
     */
    buildCombinePrompt(combinedSummaries, options) {
        const {
            targetLength = 800,
            outputLanguage = 'zh-cn'
        } = options;

        const languageMap = {
            'zh-cn': '简体中文',
            'zh-tw': '繁体中文',
            'en': 'English',
            'fr': 'Français',
            'es': 'Español',
            'pt': 'Português',
            'it': 'Italiano',
            'de': 'Deutsch',
            'ru': 'Русский',
            'ja': '日本語'
        };

        const outputLang = languageMap[outputLanguage] || outputLanguage;

        return `请将以下各个部分的摘要整合成一篇完整的综合摘要，要求：
1. 总字数控制在${targetLength}字左右
2. 使用${outputLang}输出
3. 合理组织结构，确保逻辑连贯
4. 去除重复内容，突出核心要点
5. 保持专业性和可读性
6. 如果内容允许，可以分段组织

各部分摘要：
${combinedSummaries}

请生成最终的综合摘要：`;
    }

    /**
     * Call Ollama API with retry mechanism
     */
    async callOllama(prompt, options = {}) {
        const requestOptions = {
            model: this.model,
            prompt: prompt,
            stream: false,
            options: {
                temperature: options.temperature || 0.3,
                top_p: options.top_p || 0.9,
                top_k: options.top_k || 40,
                repeat_penalty: options.repeat_penalty || 1.1
            }
        };

        let lastError;
        
        for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
            try {
                console.log(`🤖 调用Ollama API (尝试 ${attempt}/${this.maxRetries})`);
                
                const response = await axios.post(`${this.baseURL}/api/generate`, requestOptions, {
                    timeout: this.timeout,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                if (response.data && response.data.response) {
                    const result = response.data.response.trim();
                    console.log(`✅ Ollama API调用成功 (${result.length}字符)`);
                    return result;
                } else {
                    throw new Error('Ollama返回数据格式错误');
                }

            } catch (error) {
                lastError = error;
                console.error(`❌ Ollama API调用失败 (尝试 ${attempt}/${this.maxRetries}):`, error.message);
                
                if (attempt < this.maxRetries) {
                    const delay = Math.pow(2, attempt) * 1000; // Exponential backoff
                    console.log(`⏳ ${delay/1000}秒后重试...`);
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        }

        throw new Error(`Ollama API调用失败，已尝试${this.maxRetries}次: ${lastError.message}`);
    }

    /**
     * Generate structured analysis
     */
    async generateStructuredAnalysis(text, options = {}) {
        const {
            outputLanguage = 'zh-cn',
            includeKeywords = true,
            includeThemes = true,
            includeSentiment = false
        } = options;

        const languageMap = {
            'zh-cn': '简体中文',
            'zh-tw': '繁体中文',
            'en': 'English'
        };

        const outputLang = languageMap[outputLanguage] || '简体中文';
        
        let analysisPrompt = `请对以下文本进行结构化分析，使用${outputLang}输出，要求：

1. 提供简洁的内容摘要（200-300字）
2. 识别主要论点和观点`;

        if (includeKeywords) {
            analysisPrompt += `\n3. 提取关键词和重要概念（5-10个）`;
        }

        if (includeThemes) {
            analysisPrompt += `\n4. 识别主要主题和话题（3-5个）`;
        }

        if (includeSentiment) {
            analysisPrompt += `\n5. 分析整体情感倾向`;
        }

        analysisPrompt += `

请按以下JSON格式输出：
{
    "summary": "内容摘要",
    "main_points": ["主要观点1", "主要观点2", ...],`;

        if (includeKeywords) {
            analysisPrompt += `
    "keywords": ["关键词1", "关键词2", ...],`;
        }

        if (includeThemes) {
            analysisPrompt += `
    "themes": ["主题1", "主题2", ...],`;
        }

        if (includeSentiment) {
            analysisPrompt += `
    "sentiment": "正面/中性/负面",`;
        }

        analysisPrompt += `
    "structure_suggestions": ["建议1", "建议2", ...]
}

文本内容：
${text}`;

        try {
            const response = await this.callOllama(analysisPrompt);
            
            // Try to parse JSON response
            try {
                return JSON.parse(response);
            } catch (parseError) {
                // If JSON parsing fails, return raw response
                console.warn('JSON解析失败，返回原始响应');
                return {
                    summary: response,
                    raw_response: true
                };
            }
        } catch (error) {
            throw new Error(`结构化分析失败: ${error.message}`);
        }
    }

    /**
     * Test the Ollama connection and model
     */
    async testConnection() {
        try {
            console.log('🧪 测试Ollama连接...');
            
            const testPrompt = "请简单回复'连接测试成功'";
            const response = await this.callOllama(testPrompt);
            
            console.log('✅ Ollama连接测试成功:', response);
            return true;
        } catch (error) {
            console.error('❌ Ollama连接测试失败:', error.message);
            return false;
        }
    }
}

// Create singleton instance
const ollamaClient = new OllamaClient();

module.exports = {
    OllamaClient,
    generateSummary: (chunks, options) => ollamaClient.generateSummary(chunks, options),
    generateStructuredAnalysis: (text, options) => ollamaClient.generateStructuredAnalysis(text, options),
    testConnection: () => ollamaClient.testConnection(),
    checkHealth: () => ollamaClient.checkHealth()
};
