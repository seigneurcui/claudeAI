const axios = require('axios');

/**
 * Send notifications to multiple platforms after ebook conversion completion
 * @param {string} ebookFileName - The name of the converted ebook file
 * @param {string} originalFileName - Original uploaded file name
 * @param {string} outputPath - Path to the conversion result
 * @param {number} duration - Processing duration in seconds
 * @param {Array} languages - Array of languages used in processing
 */
async function sendNotifications(ebookFileName, originalFileName, outputPath, duration, languages) {
    console.log(`📢 Sending notifications for: ${ebookFileName}`);
    const languagesList = languages.join(', ');
    
    const notifications = [
        {
            name: 'WxPusher',
            url: 'https://wxpusher.zjiecode.com/api/send/message',
            headers: { 'Content-Type': 'application/json' },
            data: {
                appToken: 'AT_byimkOmi7B0xzvqEvXVYIAj0YkMrwDvV',
                content: `📚 电子书转换完毕: ${originalFileName} ==> ${ebookFileName} : ${duration}s (语言: ${languagesList})`,
                summary: '电子书转换完毕',
                contentType: 2,
                topicIds: [36095],
                uids: ['UID_FD24Cus5ocGO5CKQAcxkw8gP2ZRu'],
                verifyPay: false,
                verifyPayType: 0,
            },
        },
        {
            name: 'PushPlus',
            url: 'http://www.pushplus.plus/send',
            headers: { 'Content-Type': 'application/json' },
            data: {
                token: 'f76bf4e54490439c86fdae45e9db76ce',
                title: '📚 电子书转换完毕',
                content: `电子书转换完毕: ${originalFileName} ==> ${ebookFileName} : ${duration}s (语言: ${languagesList})`,
            },
        },
        {
            name: 'Resend Email',
            url: 'https://api.resend.com/emails',
            headers: {
                'Authorization': 'Bearer re_KwMt5gij_5c7XvcqJeNjmAhV3cy1DAvfj',
                'Content-Type': 'application/json',
            },
            data: {
                from: 'onboarding@resend.dev',
                to: 'seigneurtsui@goallez.dpdns.org',
                subject: '📚 电子书转换完毕',
                html: `
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                        <h2 style="color: #667eea;">🎉 电子书转换完成通知</h2>
                        <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                            <p><strong>原始文件:</strong> ${originalFileName}</p>
                            <p><strong>转换结果:</strong> ${ebookFileName}</p>
                            <p><strong>处理时间:</strong> ${duration}秒</p>
                            <p><strong>处理语言:</strong> ${languagesList}</p>
                            <p><strong>输出路径:</strong> ${outputPath}</p>
                        </div>
                        <p style="color: #666;">您的电子书已成功转换为思维导图，请登录系统查看结果。</p>
                    </div>
                `,
            },
        },
        {
            name: 'Telegram',
            url: `https://api.telegram.org/bot837556252:AAHUpvXA_73QYDsNbmMWi2SOKTKzzOY_Y/sendMessage`,
            headers: { 'Content-Type': 'application/json' },
            data: {
                chat_id: '8200668152',
                text: `📚 电子书转换完毕\n\n📖 文件: ${originalFileName}\n⚡ 结果: ${ebookFileName}\n⏱️ 时间: ${duration}s\n🌐 语言: ${languagesList}\n\n✅ 转换成功完成！`,
                parse_mode: 'Markdown'
            },
        },
    ];

    // Send notifications concurrently
    const notificationPromises = notifications.map(async (notification) => {
        try {
            const response = await axios.post(notification.url, notification.data, {
                headers: notification.headers,
                timeout: 10000 // 10 second timeout
            });
            
            console.log(`✅ ${notification.name} notification sent successfully:`, response.status);
            return { name: notification.name, success: true, status: response.status };
        } catch (error) {
            console.error(`❌ Failed to send ${notification.name} notification:`, error.message);
            return { name: notification.name, success: false, error: error.message };
        }
    });

    // Wait for all notifications to complete
    const results = await Promise.allSettled(notificationPromises);
    
    // Log summary
    const successful = results.filter(r => r.status === 'fulfilled' && r.value.success).length;
    const failed = results.length - successful;
    
    console.log(`📊 Notification summary: ${successful} successful, ${failed} failed`);
    
    return results;
}

/**
 * Send a test notification to verify the notification system
 */
async function sendTestNotification() {
    console.log('🧪 Sending test notification...');
    
    try {
        await sendNotifications(
            'test-ebook.pdf',
            'test-original.pdf',
            '/outputs/test.json',
            30,
            ['简体中文', '英文']
        );
        console.log('✅ Test notification sent successfully');
    } catch (error) {
        console.error('❌ Test notification failed:', error);
    }
}

/**
 * Configure notification settings
 * @param {Object} config - Notification configuration
 */
function configureNotifications(config) {
    // This function could be used to update notification tokens/settings
    // from environment variables or configuration files
    console.log('⚙️  Notification configuration updated:', config);
}

/**
 * Validate notification configuration
 */
function validateNotificationConfig() {
    const requiredEnvVars = [
        'WXPUSHER_APP_TOKEN',
        'PUSHPLUS_TOKEN', 
        'RESEND_API_KEY',
        'TELEGRAM_BOT_TOKEN'
    ];
    
    const missing = requiredEnvVars.filter(envVar => !process.env[envVar]);
    
    if (missing.length > 0) {
        console.warn('⚠️  Missing notification configuration:', missing);
        return false;
    }
    
    console.log('✅ Notification configuration is valid');
    return true;
}

/**
 * Send notification for conversion failure
 * @param {string} fileName - The name of the file that failed to convert
 * @param {string} error - Error message
 */
async function sendFailureNotification(fileName, error) {
    console.log(`🚨 Sending failure notification for: ${fileName}`);
    
    const failureNotifications = [
        {
            name: 'Telegram',
            url: `https://api.telegram.org/bot8371556252:AAHUpvXA_73QYDsNbmMWiqG2SOKTKzzOY_Y/sendMessage`,
            headers: { 'Content-Type': 'application/json' },
            data: {
                chat_id: '8200348152',
                text: `🚨 电子书转换失败\n\n📖 文件: ${fileName}\n❌ 错误: ${error}\n\n请检查系统日志获取更多信息。`
            },
        }
    ];
    
    for (const notification of failureNotifications) {
        try {
            await axios.post(notification.url, notification.data, {
                headers: notification.headers,
                timeout: 5000
            });
            console.log(`✅ ${notification.name} failure notification sent`);
        } catch (error) {
            console.error(`❌ Failed to send ${notification.name} failure notification:`, error.message);
        }
    }
}

module.exports = {
    sendNotifications,
    sendTestNotification,
    sendFailureNotification,
    configureNotifications,
    validateNotificationConfig
};
