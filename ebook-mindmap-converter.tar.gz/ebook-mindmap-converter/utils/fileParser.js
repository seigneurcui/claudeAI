const fs = require('fs');
const path = require('path');
const pdf = require('pdf-parse');
const mammoth = require('mammoth');
const EPub = require('epub');

/**
 * Parse file based on its type
 * @param {string} filePath - Path to the file
 * @param {string} mimeType - MIME type of the file
 * @returns {Promise<Object>} Parsed content
 */
async function parseFile(filePath, mimeType) {
    console.log(`📖 Parsing file: ${path.basename(filePath)} (${mimeType})`);
    
    try {
        switch (true) {
            case mimeType === 'application/pdf':
                return await parsePDF(filePath);
            
            case mimeType === 'application/epub+zip':
            case path.extname(filePath).toLowerCase() === '.epub':
                return await parseEPUB(filePath);
            
            case mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
            case mimeType === 'application/msword':
            case path.extname(filePath).toLowerCase() === '.docx':
            case path.extname(filePath).toLowerCase() === '.doc':
                return await parseWord(filePath);
            
            case mimeType === 'text/plain':
            case path.extname(filePath).toLowerCase() === '.txt':
                return await parseText(filePath);
            
            default:
                throw new Error(`不支持的文件类型: ${mimeType}`);
        }
    } catch (error) {
        console.error(`解析文件失败: ${error.message}`);
        throw new Error(`解析文件失败: ${error.message}`);
    }
}

/**
 * Parse PDF file
 * @param {string} filePath - Path to PDF file
 * @returns {Promise<Object>} Parsed PDF content
 */
async function parsePDF(filePath) {
    const dataBuffer = fs.readFileSync(filePath);
    const data = await pdf(dataBuffer);
    
    return {
        type: 'pdf',
        text: data.text,
        pages: data.numpages,
        info: data.info,
        metadata: data.metadata
    };
}

/**
 * Parse EPUB file
 * @param {string} filePath - Path to EPUB file
 * @returns {Promise<Object>} Parsed EPUB content
 */
async function parseEPUB(filePath) {
    return new Promise((resolve, reject) => {
        const epub = new EPub(filePath);
        
        epub.on('end', async () => {
            try {
                const chapters = [];
                let fullText = '';
                
                // Get table of contents
                const toc = epub.toc;
                
                // Extract text from each chapter
                for (const chapter of epub.flow) {
                    try {
                        const chapterText = await new Promise((resolveChapter, rejectChapter) => {
                            epub.getChapter(chapter.id, (error, text) => {
                                if (error) {
                                    rejectChapter(error);
                                } else {
                                    // Remove HTML tags and clean text
                                    const cleanText = text.replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
                                    resolveChapter(cleanText);
                                }
                            });
                        });
                        
                        chapters.push({
                            id: chapter.id,
                            title: chapter.title || `Chapter ${chapters.length + 1}`,
                            text: chapterText
                        });
                        
                        fullText += chapterText + '\n\n';
                        
                    } catch (chapterError) {
                        console.warn(`跳过章节 ${chapter.id}: ${chapterError.message}`);
                    }
                }
                
                resolve({
                    type: 'epub',
                    text: fullText,
                    chapters: chapters,
                    metadata: {
                        title: epub.metadata.title,
                        creator: epub.metadata.creator,
                        publisher: epub.metadata.publisher,
                        language: epub.metadata.language,
                        date: epub.metadata.date
                    },
                    toc: toc
                });
                
            } catch (error) {
                reject(new Error(`EPUB解析失败: ${error.message}`));
            }
        });
        
        epub.on('error', (error) => {
            reject(new Error(`EPUB读取失败: ${error.message}`));
        });
        
        epub.parse();
    });
}

/**
 * Parse Word document
 * @param {string} filePath - Path to Word document
 * @returns {Promise<Object>} Parsed Word content
 */
async function parseWord(filePath) {
    const buffer = fs.readFileSync(filePath);
    const result = await mammoth.extractRawText({ buffer: buffer });
    
    return {
        type: 'word',
        text: result.value,
        messages: result.messages // Any warnings or errors
    };
}

/**
 * Parse plain text file
 * @param {string} filePath - Path to text file
 * @returns {Promise<Object>} Parsed text content
 */
async function parseText(filePath) {
    const text = fs.readFileSync(filePath, 'utf8');
    
    return {
        type: 'text',
        text: text,
        encoding: 'utf8'
    };
}

/**
 * Extract and clean text from parsed content
 * @param {Object} parsedContent - Parsed file content
 * @param {string} language - Language hint for text processing
 * @returns {Promise<string>} Cleaned text
 */
async function extractText(parsedContent, language = 'auto') {
    let text = '';
    
    switch (parsedContent.type) {
        case 'pdf':
        case 'word':
        case 'text':
            text = parsedContent.text;
            break;
            
        case 'epub':
            // For EPUB, we can optionally process chapters separately
            text = parsedContent.text;
            break;
            
        default:
            throw new Error(`不支持的内容类型: ${parsedContent.type}`);
    }
    
    // Clean and normalize text
    text = cleanText(text, language);
    
    if (text.length === 0) {
        throw new Error('未能提取到文本内容');
    }
    
    console.log(`✅ 提取文本成功: ${text.length} 字符`);
    return text;
}

/**
 * Clean and normalize text
 * @param {string} text - Raw text
 * @param {string} language - Language hint
 * @returns {string} Cleaned text
 */
function cleanText(text, language) {
    // Remove excessive whitespace
    text = text.replace(/\s+/g, ' ');
    
    // Remove control characters
    text = text.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
    
    // Normalize line breaks
    text = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    
    // Remove excessive line breaks
    text = text.replace(/\n{3,}/g, '\n\n');
    
    // Language-specific cleaning
    switch (language) {
        case 'zh-cn':
        case 'zh-tw':
            // Chinese text specific cleaning
            text = text.replace(/[，。！？；：""''（）]/g, match => {
                // Normalize Chinese punctuation
                const punctMap = {
                    '，': '，', '。': '。', '！': '！', '？': '？',
                    '；': '；', '：': '：', '"': '"', "'": "'", '（': '（', '）': '）'
                };
                return punctMap[match] || match;
            });
            break;
            
        case 'ja':
            // Japanese text specific cleaning
            break;
            
        default:
            // General text cleaning
            break;
    }
    
    return text.trim();
}

/**
 * Split text into chunks for processing
 * @param {string} text - Text to split
 * @param {Object} options - Chunking options
 * @returns {Promise<Array>} Array of text chunks
 */
async function chunkText(text, options = {}) {
    const {
        chunkSize = 2000,
        chunkOverlap = 200,
        language = 'auto'
    } = options;
    
    console.log(`🔨 分割文本: 块大小=${chunkSize}, 重叠=${chunkOverlap}, 语言=${language}`);
    
    const chunks = [];
    let start = 0;
    
    while (start < text.length) {
        let end = Math.min(start + chunkSize, text.length);
        
        // Try to break at sentence boundaries
        if (end < text.length) {
            end = findSentenceBoundary(text, end, language);
        }
        
        const chunk = text.substring(start, end).trim();
        
        if (chunk.length > 0) {
            chunks.push({
                index: chunks.length,
                text: chunk,
                start: start,
                end: end,
                length: chunk.length
            });
        }
        
        // Move start position with overlap
        start = end - chunkOverlap;
        if (start <= 0) {
            start = end;
        }
    }
    
    console.log(`✅ 文本分割完成: ${chunks.length} 个块`);
    return chunks;
}

/**
 * Find appropriate sentence boundary for chunk splitting
 * @param {string} text - Text to search in
 * @param {number} position - Current position
 * @param {string} language - Language hint
 * @returns {number} Adjusted position
 */
function findSentenceBoundary(text, position, language) {
    const searchRange = 100; // Look within 100 characters
    const startSearch = Math.max(0, position - searchRange);
    const endSearch = Math.min(text.length, position + searchRange);
    
    let boundaries = [];
    
    // Language-specific sentence boundaries
    switch (language) {
        case 'zh-cn':
        case 'zh-tw':
            boundaries = ['。', '！', '？', '；'];
            break;
        case 'ja':
            boundaries = ['。', '！', '？', '；'];
            break;
        default:
            boundaries = ['.', '!', '?', ';'];
            break;
    }
    
    // Find the nearest boundary
    let bestPosition = position;
    let bestDistance = Infinity;
    
    for (const boundary of boundaries) {
        const lastIndex = text.lastIndexOf(boundary, endSearch);
        if (lastIndex > startSearch) {
            const distance = Math.abs(lastIndex - position);
            if (distance < bestDistance) {
                bestDistance = distance;
                bestPosition = lastIndex + 1;
            }
        }
    }
    
    return bestPosition;
}

/**
 * Detect language of text content
 * @param {string} text - Text to analyze
 * @returns {string} Detected language code
 */
function detectLanguage(text) {
    // Simple language detection based on character patterns
    const sampleText = text.substring(0, 1000);
    
    // Chinese characters
    if (/[\u4e00-\u9fff]/.test(sampleText)) {
        // Simplified vs Traditional Chinese detection
        const simplifiedChars = /[亿万与习近]/g;
        const traditionalChars = /[億萬與習近]/g;
        
        const simplifiedCount = (sampleText.match(simplifiedChars) || []).length;
        const traditionalCount = (sampleText.match(traditionalChars) || []).length;
        
        return traditionalCount > simplifiedCount ? 'zh-tw' : 'zh-cn';
    }
    
    // Japanese characters
    if (/[\u3040-\u309f\u30a0-\u30ff]/.test(sampleText)) {
        return 'ja';
    }
    
    // Korean characters
    if (/[\uac00-\ud7af]/.test(sampleText)) {
        return 'ko';
    }
    
    // Russian Cyrillic
    if (/[\u0400-\u04ff]/.test(sampleText)) {
        return 'ru';
    }
    
    // European language detection (simplified)
    const commonWords = {
        'en': ['the', 'and', 'to', 'of', 'a', 'in', 'is', 'it', 'you', 'that'],
        'fr': ['le', 'de', 'et', 'à', 'un', 'il', 'être', 'et', 'en', 'avoir'],
        'es': ['el', 'de', 'que', 'y', 'a', 'en', 'un', 'ser', 'se', 'no'],
        'de': ['der', 'die', 'und', 'in', 'den', 'von', 'zu', 'das', 'mit', 'sich'],
        'it': ['il', 'di', 'che', 'e', 'la', 'per', 'un', 'in', 'con', 'non'],
        'pt': ['o', 'de', 'que', 'e', 'do', 'da', 'em', 'um', 'para', 'é']
    };
    
    const words = sampleText.toLowerCase().match(/\b\w+\b/g) || [];
    let bestMatch = 'en';
    let bestScore = 0;
    
    for (const [lang, commonWordsForLang] of Object.entries(commonWords)) {
        const score = words.filter(word => commonWordsForLang.includes(word)).length;
        if (score > bestScore) {
            bestScore = score;
            bestMatch = lang;
        }
    }
    
    return bestMatch;
}

module.exports = {
    parseFile,
    extractText,
    chunkText,
    cleanText,
    detectLanguage,
    parsePDF,
    parseEPUB,
    parseWord,
    parseText
};
