/**
 * Enhanced Mindmap Generator
 * Generates structured mindmaps from summarized text content
 */

class MindmapGenerator {
    constructor() {
        this.nodeIdCounter = 0;
    }

    /**
     * Create mindmap from summary text
     * @param {string} summaryText - Summarized text content
     * @param {Object} options - Generation options
     * @returns {Object} Mindmap data structure
     */
    async createMindmap(summaryText, options = {}) {
        const {
            language = 'zh-cn',
            style = 'hierarchical',
            maxDepth = 4,
            maxNodesPerLevel = 8
        } = options;

        console.log(`🧠 开始生成思维导图: ${summaryText.length}字符 (${language}, ${style})`);

        try {
            // Parse and structure the summary
            const structure = await this.parseTextStructure(summaryText, language);
            
            // Create mindmap nodes
            const mindmap = this.buildMindmapStructure(structure, {
                style,
                maxDepth,
                maxNodesPerLevel,
                language
            });

            // Add metadata
            mindmap.metadata = {
                generatedAt: new Date().toISOString(),
                language: language,
                style: style,
                sourceLength: summaryText.length,
                nodeCount: this.countNodes(mindmap),
                maxDepth: this.calculateMaxDepth(mindmap)
            };

            console.log(`✅ 思维导图生成完成: ${mindmap.metadata.nodeCount}个节点`);
            return mindmap;

        } catch (error) {
            console.error('❌ 思维导图生成失败:', error);
            throw new Error(`思维导图生成失败: ${error.message}`);
        }
    }

    /**
     * Parse text structure into hierarchical data
     */
    async parseTextStructure(text, language) {
        // Split text into sentences/paragraphs based on language
        const sentences = this.splitIntoSentences(text, language);
        
        // Identify key phrases and themes
        const keyPhrases = this.extractKeyPhrases(sentences, language);
        
        // Group related content
        const themes = this.groupIntoThemes(keyPhrases, sentences, language);
        
        // Build hierarchical structure
        const structure = this.buildHierarchy(themes, language);
        
        return structure;
    }

    /**
     * Split text into sentences based on language
     */
    splitIntoSentences(text, language) {
        let sentences = [];
        
        switch (language) {
            case 'zh-cn':
            case 'zh-tw':
                // Chinese sentence splitting
                sentences = text.split(/[。！？；]/).filter(s => s.trim().length > 0);
                break;
                
            case 'ja':
                // Japanese sentence splitting
                sentences = text.split(/[。！？]/).filter(s => s.trim().length > 0);
                break;
                
            default:
                // English and other languages
                sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
                break;
        }
        
        return sentences.map(s => s.trim()).filter(s => s.length > 10);
    }

    /**
     * Extract key phrases from sentences
     */
    extractKeyPhrases(sentences, language) {
        const keyPhrases = [];
        const stopWords = this.getStopWords(language);
        
        sentences.forEach((sentence, index) => {
            // Simple key phrase extraction based on patterns
            const phrases = this.identifyPhrases(sentence, language, stopWords);
            
            phrases.forEach(phrase => {
                keyPhrases.push({
                    text: phrase,
                    sentence: sentence,
                    sentenceIndex: index,
                    weight: this.calculatePhraseWeight(phrase, sentence, language)
                });
            });
        });
        
        // Sort by weight and return top phrases
        return keyPhrases
            .sort((a, b) => b.weight - a.weight)
            .slice(0, 50); // Top 50 key phrases
    }

    /**
     * Get stop words for language
     */
    getStopWords(language) {
        const stopWords = {
            'zh-cn': ['的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这'],
            'zh-tw': ['的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一個', '上', '也', '很', '到', '說', '要', '去', '你', '會', '著', '沒有', '看', '好', '自己', '這'],
            'en': ['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should'],
            'ja': ['の', 'に', 'は', 'を', 'が', 'で', 'と', 'から', 'まで', 'より', 'も', 'て', 'だ', 'である', 'です', 'ます', 'した', 'する', 'される'],
            'fr': ['le', 'la', 'les', 'un', 'une', 'et', 'ou', 'de', 'du', 'des', 'à', 'au', 'aux', 'dans', 'sur', 'avec', 'par', 'pour', 'est', 'sont', 'était', 'étaient'],
            'es': ['el', 'la', 'los', 'las', 'un', 'una', 'y', 'o', 'de', 'del', 'en', 'con', 'por', 'para', 'es', 'son', 'era', 'eran', 'que', 'se'],
            'de': ['der', 'die', 'das', 'ein', 'eine', 'und', 'oder', 'von', 'zu', 'in', 'auf', 'mit', 'für', 'ist', 'sind', 'war', 'waren', 'dass', 'sich'],
            'ru': ['и', 'в', 'не', 'что', 'он', 'на', 'я', 'с', 'как', 'а', 'то', 'все', 'она', 'так', 'его', 'но', 'да', 'ты', 'к', 'у'],
            'it': ['il', 'la', 'di', 'che', 'e', 'un', 'a', 'è', 'per', 'in', 'una', 'sono', 'si', 'non', 'con', 'le', 'su', 'del', 'al'],
            'pt': ['o', 'a', 'de', 'e', 'do', 'da', 'em', 'um', 'para', 'é', 'com', 'não', 'uma', 'os', 'no', 'se', 'na', 'por', 'mais', 'as']
        };
        
        return stopWords[language] || stopWords['en'];
    }

    /**
     * Identify phrases in sentence
     */
    identifyPhrases(sentence, language, stopWords) {
        const phrases = [];
        
        // Simple noun phrase extraction
        const words = sentence.split(/\s+/);
        
        // Extract 2-4 word phrases that don't start/end with stop words
        for (let i = 0; i < words.length - 1; i++) {
            for (let len = 2; len <= Math.min(4, words.length - i); len++) {
                const phrase = words.slice(i, i + len).join(' ');
                const cleanPhrase = phrase.replace(/[^\w\s\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]/g, '').trim();
                
                if (cleanPhrase.length > 3 && 
                    !stopWords.includes(words[i].toLowerCase()) && 
                    !stopWords.includes(words[i + len - 1].toLowerCase())) {
                    phrases.push(cleanPhrase);
                }
            }
        }
        
        return phrases;
    }

    /**
     * Calculate phrase weight/importance
     */
    calculatePhraseWeight(phrase, sentence, language) {
        let weight = 1;
        
        // Length bonus
        weight += phrase.length * 0.1;
        
        // Position bonus (phrases at beginning/end are often important)
        const position = sentence.indexOf(phrase) / sentence.length;
        if (position < 0.3 || position > 0.7) {
            weight += 0.5;
        }
        
        // Capitalization bonus (for non-CJK languages)
        if (!['zh-cn', 'zh-tw', 'ja'].includes(language)) {
            if (/^[A-Z]/.test(phrase)) {
                weight += 0.3;
            }
        }
        
        return weight;
    }

    /**
     * Group key phrases into themes
     */
    groupIntoThemes(keyPhrases, sentences, language) {
        const themes = [];
        const usedPhrases = new Set();
        
        // Simple clustering based on word similarity
        keyPhrases.forEach(phrase => {
            if (usedPhrases.has(phrase.text)) return;
            
            const theme = {
                mainConcept: phrase.text,
                relatedPhrases: [phrase],
                sentences: [phrase.sentence],
                weight: phrase.weight
            };
            
            // Find related phrases
            keyPhrases.forEach(otherPhrase => {
                if (otherPhrase.text !== phrase.text && 
                    !usedPhrases.has(otherPhrase.text) &&
                    this.calculateSimilarity(phrase.text, otherPhrase.text, language) > 0.3) {
                    
                    theme.relatedPhrases.push(otherPhrase);
                    theme.sentences.push(otherPhrase.sentence);
                    theme.weight += otherPhrase.weight;
                    usedPhrases.add(otherPhrase.text);
                }
            });
            
            usedPhrases.add(phrase.text);
            themes.push(theme);
        });
        
        return themes.sort((a, b) => b.weight - a.weight).slice(0, 15); // Top 15 themes
    }

    /**
     * Calculate similarity between two phrases
     */
    calculateSimilarity(phrase1, phrase2, language) {
        const words1 = new Set(phrase1.toLowerCase().split(/\s+/));
        const words2 = new Set(phrase2.toLowerCase().split(/\s+/));
        
        const intersection = new Set([...words1].filter(x => words2.has(x)));
        const union = new Set([...words1, ...words2]);
        
        return intersection.size / union.size; // Jaccard similarity
    }

    /**
     * Build hierarchical structure from themes
     */
    buildHierarchy(themes, language) {
        const rootNode = {
            id: this.getNextNodeId(),
            text: this.generateRootTitle(themes, language),
            type: 'root',
            children: []
        };
        
        // Group themes into categories
        const categories = this.categorizeThemes(themes, language);
        
        categories.forEach(category => {
            const categoryNode = {
                id: this.getNextNodeId(),
                text: category.title,
                type: 'category',
                children: [],
                weight: category.weight
            };
            
            category.themes.forEach(theme => {
                const themeNode = {
                    id: this.getNextNodeId(),
                    text: theme.mainConcept,
                    type: 'theme',
                    children: [],
                    weight: theme.weight,
                    sentences: theme.sentences.slice(0, 3) // Keep top 3 sentences
                };
                
                // Add sub-concepts
                theme.relatedPhrases.slice(1, 4).forEach(relatedPhrase => {
                    themeNode.children.push({
                        id: this.getNextNodeId(),
                        text: relatedPhrase.text,
                        type: 'concept',
                        weight: relatedPhrase.weight
                    });
                });
                
                categoryNode.children.push(themeNode);
            });
            
            rootNode.children.push(categoryNode);
        });
        
        return rootNode;
    }

    /**
     * Generate root title from themes
     */
    generateRootTitle(themes, language) {
        const titles = {
            'zh-cn': '文档概览',
            'zh-tw': '文檔概覽',
            'en': 'Document Overview',
            'ja': '文書概要',
            'fr': 'Aperçu du Document',
            'es': 'Resumen del Documento',
            'de': 'Dokumentübersicht',
            'ru': 'Обзор Документа',
            'it': 'Panoramica del Documento',
            'pt': 'Visão Geral do Documento'
        };
        
        return titles[language] || titles['en'];
    }

    /**
     * Categorize themes into broader categories
     */
    categorizeThemes(themes, language) {
        const categories = [];
        const categoryNames = this.getCategoryNames(language);
        
        // Simple categorization - divide themes into 3-5 categories
        const themesPerCategory = Math.max(2, Math.ceil(themes.length / 4));
        
        for (let i = 0; i < themes.length; i += themesPerCategory) {
            const categoryThemes = themes.slice(i, i + themesPerCategory);
            const categoryIndex = Math.floor(i / themesPerCategory);
            
            categories.push({
                title: categoryNames[categoryIndex] || `${categoryNames[0]} ${categoryIndex + 1}`,
                themes: categoryThemes,
                weight: categoryThemes.reduce((sum, theme) => sum + theme.weight, 0)
            });
        }
        
        return categories;
    }

    /**
     * Get category names by language
     */
    getCategoryNames(language) {
        const names = {
            'zh-cn': ['核心概念', '关键要点', '详细内容', '补充信息', '总结观点'],
            'zh-tw': ['核心概念', '關鍵要點', '詳細內容', '補充資訊', '總結觀點'],
            'en': ['Core Concepts', 'Key Points', 'Details', 'Additional Info', 'Summary'],
            'ja': ['核心概念', 'キーポイント', '詳細', '補足情報', '要約'],
            'fr': ['Concepts Clés', 'Points Principaux', 'Détails', 'Infos Supplémentaires', 'Résumé'],
            'es': ['Conceptos Clave', 'Puntos Principales', 'Detalles', 'Información Adicional', 'Resumen'],
            'de': ['Kernkonzepte', 'Hauptpunkte', 'Details', 'Zusätzliche Infos', 'Zusammenfassung'],
            'ru': ['Основные Концепции', 'Ключевые Моменты', 'Детали', 'Дополнительная Информация', 'Резюме'],
            'it': ['Concetti Chiave', 'Punti Principali', 'Dettagli', 'Informazioni Aggiuntive', 'Riassunto'],
            'pt': ['Conceitos Principais', 'Pontos Chave', 'Detalhes', 'Informações Adicionais', 'Resumo']
        };
        
        return names[language] || names['en'];
    }

    /**
     * Build mindmap structure with different styles
     */
    buildMindmapStructure(rootNode, options) {
        const { style, maxDepth, maxNodesPerLevel } = options;
        
        // Prune tree to respect limits
        this.pruneTree(rootNode, maxDepth, maxNodesPerLevel);
        
        // Add visual properties based on style
        this.addVisualProperties(rootNode, style);
        
        return {
            root: rootNode,
            style: style,
            layout: this.generateLayout(rootNode, style),
            colors: this.generateColorScheme(style),
            edges: this.generateEdges(rootNode)
        };
    }

    /**
     * Prune tree to respect depth and width limits
     */
    pruneTree(node, maxDepth, maxNodesPerLevel, currentDepth = 0) {
        if (currentDepth >= maxDepth) {
            node.children = [];
            return;
        }
        
        // Limit children per level
        if (node.children && node.children.length > maxNodesPerLevel) {
            node.children = node.children
                .sort((a, b) => (b.weight || 0) - (a.weight || 0))
                .slice(0, maxNodesPerLevel);
        }
        
        // Recursively prune children
        if (node.children) {
            node.children.forEach(child => {
                this.pruneTree(child, maxDepth, maxNodesPerLevel, currentDepth + 1);
            });
        }
    }

    /**
     * Add visual properties to nodes
     */
    addVisualProperties(node, style) {
        // Add coordinates, colors, sizes based on style and node type
        const visualProps = this.getVisualProps(node.type, style);
        
        Object.assign(node, visualProps);
        
        if (node.children) {
            node.children.forEach(child => {
                this.addVisualProperties(child, style);
            });
        }
    }

    /**
     * Get visual properties for node type
     */
    getVisualProps(nodeType, style) {
        const props = {
            root: { size: 40, color: '#2c5aa0', fontSize: 16, fontWeight: 'bold' },
            category: { size: 30, color: '#2196f3', fontSize: 14, fontWeight: 'bold' },
            theme: { size: 25, color: '#4caf50', fontSize: 12, fontWeight: 'normal' },
            concept: { size: 20, color: '#ff9800', fontSize: 10, fontWeight: 'normal' }
        };
        
        return props[nodeType] || props.concept;
    }

    /**
     * Generate layout information
     */
    generateLayout(rootNode, style) {
        return {
            type: style,
            centerX: 400,
            centerY: 300,
            spacing: 120,
            angleStep: style === 'radial' ? (2 * Math.PI / rootNode.children.length) : 0
        };
    }

    /**
     * Generate color scheme
     */
    generateColorScheme(style) {
        const schemes = {
            hierarchical: ['#2c5aa0', '#2196f3', '#4caf50', '#ff9800', '#f44336'],
            radial: ['#673ab7', '#3f51b5', '#2196f3', '#00bcd4', '#4caf50'],
            organic: ['#8bc34a', '#4caf50', '#00bcd4', '#2196f3', '#3f51b5']
        };
        
        return schemes[style] || schemes.hierarchical;
    }

    /**
     * Generate edge information
     */
    generateEdges(rootNode) {
        const edges = [];
        
        const traverse = (node) => {
            if (node.children) {
                node.children.forEach(child => {
                    edges.push({
                        from: node.id,
                        to: child.id,
                        type: 'hierarchy',
                        weight: child.weight || 1
                    });
                    traverse(child);
                });
            }
        };
        
        traverse(rootNode);
        return edges;
    }

    /**
     * Utility functions
     */
    getNextNodeId() {
        return `node_${++this.nodeIdCounter}`;
    }

    countNodes(mindmap) {
        let count = 0;
        const traverse = (node) => {
            count++;
            if (node.children) {
                node.children.forEach(traverse);
            }
        };
        traverse(mindmap.root);
        return count;
    }

    calculateMaxDepth(mindmap) {
        const traverse = (node, depth = 0) => {
            let maxDepth = depth;
            if (node.children) {
                node.children.forEach(child => {
                    maxDepth = Math.max(maxDepth, traverse(child, depth + 1));
                });
            }
            return maxDepth;
        };
        return traverse(mindmap.root);
    }

    /**
     * Export mindmap to different formats
     */
    exportToFormat(mindmap, format) {
        switch (format) {
            case 'json':
                return JSON.stringify(mindmap, null, 2);
            case 'svg':
                return this.generateSVG(mindmap);
            case 'dot':
                return this.generateDOT(mindmap);
            default:
                throw new Error(`Unsupported export format: ${format}`);
        }
    }

    /**
     * Generate SVG representation
     */
    generateSVG(mindmap) {
        // Basic SVG generation - can be enhanced
        const { root, layout } = mindmap;
        let svg = `<svg width="800" height="600" xmlns="http://www.w3.org/2000/svg">`;
        
        const traverse = (node, x, y, level = 0) => {
            // Draw node
            svg += `<circle cx="${x}" cy="${y}" r="${node.size || 20}" fill="${node.color || '#2196f3'}" />`;
            svg += `<text x="${x}" y="${y + 5}" text-anchor="middle" font-size="${node.fontSize || 12}">${node.text}</text>`;
            
            // Draw children
            if (node.children && node.children.length > 0) {
                const angleStep = (2 * Math.PI) / node.children.length;
                const radius = 100 + level * 50;
                
                node.children.forEach((child, index) => {
                    const angle = index * angleStep;
                    const childX = x + Math.cos(angle) * radius;
                    const childY = y + Math.sin(angle) * radius;
                    
                    // Draw edge
                    svg += `<line x1="${x}" y1="${y}" x2="${childX}" y2="${childY}" stroke="#666" stroke-width="2" />`;
                    
                    traverse(child, childX, childY, level + 1);
                });
            }
        };
        
        traverse(root, layout.centerX, layout.centerY);
        svg += `</svg>`;
        
        return svg;
    }

    /**
     * Generate DOT format for Graphviz
     */
    generateDOT(mindmap) {
        let dot = 'digraph mindmap {\n';
        dot += '  node [fontname="Arial" fontsize=12];\n';
        dot += '  edge [color="#666666"];\n\n';
        
        const traverse = (node) => {
            dot += `  "${node.id}" [label="${node.text}" shape=ellipse];\n`;
            
            if (node.children) {
                node.children.forEach(child => {
                    dot += `  "${node.id}" -> "${child.id}";\n`;
                    traverse(child);
                });
            }
        };
        
        traverse(mindmap.root);
        dot += '}';
        
        return dot;
    }
}

// Create singleton instance
const mindmapGenerator = new MindmapGenerator();

module.exports = {
    MindmapGenerator,
    createMindmap: (summaryText, options) => mindmapGenerator.createMindmap(summaryText, options),
    exportToFormat: (mindmap, format) => mindmapGenerator.exportToFormat(mindmap, format)
};